'use strict';

angular.module('applications', ['ngTable']);

//Routers
myApp.config(function($stateProvider)
{
  
  //Search Applications
  $stateProvider.state('applications',
  {
	url: '/applications',
    templateUrl: 'partials/applications/applications.html',
	data:
	{
		auth:true
	}
  });
  
  //Add Application
  $stateProvider.state('addApplication', 
 {
	url: '/addApplication',
    templateUrl: 'partials/applications/addApplication.html',
    controller: 'addApplicationController',
	data:
	{
		auth:true
	}
  });
  
  $stateProvider.state('viewReport', 
  {
 	 url: '/viewReport/{id}',
     templateUrl: 'partials/applications/viewReport.html',
     controller: 'viewReportController',
 	data:
 	{
 		auth:true
 	}
   });
  
  
  
  //Application Tab
  $stateProvider.state('application', {
    url: '',
	abstract:true,
    templateUrl: 'partials/applications/applicationTab.html',
	data:{
		auth:true
	}
  });

  //View application
  $stateProvider.state('application.view', 
 {
    url: "/view/{id}",
    views: {
      "viewApplication": 
      {
        templateUrl: "partials/applications/viewApplication.html",
        controller: 'viewApplicationController'
      }
    },
    resolve:
    {
      applicationResolved: function(applicationServices, $stateParams)
      {
        return applicationServices.getApplication($stateParams.id);
      }
    },
	data:
	{
		auth:true
	}
  });
    
  //View application Config
  $stateProvider.state('application.configview', 
 {
    url: "/view/config/{id}",
    views: {
      "viewConfigApplication":
      {
        templateUrl: "partials/applications/viewConfigApplication.html",
        controller: 'viewApplicationConfigController'
      }
    },
	data:
	{
		auth:true
	}
  });
  
//View application Config
 $stateProvider.state('configApplication', 
 {
	  url: '/configApplication/{id}',
	  templateUrl: 'partials/applications/configApplication.html',
	  controller: 'addApplicationConfigController',
		data:
		{
			auth:true
		}
  });
 
 $stateProvider.state('editConfigApplication', 
 {
	  url: '/editConfigApplication/{id}',
	  templateUrl: 'partials/applications/editConfigApplication.html',
	  controller: 'editApplicationConfigController',
		data:
		{
			auth:true
		}
  });
  
  
  $stateProvider.state('editUploadClassApplication', 
  {
 	  url: '/editUploadClassApplication/{id}',
 	  templateUrl: 'partials/applications/uploadApplication.html',
 	  controller: 'editUploadClassController',
 		data:
 		{
 			auth:true
 		}
   });
  
  
  $stateProvider.state('editUploadSourceApplication', 
  {
 	  url: '/editUploadSourceApplication/{id}',
 	  templateUrl: 'partials/applications/uploadApplication.html',
 	  controller: 'editUploadSourceController',
 		data:
 		{
 			auth:true
 		}
   });
  
  $stateProvider.state('uploadSourceApplication', 
  {
 	  url: '/uploadSourceApplication/{id}',
 	  templateUrl: 'partials/applications/uploadApplication.html',
 	  controller: 'uploadSourceController',
 		data:
 		{
 			auth:true
 		}
   });
  
  $stateProvider.state('uploadClassApplication', 
  {
 	  url: '/uploadClassApplication/{id}',
 	  templateUrl: 'partials/applications/uploadApplication.html',
 	  controller: 'uploadClassController',
 		data:
 		{
 			auth:true
 		}
   });
  

  //Add Application
  $stateProvider.state('editApplication', 
 {
	url: '/editApplication/{id}',
    templateUrl: 'partials/applications/editApplication.html',
    controller: 'editApplicationController',
	data:
	{
		auth:true
	}
  });
  
    
});

//Factories
myApp.factory('applicationServices', ['$rootScope','$http','dialogs', function($rootScope,$http,dialogs)
{

    var factoryDefinitions = 
    {
	  getApplications: function() 
	  {
		dialogs.wait(undefined,undefined,100);
		  
        return $http.get('/ccqp-service/app/search/all.json')
        .success(function(data) 
        { 
        	$rootScope.$broadcast('dialogs.wait.complete');
        	return data; 
        }).error(function(data)
    	        {
        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
        });
      },
      getConfigurations: function(applicationId) 
	  {
    	dialogs.wait(undefined,undefined,100); 
    	
    	return $http.get('/ccqp-service/app/search/'+applicationId+'.json')
        .success(function(data) 
        { 
        	$rootScope.$broadcast('dialogs.wait.complete');
        	return data;
        }).error(function(data)
    	        {
        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
        });
      },
      getMasterConfigurations: function(strategy) 
	  {
    	  dialogs.wait(undefined,undefined,100);  
    	return $http.get('/ccqp-service/master/config/search/all/'+strategy+'.json')
        .success(function(data)
        { 
        	$rootScope.$broadcast('dialogs.wait.complete');
        	return data;
        }).error(function(data)
    	        {
        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
        });
      },
	  addApplication: function(applicationReq) 
	  {
		  dialogs.wait(undefined,undefined,100);  
		return $http.post('/ccqp-service/app/create.json', applicationReq).
				success(function(data) 
				{
					$rootScope.$broadcast('dialogs.wait.complete');
					return data; 
				}).error(function(data)
				        {
		        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
		        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
		        });
      },
	  getApplication: function(applicationId) 
	  {
		  dialogs.wait(undefined,undefined,100);  
		  return $http.get('/ccqp-service/app/search/'+applicationId+'.json')
	        .success(function(data) 
	        { 
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        }).error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });	  
        
      },
	  updateApplication: function(applicationReq) 
	  {
		  dialogs.wait(undefined,undefined,100); 
          return $http.put('/ccqp-service/app/update.json',applicationReq)
	        .success(function(data)
	        { 
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        }).error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });
		  
      },
      updateOnlyApplication: function(applicationReq) 
	  {
		  dialogs.wait(undefined,undefined,100); 
          return $http.put('/ccqp-service/app/update/application.json',applicationReq)
	        .success(function(data)
	        { 
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        }).error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });
		  
      },
	  startServerApplication: function(appId) 
	  {
		  dialogs.wait(undefined,undefined,100);  
            return $http.post('/ccqp-service/tcp-server/start/'+appId+'.json')
	        .success(function(data)
	        { 
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        }).error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });
		  
      },
      statusServerApplication: function(appId) 
	  {
    	  	dialogs.wait(undefined,undefined,100);  		
    	  
            return $http.get('/ccqp-service/tcp-server/status/'+appId+'.json')
	        .success(function(data)
	        { 
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 	        	
	        }).error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });
		  
      },
      stopServerApplication: function(appId) 
	  {
    	  dialogs.wait(undefined,undefined,100);  
    	  
            return $http.delete('/ccqp-service/tcp-server/stop/'+appId+'.json')
	        .success(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        })
	        .error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 	        	
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });
		  
      },
      getCoverageReportDetail: function() 
	  {
    	  dialogs.wait(undefined,undefined,100);  
            return $http.get('/ccqp-service/app/report-detail.json')
	        .success(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        })
	        .error(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');	 
	        	dialogs.error("Error","Opps!!! Error while processing your request!!!");	        	
	        });
		  
      },
      searchPackages: function(appName) 
	  {
    	    dialogs.wait(undefined,undefined,100);  
            return $http.get('/ccqp-service/app/search/packages/'+appName+'.json')
	        .success(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        });		  
      },
      fetchSessionData: function(appId) 
	  {
    	    dialogs.wait(undefined,undefined,100);  
            return $http.get('/ccqp-service/app/fetch_all_sessions/'+appId+'.json')
	        .success(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        });		  
      },
      createNewSession: function(appId) 
	  {
    	    dialogs.wait(undefined,undefined,100);  
            return $http.get('/ccqp-service/app/start_new_session/'+appId+'.json')
	        .success(function(data)
	        {
	        	$rootScope.$broadcast('dialogs.wait.complete');
	        	return data; 
	        });		  
      },
	}
	
    return factoryDefinitions;
  }
]);

//Controllers
myApp.controller('getApplicationsController', ['$scope', 'applicationServices', 'dataTable', function($scope, applicationServices, dataTable)
{
	applicationServices.getApplications().then(function(result)
	{
		$scope.data = result.data;	
		
		if (!result.data.error)
		{			
			dataTable.render($scope, '', "applicationstList", result.data);
		}		
	});
}]);



myApp.controller('editUploadClassController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$stateParams','$state','dialogs', function($rootScope,$scope, FileUploader, applicationServices, $location,$stateParams,$state,dialogs) 
{
       	
       	$scope.uploadHeader = "Upload Class Files";
       	$scope.nextButtonLabel = "Next Edit Configuration";

       	$scope.uploadEndPoint = null;
       	$scope.isCompleted = false;
       	
       	
       	var uploader = $scope.uploader = new FileUploader({
               url: '/ccqp-service/upload/classes/'+$stateParams.id+'.json'
           });

           // FILTERS

           uploader.filters.push({
               name: 'customFilter',
               fn: function(item /*{File|FileLikeObject}*/, options) {
                   return this.queue.length < 10;
               }
           });

           // CALLBACKS

           uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
               console.log('onWhenAddingFileFailed', item, filter, options);
           };
           uploader.onAfterAddingFile = function(fileItem) {
               console.log('onAfterAddingFile', fileItem);
           };
           uploader.onAfterAddingAll = function(addedFileItems) {
               console.log('onAfterAddingAll', addedFileItems);
           };
           uploader.onBeforeUploadItem = function(item) {
               console.log('onBeforeUploadItem', item);
           };
           uploader.onProgressItem = function(fileItem, progress) {
               console.log('onProgressItem', fileItem, progress);
           };
           uploader.onProgressAll = function(progress) {
               console.log('onProgressAll', progress);
           };
           uploader.onSuccessItem = function(fileItem, response, status, headers) {
               console.log('onSuccessItem', fileItem, response, status, headers);
           };
           uploader.onErrorItem = function(fileItem, response, status, headers) {
               console.log('onErrorItem', fileItem, response, status, headers);
           };
           uploader.onCancelItem = function(fileItem, response, status, headers) {
               console.log('onCancelItem', fileItem, response, status, headers);
           };
           uploader.onCompleteItem = function(fileItem, response, status, headers) {
               console.log('onCompleteItem', fileItem, response, status, headers);
           };
           uploader.onCompleteAll = function() {
               console.log('onCompleteAll');
               $scope.isCompleted = true;
           };

           console.log('uploader', uploader);
           
           $scope.next = function() 
       	{
           	$state.transitionTo('editConfigApplication',
		   {
				id: $stateParams.id
		   });       	   	
           	
       	}
       }]);


myApp.controller('uploadClassController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$stateParams','$state','dialogs', function($rootScope,$scope, FileUploader, applicationServices, $location,$stateParams,$state,dialogs) 
{
	
	$scope.uploadHeader = "Upload Class Files";
	$scope.nextButtonLabel = "Next Add Configuration";

	$scope.uploadEndPoint = null;
	$scope.isCompleted = false;
	
	
	var uploader = $scope.uploader = new FileUploader({
        url: '/ccqp-service/upload/classes/'+$stateParams.id+'.json'
    });

    // FILTERS

    uploader.filters.push({
        name: 'customFilter',
        fn: function(item /*{File|FileLikeObject}*/, options) {
            return this.queue.length < 10;
        }
    });

    // CALLBACKS

    uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
        console.log('onWhenAddingFileFailed', item, filter, options);
    };
    uploader.onAfterAddingFile = function(fileItem) {
        console.log('onAfterAddingFile', fileItem);
    };
    uploader.onAfterAddingAll = function(addedFileItems) {
        console.log('onAfterAddingAll', addedFileItems);
    };
    uploader.onBeforeUploadItem = function(item) {
        console.log('onBeforeUploadItem', item);
    };
    uploader.onProgressItem = function(fileItem, progress) {
        console.log('onProgressItem', fileItem, progress);
    };
    uploader.onProgressAll = function(progress) {
        console.log('onProgressAll', progress);
    };
    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        console.log('onSuccessItem', fileItem, response, status, headers);
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
        console.log('onErrorItem', fileItem, response, status, headers);
    };
    uploader.onCancelItem = function(fileItem, response, status, headers) {
        console.log('onCancelItem', fileItem, response, status, headers);
    };
    uploader.onCompleteItem = function(fileItem, response, status, headers) {
        console.log('onCompleteItem', fileItem, response, status, headers);
    };
    uploader.onCompleteAll = function() {
        console.log('onCompleteAll');
        $scope.isCompleted = true;
    };

    console.log('uploader', uploader);
    
    $scope.next = function() 
	{
    	if($scope.isCompleted)
	   	{
	   	    	$state.transitionTo('configApplication',
			   {
					id: $stateParams.id
			   });
	   	}
	   	else
	   	{
	   		dialogs.error("Error","Please upload classes to continue!!!");
	   	}	
    	
	}
}]);





myApp.controller('uploadSourceController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$stateParams','$state','dialogs', function($rootScope,$scope, FileUploader, applicationServices, $location,$stateParams,$state,dialogs) 
{
	$scope.uploadHeader = "Upload Source Code";
	$scope.nextButtonLabel = "Next Upload Classes";

	$scope.uploadEndPoint = null;
	$scope.isCompleted = false;
	
	var uploader = $scope.uploader = new FileUploader({
        url: '/ccqp-service/upload/source/'+$stateParams.id+'.json'
    });

    // FILTERS

    uploader.filters.push({
        name: 'customFilter',
        fn: function(item /*{File|FileLikeObject}*/, options) {
            return this.queue.length < 10;
        }
    });

    // CALLBACKS

    uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
        console.log('onWhenAddingFileFailed', item, filter, options);
    };
    uploader.onAfterAddingFile = function(fileItem) {
        console.log('onAfterAddingFile', fileItem);
    };
    uploader.onAfterAddingAll = function(addedFileItems) {
        console.log('onAfterAddingAll', addedFileItems);
    };
    uploader.onBeforeUploadItem = function(item) {
        console.log('onBeforeUploadItem', item);
    };
    uploader.onProgressItem = function(fileItem, progress) {
        console.log('onProgressItem', fileItem, progress);
    };
    uploader.onProgressAll = function(progress) {
        console.log('onProgressAll', progress);
    };
    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        console.log('onSuccessItem', fileItem, response, status, headers);
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
        console.log('onErrorItem', fileItem, response, status, headers);
    };
    uploader.onCancelItem = function(fileItem, response, status, headers) {
        console.log('onCancelItem', fileItem, response, status, headers);
    };
    uploader.onCompleteItem = function(fileItem, response, status, headers) {
        console.log('onCompleteItem', fileItem, response, status, headers);
    };
    uploader.onCompleteAll = function() 
    {
        console.log('onCompleteAll');
        $scope.isCompleted= true;
    };

    console.log('uploader', uploader);
    
    $scope.next = function() 
	{
    	
    	if($scope.isCompleted)
    	{
    	    $state.transitionTo('uploadClassApplication',
		   {
				id: $stateParams.id
		   });
    	}
    	else
    	{
    		dialogs.error("Error","Please upload source code to continue!!!");
    	}	
	}
	
}]);



myApp.controller('editUploadSourceController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$stateParams','$state','dialogs', function($rootScope,$scope, FileUploader, applicationServices, $location,$stateParams,$state,dialogs) 
{
	$scope.uploadHeader = "Upload Source Code";
	$scope.nextButtonLabel = "Next Upload Classes";

	$scope.uploadEndPoint = null;
	$scope.isCompleted = false;
	
	var uploader = $scope.uploader = new FileUploader({
        url: '/ccqp-service/upload/source/'+$stateParams.id+'.json'
    });

    // FILTERS

    uploader.filters.push({
        name: 'customFilter',
        fn: function(item /*{File|FileLikeObject}*/, options) {
            return this.queue.length < 10;
        }
    });

    // CALLBACKS

    uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
        console.log('onWhenAddingFileFailed', item, filter, options);
    };
    uploader.onAfterAddingFile = function(fileItem) {
        console.log('onAfterAddingFile', fileItem);
    };
    uploader.onAfterAddingAll = function(addedFileItems) {
        console.log('onAfterAddingAll', addedFileItems);
    };
    uploader.onBeforeUploadItem = function(item) {
        console.log('onBeforeUploadItem', item);
    };
    uploader.onProgressItem = function(fileItem, progress) {
        console.log('onProgressItem', fileItem, progress);
    };
    uploader.onProgressAll = function(progress) {
        console.log('onProgressAll', progress);
    };
    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        console.log('onSuccessItem', fileItem, response, status, headers);
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
        console.log('onErrorItem', fileItem, response, status, headers);
    };
    uploader.onCancelItem = function(fileItem, response, status, headers) {
        console.log('onCancelItem', fileItem, response, status, headers);
    };
    uploader.onCompleteItem = function(fileItem, response, status, headers) {
        console.log('onCompleteItem', fileItem, response, status, headers);
    };
    uploader.onCompleteAll = function() 
    {
        console.log('onCompleteAll');
        $scope.isCompleted= true;
    };

    console.log('uploader', uploader);
    
    $scope.next = function() 
	{
    	
    	$state.transitionTo('editUploadClassApplication',
	   {
			id: $stateParams.id
	   });
    	
	}
	
}]);

myApp.controller('addApplicationConfigController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$stateParams','$state', function($rootScope,$scope, FileUploader, applicationServices, $location,$stateParams,$state) 
{
	
	$scope.configMasterData = [];
	$scope.javaTCTConfig = [];
	
	$scope.packages = [];
	
	$scope.selectedObject = {};	
	$scope.selectedPackages = [];
	$scope.javaTCTConfig.includes = [];
	
	$scope.selectedObject2 = {};	
	$scope.selectedPackages2 = [];
	$scope.javaTCTConfig.excludes = [];
	
	$scope.loadDefaultMasterConfig = function()
	{
		
		applicationServices.getApplication($stateParams.id).then(function(result1)
		{
			$scope.applicationData = result1.data;
			
			applicationServices.getMasterConfigurations($scope.applicationData.strategy).then(function(result)
			{
				$scope.configMasterData = result.data;	
			});
	
			applicationServices.searchPackages($scope.applicationData.appFolderName).then(function(result)
			{
				$scope.packages = result.data;
			});					
		});
	};
	
	
	$scope.$watch('selectedObject', function() 
	{
		if($scope.selectedObject!=null && $scope.selectedObject.originalObject!=null)
		{
			$scope.selectedPackages.push($scope.selectedObject.originalObject.key);			
			$scope.selectedPackages = jQuery.unique($scope.selectedPackages);
			
			$scope.javaTCTConfig.includes=$scope.selectedPackages;
			
			var values = "";
			
			angular.forEach($scope.selectedPackages, function(value, key) 
			{
				values = values + value + ":";
			});
			
			$scope.javaTCTConfig.includes = values.substring(0,values.lastIndexOf(":"));
		}	
		 
	}, true); // watching properties
	
	$scope.remove = function(index) 
	{
		$scope.selectedPackages.splice(index,1);
		
		var values = "";
		
		angular.forEach($scope.selectedPackages, function(value, key) 
		{
			values = values + value + ":";
		});
		
		$scope.javaTCTConfig.includes = values.substring(0,values.lastIndexOf(":"));
    }
	
	
	
		$scope.$watch('selectedObject2', function() 
			{
				if($scope.selectedObject2!=null && $scope.selectedObject2.originalObject!=null)
				{
					$scope.selectedPackages2.push($scope.selectedObject2.originalObject.key);			
					$scope.selectedPackages2 = jQuery.unique($scope.selectedPackages2);
					
					$scope.javaTCTConfig.excludes=$scope.selectedPackages2;
					
					var values = "";
					
					angular.forEach($scope.selectedPackages2, function(value, key) 
					{
						values = values + value + ":";
					});
					
					$scope.javaTCTConfig.excludes = values.substring(0,values.lastIndexOf(":"));
				}	
				 
			}, true); // watching properties
			
			$scope.remove2 = function(index) 
			{
				$scope.selectedPackages2.splice(index,1);
				
				var values = "";
				
				angular.forEach($scope.selectedPackages2, function(value, key) 
				{
					values = values + value + ":";
				});
				
				$scope.javaTCTConfig.excludes = values.substring(0,values.lastIndexOf(":"));
		    }
	
	
	$scope.addApplicationConfig = function() 
	{
	    if ($scope.addApplicationConfigForm.$valid) 
		{	
	    	var configArray = [];
			
			angular.forEach($scope.configMasterData, function(value, key) 
			{
				  configArray.push({config_key:value.key,config_value:$scope.javaTCTConfig[value.key],config_type:value.type})
			});
									
			$scope.applicationData.app_id=$stateParams.id;
			$scope.applicationData.javaTCTConfig = configArray;  	
			  
			applicationServices.updateApplication($scope.applicationData).then(function(result)
			 {
				//$scope.data = result.data;				
				if (!result.data.error) 
				{
					
					applicationServices.startServerApplication($stateParams.id).then(function(result)
					{
						   $state.transitionTo('applications',
						   {
								id: $stateParams.id
						   });	
					});				  
				}
			 });
		}
	};
	
	$scope.cancel = function()
	{
		$location.path("/applications");
	};
	
}]);



myApp.controller('editApplicationConfigController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$stateParams','$state','$parse', function($rootScope,$scope, FileUploader, applicationServices, $location,$stateParams,$state,$parse) 
{
	
	$scope.configMasterData = [];
	$scope.javaTCTConfig = [];
	
	$scope.packages = [];
	$scope.selectedObject = {};	
	$scope.selectedPackages = [];
	
	$scope.selectedObject2 = {};	
	$scope.selectedPackages2 = [];
	
	$scope.loadDefaultMasterConfig = function()
	{
		
		applicationServices.getApplication($stateParams.id).then(function(result1)
		{
			$scope.applicationData = result1.data;
			
			applicationServices.getMasterConfigurations($scope.applicationData.strategy).then(function(result)
			{
				$scope.configMasterData = result.data;				
				
				angular.forEach($scope.configMasterData, function(value1, key1) 
				{
					
					angular.forEach($scope.applicationData.javaTCTConfig, function(value, key) 
					{
						if(value1.key===value.config_key && value1.key=="includes")
						{
							var res = value.config_value.split(":");
							
							for(var i = 0; i < res.length; i++)
							{
								$scope.selectedPackages.push(res[i]);
								$scope.selectedPackages = jQuery.unique($scope.selectedPackages);	
							}
							
							value1.default_value=value.config_value;							
							value1.id=$parse('javaTCTConfig.'+value.config_key);
							value1.id.assign($scope, value.config_value);							
							value1.config_id=value.config_id;
							
						}
						else if(value1.key===value.config_key && value1.key=="excludes")
						{
							var res = value.config_value.split(":");
							
							for(var i = 0; i < res.length; i++)
							{
								$scope.selectedPackages2.push(res[i]);
								$scope.selectedPackages2 = jQuery.unique($scope.selectedPackages2);	
							}
							
							value1.default_value=value.config_value;							
							value1.id=$parse('javaTCTConfig.'+value.config_key);
							value1.id.assign($scope, value.config_value);							
							value1.config_id=value.config_id;
							
						}
						else if(value1.key===value.config_key)
						{
							value1.default_value=value.config_value;							
							value1.id=$parse('javaTCTConfig.'+value.config_key);
							value1.id.assign($scope, value.config_value);	
							value1.config_id=value.config_id;
						}
						
					});	
					
				});				
				
			});
	
			applicationServices.searchPackages($scope.applicationData.appFolderName).then(function(result)
			{
				$scope.packages = result.data;
			});					
		});
	};
	
	
	$scope.$watch('selectedObject', function() 
	{
		if($scope.selectedObject!=null && $scope.selectedObject.originalObject!=null)
		{
			$scope.selectedPackages.push($scope.selectedObject.originalObject.key);			
			$scope.selectedPackages = jQuery.unique($scope.selectedPackages);			
			$scope.javaTCTConfig.includes=$scope.selectedPackages;
			
			var values = "";
			
			angular.forEach($scope.selectedPackages, function(value, key) 
			{
				values = values + value + ":";
			});
			
			$scope.javaTCTConfig.includes = values.substring(0,values.lastIndexOf(":"));
		}	
		 
	}, true); // watching properties
	
	$scope.remove = function(index) 
	{
		$scope.selectedPackages.splice(index,1);
		
		var values = "";
		
		angular.forEach($scope.selectedPackages, function(value, key) 
		{
			values = values + value + ":";
		});
		
		$scope.javaTCTConfig.includes = values.substring(0,values.lastIndexOf(":"));
    }
	
			$scope.$watch('selectedObject2', function() 
			{
				if($scope.selectedObject2!=null && $scope.selectedObject2.originalObject!=null)
				{
					$scope.selectedPackages2.push($scope.selectedObject2.originalObject.key);			
					$scope.selectedPackages2 = jQuery.unique($scope.selectedPackages2);
					
					$scope.javaTCTConfig.excludes=$scope.selectedPackages2;
					
					var values = "";
					
					angular.forEach($scope.selectedPackages2, function(value, key) 
					{
						values = values + value + ":";
					});
					
					$scope.javaTCTConfig.excludes = values.substring(0,values.lastIndexOf(":"));
				}	
				 
			}, true); // watching properties
			
			$scope.remove2 = function(index) 
			{
				$scope.selectedPackages2.splice(index,1);
				
				var values = "";
				
				angular.forEach($scope.selectedPackages2, function(value, key) 
				{
					values = values + value + ":";
				});
				
				$scope.javaTCTConfig.excludes = values.substring(0,values.lastIndexOf(":"));
		    }
	
	
	$scope.editApplicationConfig = function() 
	{
	    if ($scope.editApplicationConfigForm.$valid) 
		{	
	    	
	    	var configArray = [];
			
			angular.forEach($scope.configMasterData, function(value, key) 
			{
				  configArray.push({config_id:value.config_id,config_key:value.key,config_value:$scope.javaTCTConfig[value.key],config_type:value.type})
			});
									
			$scope.applicationData.app_id=$stateParams.id;
			$scope.applicationData.javaTCTConfig = configArray; 	
			  
			applicationServices.updateOnlyApplication($scope.applicationData).then(function(result)
			 {
				//$scope.data = result.data;			
				if (!result.data.error) 
				{
				   $state.transitionTo('applications',
				   {
						id: $stateParams.id
				   });		  
				}
			 });
		}
	};
	
	$scope.cancel = function()
	{
		$location.path("/applications");
	};
	
}]);

myApp.controller('addApplicationController', ['$rootScope','$scope', 'FileUploader','applicationServices', '$location','$state', function($rootScope,$scope, FileUploader, applicationServices, $location,$state) 
{
	$scope.strategiesDefault = 'tcpserver';	
	
	$scope.strategiesData = 
	{
	    repeatSelect: null,
	    availableOptions: 
	    [
	      {id: 'tcpserver', name: 'tcpserver'},
	      {id: 'dme2', name: 'dme2'},
	      {id: 'fusion', name: 'fusion'}
	    ],
	    selectedOption: {id: 'tcpserver', name: 'tcpserver'}
	};
	
	
	$scope.onStrategiesDataChange = function()
	{
		if($scope.strategiesData.selectedOption.name!='tcpserver')
		{
			alert('Only TCPServer strategy supported by JavaTCT as of now!!!!');	
			$scope.strategiesData.selectedOption = {id: 'tcpserver', name: 'tcpserver'};
		}		
	}
	
	
	$scope.addApplication = function() 
	{
	   if ($scope.addApplicationForm.$valid) 
		{	
			$scope.application.strategy =$scope.strategiesData.selectedOption.name;
			
			$scope.application.javaTCTConfig = [];
			
			applicationServices.addApplication($scope.application).then(function(result)
			{
				$scope.data = result;
				
				if (!result.error)
				{	
					$state.transitionTo('uploadSourceApplication',  {id: result.data.status});
				}	
			});
		}
		
	}
	
	$scope.cancel = function()
	{
		$location.path("/applications");
	}
	
}]);

myApp.controller('UploadFileChangesCtrl', ['$rootScope','$scope','applicationServices','$location','$state','$stateParams','$sce','FileUploader', function($rootScope,$scope,applicationServices,$location, $state,$stateParams,$sce,FileUploader) 
{

	$scope.fileUploadProgress = 0;
	$scope.file = '';
	    
	$scope.uploader = new FileUploader({
	    	url: '/ccqp-service/upload/changes/' + $stateParams.id + '.json',
	    	onAfterAddingFile: function(file){
	    		$scope.file = file.file.name;
	    	},
	    	onProgressItem: function(item, progress){
	    		$scope.fileUploadProgress = progress;
	    	},
	    	onCompleteAll: function(){
	    		$scope.file = '';
	    	},
	    	onCompleteItem: function(item, packages){
	    		$scope.packages = packages;
	    	}
	    });
	    
		$scope.upload = function(){
	    	if($scope.uploader.getNotUploadedItems().length > 0) {
	    		$scope.uploader.uploadAll();
	    	}
	    }
	
	
}]);

myApp.controller('viewReportController', ['$rootScope','$scope','applicationServices','$location','$state','$stateParams','$sce','$modal', function($rootScope,$scope,applicationServices,$location, $state,$stateParams,$sce,$modal) 
{
	$scope.headerName="Code Coverage Report";
	$scope.detailFrame = null;
	
	$scope.sessionsData = 
	{
	    repeatSelect: null,
	    availableOptions: null
	};
	
	$scope.onSessionsDataChange = function()
	{
		var link = $scope.report_server_host+"/"+$scope.sessionsData.selectedOption.key;				
		$scope.detailFrame = $sce.trustAsResourceUrl(link);		
	}
	
	$scope.createNewSession = function()
	{
		applicationServices.createNewSession($stateParams.id).then(function(result1)
		{
			if (!result1.data.error)
			{			
				$scope.create_new_session = result1.data.exception;
				
				applicationServices.fetchSessionData($stateParams.id).then(function(result2)
				{
					if (!result2.data.error)
					{			
						$scope.sessionsData.availableOptions = result2.data;			
						$scope.sessionsData.selectedOption = {key:$scope.create_new_session,value:$scope.create_new_session};
						
						applicationServices.getCoverageReportDetail().then(function(result3)
						{
							$scope.report_server_host = result3.data.java_tct_report_server_address;							
							var link = $scope.report_server_host+"/"+$scope.create_new_session;				
							$scope.detailFrame = $sce.trustAsResourceUrl(link);
						});
					}		
				});				
			}		
		});	
	}
	
	$scope.uploadFileChanges = function(){
    	$modal.open({
            templateUrl: 'partials/applications/uploadFileChangesModel.html',
            controller: 'UploadFileChangesCtrl',
            windowClass: 'modal-lg',
            resolve: {
            	app_id: function($stateParams)
            	{
            		return $stateParams.id;
            	}
            }
        });
    }
	
		
	applicationServices.fetchSessionData($stateParams.id).then(function(result1)
	{
		if (!result1.data.error)
		{			
			$scope.sessionsData.availableOptions = result1.data;			
			$scope.sessionsData.selectedOption = result1.data[0];
			
			applicationServices.getCoverageReportDetail().then(function(result2)
			{
				$scope.report_server_host = result2.data.java_tct_report_server_address;
				
				var link = $scope.report_server_host+"/"+$scope.sessionsData.selectedOption.key;				
				$scope.detailFrame = $sce.trustAsResourceUrl(link);	
			});
		}		
	});	
	
	
	
	$scope.refresh = function()
   	{
		 var iFrame = $("#reportIframe");
		 iFrame.attr("src",iFrame.attr("src"));
    }
	
	$scope.cancel = function()
   	{
   		$location.path("/applications");
    }
	
}]);

myApp.controller('viewApplicationController', ['$rootScope','$scope','applicationServices', 'applicationResolved','$location','$state','$stateParams','$timeout','dialogs', function($rootScope,$scope,applicationServices, applicationResolved,$location, $state,$stateParams,$timeout,dialogs) 
{
	
	
	
	$scope.server_status = "STOPPED";
	$("#tcp_server_start").hide();
	$("#tcp_server_stop").hide();
	
	
	
	$scope.viewApplication = applicationResolved.data;
		
	$scope.cancel = function() 
	{
		$location.path("/applications");
    }
	
	
	
	applicationServices.statusServerApplication($stateParams.id).then(function(result)
	{
		if(result.data.message=="success" && result.data.exception=="NOT-RUNNING")
		{
			$("#tcp_server_start").show();
			$("#tcp_server_stop").hide();
		}
		else if(result.data.message=="success" && result.data.exception=="NOT-FOUND")
		{
			$("#tcp_server_start").hide();
			$("#tcp_server_stop").hide();
		}
		else
		{
			$("#tcp_server_start").hide();
			$("#tcp_server_stop").show();
		}		
		
		$rootScope.$broadcast('dialogs.wait.complete');
	});	
	
	$scope.tcpServer = function(name) 
	{	
		applicationServices.statusServerApplication($stateParams.id).then(function(result)
		{
			
			if("start"==name)
			{
				
				if(result.data.exception=="RUNNING")
				{
					dialogs.error("Error","Server is already running! Please stop server first");
					$("#tcp_server_start").show();
					$("#tcp_server_stop").hide();
				}
				else
				{
					applicationServices.startServerApplication($stateParams.id).then(function(result)
					{
						console.log(result);
						$("#tcp_server_start").hide();
						$("#tcp_server_stop").show();					
					});
				}
				
			} 
			else if("stop"==name)
			{
			
				if(result.data.exception!="RUNNING")
				{
					dialogs.error("Error","Server is not running! Please start server first");
					$("#tcp_server_start").hide();
					$("#tcp_server_stop").show();
				}
				else
				{
					
					var dlg = dialogs.confirm('Message','Stopping TCP-SERVER is not recommended because TCP-CLIENT will loose connection and you will have to bounce the TCP-CLIENT SERVER to make connection again.');
					dlg.result.then(function(btn)
					{
						applicationServices.stopServerApplication($stateParams.id).then(function(result)
						{
							$("#tcp_server_start").show();
							$("#tcp_server_stop").hide();
						});
					},
					function(btn)
					{
						
					});			
					
				}				
			}
			
		});			
    };
    
    $scope.restapis = $location.host()+":"+$location.port()+"/ccqp-service/app/download/agent.json\n"+$location.host()+":"+$location.port()+"/ccqp-service/app/download/agent-properties/"+$stateParams.id+".json";
    
    $scope.downloadAgent = function(appId)
	{
    	window.open("/ccqp-service/app/download/agent");
	};
	
	$scope.downloadAgentProperties = function(appId) 
	{
    	window.open("/ccqp-service/app/download/agent-properties/"+appId+".json");
	};
	
}]);

myApp.controller('viewApplicationConfigController', ['$scope', 'applicationServices', 'dataTable','$location','$state','$stateParams', function($scope, applicationServices, dataTable,$location, $state,$stateParams) 
{
    applicationServices.getConfigurations($stateParams.id).then(function(result)
	{
		$scope.data = result.data.javaTCTConfig;
		
		if (!result.data.error)
		{			
			dataTable.render($scope, '', "configtList", result.data.javaTCTConfig);
		}			
	});
	
   		
   	$scope.cancel = function()
   	{
   		$location.path("/applications");
    }
                                               	
}]);

myApp.controller('editApplicationController', ['$scope', 'applicationServices', '$location', '$state','$stateParams', function($scope, applicationServices, $location, $state,$stateParams) 
{
 
	applicationServices.getApplication($stateParams.id).then(function(result1)
	{
		$scope.application = result1.data;
	});
	
	$scope.editApplication = function() 
	{
	   if ($scope.editApplicationForm.$valid) 
		{	
			$scope.application.javaTCTConfig = [];
			
			applicationServices.updateOnlyApplication($scope.application).then(function(result)
			{
				$scope.data = result;
				
				if (!result.error)
				{	
					$state.transitionTo('editUploadSourceApplication',  {id: $stateParams.id});
				}	
			});
		}
		
	}
	
	$scope.cancel = function()
	{
		$location.path("/applications");
	}
	
 
}]);