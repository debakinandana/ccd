'use strict';

angular.module('dashboard', []);

//Routers
myApp.config(function($stateProvider) {
  $stateProvider.state('dashboard', {
	url: '/dashboard',
    templateUrl: 'partials/dashboard/exec-dashboard.html',
	data:{
		auth:true
	}
  });
  
});

//Factories
myApp.factory('dashboardServices', ['$http', function($http) 
{

    var factoryDefinitions = 
    {
      getOverAllStats: function() 
      {
        return $http.get('/ccqp-service/app/dashboard/overall.json').success(function(data) { return data; });
      },
      getTodaysStats:function () 
      {
          return $http.get('partials/dashboard/mock/todays_stats.json').success(function (data) { return data; });
      },
      getRecentNews:function () 
      {
          return $http.get('partials/dashboard/mock/recent_news.json').success(function (data, status, headers, config) {              return data;          });
      },
      getLastFiveApplications:function () 
      {
          return $http.get('partials/dashboard/mock/applications_last_five.json').success(function (data) { return data;          });
      }
	}
	
    return factoryDefinitions;
  }
]);




//Controllers
myApp.controller('overAllStatsController', ['$scope', 'dashboardServices', function($scope, dashboardServices) 
{
	dashboardServices.getOverAllStats().then(function(result)
	{
		$scope.data = result.data;	
	});
}]);



//Controllers
myApp.controller('getLastFiveApplicationsController', ['$scope', 'dashboardServices', function($scope, dashboardServices) 
{
	dashboardServices.getLastFiveApplications().then(function (result) {
        $scope.data = result.data;
    });
}]);

//Controllers
myApp.controller('recentNewsController', ['$scope', 'dashboardServices', function($scope, dashboardServices) 
{
	dashboardServices.getRecentNews().then(function (result) {
        $scope.data = result.data;
    });
}]);

//Controllers
myApp.controller('todaysStatsController', ['$scope', 'dashboardServices', function($scope, dashboardServices) 
{
	dashboardServices.getTodaysStats().then(function (result) {
        $scope.data = result.data;
    });
}]);
