package com.att.tta.ccqp.timer;

import java.util.TimerTask;

public class CloseConnections extends TimerTask
{
	
	
	
	public void run() 
	{
		
	}
}