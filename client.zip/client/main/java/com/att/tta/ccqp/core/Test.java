package com.att.tta.ccqp.core;

import java.io.IOException;

import com.att.tta.ccqp.util.ConfigUtils;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		ReportGenerator.main(new String[] {ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant"),"true"});
	}

}
