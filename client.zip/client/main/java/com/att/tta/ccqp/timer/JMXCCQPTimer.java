package com.att.tta.ccqp.timer;

import java.io.FileOutputStream;
import java.util.TimerTask;

import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.att.tta.ccqp.core.ReportGenerator;
import com.att.tta.ccqp.util.ConfigUtils;

public class JMXCCQPTimer extends TimerTask
{
		private String SERVICE_URL= ConfigUtils.getInstance().getConfigProp().getProperty("jmx_url");
		private String HOST = ConfigUtils.getInstance().getConfigProp().getProperty("tcpserver");
		private String PORT = ConfigUtils.getInstance().getConfigProp().getProperty("jmx_port");
		
	
		public JMXCCQPTimer()
		{
			System.out.println("started ccqp jmx connections!!!!");	
		}	
		
		
		class CloseConnections extends TimerTask
		{
			public void run() 
			{
				try 
				{
					System.out.println("CCQP jmx Client Stopped!!!");
					
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}				
			}
		}
	
	
	  public void run()
	  {
		 
		try 
		{
			synchronized (this) 
			{
				FileOutputStream localFile = null;
				JMXConnector jmxc =null;
				
				try
				{
					// Open connection to the coverage agent:
					JMXServiceURL url = new JMXServiceURL(SERVICE_URL.replace("_HOST_", HOST).replace("_PORT_", PORT));
					jmxc = JMXConnectorFactory.connect(url, null);
					MBeanServerConnection connection = jmxc.getMBeanServerConnection();
		
					IProxy proxy = (IProxy) MBeanServerInvocationHandler.newProxyInstance(connection, new ObjectName("org.jacoco:type=Runtime"),IProxy.class, false);
		
					// Retrieve JaCoCo version and session id:
					System.out.println("Version: " + proxy.getVersion());
					System.out.println("Session: " + proxy.getSessionId());
		
					// Retrieve dump and write to file:
					byte[] dump = proxy.getExecutionData(false);
					localFile = new FileOutputStream(ConfigUtils.appendParentPath(ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant"),ConfigUtils.getInstance().getConfigProp().getProperty("data_file")));
					localFile.write(dump);					
				}
				finally
				{
					localFile.close();
					// Close connection:
					jmxc.close();
				}
				
				ReportGenerator.main(new String[] {ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")});	
			}	
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
				
	  }
	  
	  
	  private interface IProxy 
		{
			String getVersion();

			String getSessionId();

			void setSessionId(String id);

			byte[] getExecutionData(boolean reset);

			void reset();
		}
	
}
