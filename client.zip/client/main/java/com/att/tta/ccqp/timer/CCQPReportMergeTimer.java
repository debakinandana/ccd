package com.att.tta.ccqp.timer;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.TimerTask;

import org.apache.commons.io.FileUtils;
import org.apache.tools.ant.types.resources.FileResource;
import org.jacoco.ant.MergeTask;

import com.att.tta.ccqp.core.ReportGenerator;
import com.att.tta.ccqp.util.ConfigUtils;

public class CCQPReportMergeTimer extends TimerTask
{
	
		public CCQPReportMergeTimer()
		{
			
		}
	
	  public void run()
	  {
		 
		try 
		{
			synchronized (this) 
			{
				MergeTask mergeTask = new MergeTask();
				mergeTask.setDescription("JavaTCT_Merge_Report");
				
				String destFilePath = ConfigUtils.getInstance().appendParentPath(ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant"),ConfigUtils.getInstance().getConfigProp().getProperty("data_file"));
				
				
				if(new File(destFilePath).exists())
				{
					new File(destFilePath).delete();
				}
				
				
				mergeTask.setDestfile(new File(destFilePath));	
				
				String parentToFindExecFiles = (String) ConfigUtils.getInstance().getConfigProp().get("ccqp_merger_parent");
				System.out.println("Root Folder to search for .exec files" + parentToFindExecFiles);
								
				final String[] SUFFIX = {"exec"};  // use the suffix to filter

			    File rootDir = new File(parentToFindExecFiles);

			    Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, true);
				
				for (Iterator iterator = files.iterator(); iterator.hasNext();) 
				{
					File file = (File) iterator.next();					
					FileResource fileResource= new FileResource(file);	
					mergeTask.addConfigured(fileResource);	
				}
								
				mergeTask.execute();	
				
				ReportGenerator.main(new String[] {ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")});	
			}						
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
				
	  }
	
}
