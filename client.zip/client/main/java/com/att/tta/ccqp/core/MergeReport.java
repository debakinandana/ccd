package com.att.tta.ccqp.core;

import com.att.tta.ccqp.timer.CCQPReportMergeTimerScheduler;


public class MergeReport {

	public static void main(String[] args)
	{
	
		CCQPReportMergeTimerScheduler.initialize();
		
	}

}
