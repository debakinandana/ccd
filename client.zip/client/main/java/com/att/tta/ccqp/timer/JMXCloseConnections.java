package com.att.tta.ccqp.timer;

import java.util.TimerTask;

public class JMXCloseConnections extends TimerTask
{
	public void run() 
	{
		
	}
}