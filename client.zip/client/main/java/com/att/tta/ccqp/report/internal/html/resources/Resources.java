package com.att.tta.ccqp.report.internal.html.resources;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.jacoco.report.internal.ReportOutputFolder;

public class Resources extends org.jacoco.report.internal.html.resources.Resources {

    private final ReportOutputFolder folder;

    /**
     * Attaches resources to the report with the given root folder.
     * 
     * @param root
     *            root folder of the report
     */
    public Resources(final ReportOutputFolder root) {
	super(root);
	folder = root.subFolder(".resources");
    }

    /**
     * Returns a relative link to a static resource.
     * 
     * @param base
     *            base folder from where the link should be created
     * @param name
     *            name of the static resource, see constants in this class
     * @return relative link
     */
    @Override
    public String getLink(final ReportOutputFolder base, final String name) {
	return folder.getLink(base, name);
    }

    /**
     * Copies all static resources into the report.
     * 
     * @throws IOException
     *             if the resources can't be written to the report
     */
    @Override
    public void copyResources() throws IOException {
	copyResource(STYLESHEET);
	copyResource("report.gif");
	copyResource("group.gif");
	copyResource("bundle.gif");
	copyResource("package.gif");
	copyResource("source.gif");
	copyResource("class.gif");
	copyResource("method.gif");
	copyResource("session.gif");
	copyResource("sort.gif");
	copyResource("up.gif");
	copyResource("down.gif");
	copyResource("branchfc.gif");
	copyResource("branchnc.gif");
	copyResource("branchpc.gif");
	copyResource(REDBAR);
	copyResource(GREENBAR);
	copyResource(PRETTIFY_STYLESHEET);
	copyResource(PRETTIFY_SCRIPT);
	copyResource(SORT_SCRIPT);
    }

    private void copyResource(final String name) throws IOException {
	final InputStream in = Resources.class.getResourceAsStream(name);
	final OutputStream out = folder.createFile(name);
	final byte[] buffer = new byte[256];
	int len;
	while ((len = in.read(buffer)) != -1) {
	    out.write(buffer, 0, len);
	}
	in.close();
	out.close();
    }

}
