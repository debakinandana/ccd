package com.att.tta.ccqp.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.att.tta.ccqp.util.ConfigUtils;



public class CCQPJMXClient 
{

	private CCQPJMXClient() 
	{
		
	}		

	private static final String SERVICE_URL = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_jmx_url");

	/**
	 * Execute the example.
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(final String[] args) throws Exception 
	{
		// Open connection to the coverage agent:
		JMXServiceURL url = new JMXServiceURL(SERVICE_URL.replace("_HOST_", ConfigUtils.getInstance().getConfigProp().getProperty("tcpserver")).replace("_PORT_", ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_jmx_port")));
		JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
		MBeanServerConnection connection = jmxc.getMBeanServerConnection();
		
		IProxy proxy = (IProxy) MBeanServerInvocationHandler.newProxyInstance(connection, new ObjectName("com.tta.ccqp.jmx:type=CCQPManager"),IProxy.class, false);

		List<String> params = new ArrayList<String>();
		
		System.out.println(proxy.getCCQPConfigurations());
		System.out.println(proxy.disableCCQP(params));
		System.out.println(proxy.enableCCQP(params));
		System.out.println(proxy.bounceServer(params));
		
		for(String value: proxy.listAllLoadedClass())
		{
			if(value.startsWith("amdocs."))
			System.out.println(value);
		}
		
		jmxc.close();
	}

	private interface IProxy 
	{
		
		public Map<String,String> getCCQPConfigurations();
		public String enableCCQP(List<String> params);
		public String disableCCQP(List<String> params);
		public List<String> listAllLoadedClass();
		public String bounceServer(List<String> params);
	}
	
	
	
}
