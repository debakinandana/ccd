package com.att.tta.ccqp.core;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.tools.ant.types.resources.FileResource;
import org.jacoco.core.data.ExecutionDataWriter;
import org.jacoco.core.data.SessionInfo;
import org.jacoco.core.tools.ExecFileLoader;

import com.att.tta.ccqp.util.ConfigUtils;
import com.att.tta.ccqp.util.MergeTask;

public class MergeTest
{
	
	
	private static Logger logger = Logger.getLogger(MergeTest.class);
	
	private static String  home = "C:\\Users\\GS495A\\Documents\\download\\JavaTCT";
	private static final String ccqp_parent = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant");	
	private static final String merge_exec_location = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")+System.getProperty("file.separator")+"tmp";
	private static final String temp_file_location = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")+System.getProperty("file.separator")+"tmp";
	private static String merge_file_name = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")+System.getProperty("file.separator")+ConfigUtils.getInstance().getConfigProp().getProperty("data_file");
	private static String server_merge = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")+System.getProperty("file.separator")+"server_merge.exec";
	private static String server_merge2 = home+System.getProperty("file.separator")+"/old/server_merge.exec";
	
	
	public static void main2(String[] args) throws Exception
	{
		
		byte[] bytes2 = FileUtils.readFileToByteArray(new File(server_merge));	
		
		for (byte b : bytes2) 
		{
			System.out.print( (char) b);
		}
		
		
		/*
		for (byte b : bytes) 
		{
			
			if(!Character.valueOf((char) b).equals(""))
			{
				System.out.println(Character.valueOf((char) b));
			}
			
		}
		*/
		
		
		
		/*
		String s = new String(bytes).trim();
	    	    
	    new FileOutputStream(server_merge,true).write(s.getBytes());
	    
	    readOneByte(server_merge);
	    
	    System.out.println(new String(fileWriter.getFileHeader()));
	    */
	    
		/*
		
		SessionInfo info = new SessionInfo("dummay", new Date().getTime(), new Date().getTime());		
		ExecutionDataWriter fileWriter = new ExecutionDataWriter( new FileOutputStream(server_merge));
		fileWriter.visitSessionInfo(info);
		
		fileWriter.flush();
		
		ExecutionDataReader dataReader = new ExecutionDataReader(new FileInputStream(server_merge));		
		dataReader.read();		
		
		
		
		final String[] SUFFIX = {"exec"};  // use the suffix to filter								
	    File rootDir = new File(server_merge);
	    @SuppressWarnings("unchecked")
		Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, false);		    
	    
		for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) 
		{
			File file = iterator.next();
			
			readOneByte(file.getPath());
		}
		*/
		
	}

	
	
	public static void main(String[] args) throws Exception
	{
		SessionInfo info = new SessionInfo("dummay", new Date().getTime(), new Date().getTime());		
		ExecutionDataWriter fileWriter = new ExecutionDataWriter( new FileOutputStream(server_merge));
		fileWriter.visitSessionInfo(info);
				
		fileWriter.flush();		
		
		byte[] bytes2 = FileUtils.readFileToByteArray(new File(server_merge));	
		byte[] bytes = FileUtils.readFileToByteArray(new File(server_merge2));	
		
		DataOutputStream w = new DataOutputStream(new FileOutputStream(server_merge));
		w.write(bytes2);
		w.write(new String(bytes).trim().getBytes());
		w.flush();
		w.close();
	    
		logger.info("Reader Called!!!!Merging and Generating report!!!");
		
		File tempFolder = new File(temp_file_location);
		
		if(tempFolder!=null && tempFolder.exists() && tempFolder.isDirectory() && tempFolder.list().length > 0)
		{
			//merge from tmp to parent directory
			//mergeDataFile(merge_file_name, merge_exec_location, new ArrayList<String>());							
			
			
			List<String> ignoreList = new ArrayList<String>();
			final String[] SUFFIX = {"exec"};  // use the suffix to filter								
		    File rootDir = new File(ccqp_parent);
		    @SuppressWarnings("unchecked")
			Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, false);		    
		    
			for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) 
			{
				File file = iterator.next();
				
				if(file.getName().startsWith("new_session_"))
				{
					ignoreList.add(file.getName());
				}
			}
			
			//merge everything in parent directory to merge file
			mergeDataFile(server_merge, ccqp_parent, ignoreList);
			ReportGenerator.main(new String[] {ccqp_parent,ConfigUtils.getInstance().getConfigProp().getProperty("merge_data_file"),ConfigUtils.getInstance().getConfigProp().getProperty("server_merge_sessionid")});
											
			
			for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) 
			{
				//now look for any new session files
				ignoreList = new ArrayList<String>();		
				
				File file = iterator.next();
				
				if(file.getName().startsWith("jacoco_client") || file.getName().startsWith("server_merge"))
				{
					continue;
				}
					
				
				if(file.getName().startsWith("new_session"))
				{
					for (Iterator<File> iterator2 = files.iterator(); iterator2.hasNext();) 
					{
						File file2 = iterator2.next();
						
						if(file.getName().startsWith("jacoco_client"))
						{
							continue;
						}											
						else if(file2.getName().startsWith("server_merge"))
						{
							ignoreList.add(file2.getName());	
						}
						else if(!file.getName().equals(file2.getName()))
						{
							ignoreList.add(file2.getName());																							
						}											
					}
					
					mergeDataFile(file.getPath(), ccqp_parent, ignoreList);
					ReportGenerator.main(new String[] {ccqp_parent,file.getName(),file.getName()});
				}
			}
		}
	}
	
	
	public static void mergeDataFile(String destFile, String mergeLocationExec, List<String> ignoreFileList) throws IOException
	{
		MergeTask mergeTask = new MergeTask();
		mergeTask.setDescription("JavaTCT_Merge_Report");			
		
		File destFileObject = new File(destFile);	
		
		if(!destFileObject.exists())
		{
			destFileObject.createNewFile();
		}		
		
		mergeTask.setDestfile(destFileObject);
	    ExecFileLoader execFileLoader = null;		    
	    
	    int count = 0;			
	   
    	logger.info("Root Folder to search for .exec files" + mergeLocationExec);
		
		final String[] SUFFIX = {"exec"};  // use the suffix to filter
		
	    File rootDir = new File(mergeLocationExec);

	    @SuppressWarnings("unchecked")
		Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, true);		    
	    
		for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) 
		{
			File file = iterator.next();
			
			if(ignoreFileList.contains(file.getName()))
			{
				continue;
			}
			
			execFileLoader = new ExecFileLoader();				
			execFileLoader.load(file);
			
			if(execFileLoader.getSessionInfoStore().getInfos().size() > 0 &&
			   execFileLoader.getExecutionDataStore().getContents().size() > 0)
			{	
				FileResource fileResource= new FileResource(file);				
				mergeTask.addConfigured(fileResource);
				++count;
			}		
		}
		
		if(count> 0)
		{
			mergeTask.execute(false);
		}
	}
	
	public static void readOneByte(String filePath) throws FileNotFoundException
	{
	    FileInputStream file = null;
	    byte x = -1;
	    
	    try 
	    {
	      file = new FileInputStream(filePath);
	      
	      x = (byte) file.read();
	      
	      System.out.println(x);
	      
	    } 
	    catch (FileNotFoundException f) 
	    {
	      throw f;
	    } 
	    catch (IOException i) 
	    {
	      i.printStackTrace();
	    } 
	    finally 
	    {
	      try
	      {
	        if (file != null) 
	        {
	          file.close();
	        }
	      } 
	      catch (IOException e) 
	      {
	      }
	    }
	  }
}
	
