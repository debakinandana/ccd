package com.att.tta.ccqp.core;

import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.log4j.Logger;
import org.jacoco.core.analysis.Analyzer;
import org.jacoco.core.analysis.CoverageBuilder;
import org.jacoco.core.analysis.IBundleCoverage;
import org.jacoco.core.data.ExecutionData;
import org.jacoco.core.data.SessionInfo;
import org.jacoco.core.tools.ExecFileLoader;
import org.jacoco.report.DirectorySourceFileLocator;
import org.jacoco.report.FileMultiReportOutput;
import org.jacoco.report.IReportVisitor;
import org.jacoco.report.MultiSourceFileLocator;
import org.jacoco.report.csv.CSVFormatter;
import org.jacoco.report.xml.XMLFormatter;

import com.att.tta.ccqp.report.html.HTMLFormatter;
import com.att.tta.ccqp.util.ConfigUtils;

public class ReportGenerator 
{
	
	private static Logger logger = Logger.getLogger(ReportGenerator.class);
	
	private final String title;

	private final File executionDataFile;
	private final File classesDirectory;
	//private final File classesOriginalDirectory;
	private final File sourceDirectory;	
	private final  List<String> sources = new ArrayList<String>();	
	private final File reportDirectory;
	private ExecFileLoader execFileLoader;	
	

	/**
	 * Create a new generator based for the given project.
	 * 
	 * @param projectDirectory
	 */
	public ReportGenerator(final String[] args) 
	{
		
		File projectDirectory = new File(args[0]);		
		this.title = projectDirectory.getName();		
		this.executionDataFile = new File(projectDirectory, args[1]);
		
		
		this.classesDirectory = new File(projectDirectory, ConfigUtils.getInstance().getConfigProp().getProperty("classes_directory"));
		this.sourceDirectory = new File(projectDirectory, ConfigUtils.getInstance().getConfigProp().getProperty("source_directory"));
		
		try 
		{
			
			File[] subdirs = this.sourceDirectory.listFiles((FileFilter) DirectoryFileFilter.DIRECTORY);
			
			if(subdirs!=null)
			{
				for (File dir : subdirs) 
				{
					sources.add(dir.getCanonicalPath());
				}
			}
		}
		catch (Exception e) 
		{
			logger.info("Exception: "+ args.toString());
			e.printStackTrace();
		}
		
		this.reportDirectory = new File(ConfigUtils.appendParentPath(ConfigUtils.getInstance().getConfigProp().getProperty("coverage_report"),args[2]));
			
	}

	/**
	 * Create the report.
	 * 
	 * @throws IOException
	 */
	public void create() throws IOException {

		// Read the jacoco.exec file. Multiple data files could be merged
		// at this point
		loadExecutionData();

		// Run the structure analyzer on a single class folder to build up
		// the coverage model. The process would be similar if your classes
		// were in a jar file. Typically you would create a bundle for each
		// class folder and each jar you want in your report. If you have
		// more than one bundle you will need to add a grouping node to your
		// report
		final IBundleCoverage bundleCoverage = analyzeStructure();
		createReport(bundleCoverage);
	}
	
	private MultiSourceFileLocator sourceFolders() 
	{ 
	    MultiSourceFileLocator multiSourceFileLocator = new MultiSourceFileLocator(2); 
	    
	    for (Object sourceFolder : sources.toArray()) 
	    { 
	      multiSourceFileLocator.add(new DirectorySourceFileLocator(new File(sourceFolder.toString()), "utf-8", 2)); 
	    } 
	    
	    return multiSourceFileLocator; 
	  }
	
	private List<SessionInfo> getUniqueSessionInfo(List<SessionInfo> info)
	{
		Collections.sort(info);	
		
		List<SessionInfo> local = new ArrayList<SessionInfo>();
		Set<String> uniqueids = new HashSet<String>();
		
				
		
		for (SessionInfo sessionInfo : info) 
		{
			uniqueids.add(sessionInfo.getId());		
		}
		
		for (String uniqueid : uniqueids) 
		{
			List<Long> tempLong = new ArrayList<Long>(); 
			
			for (SessionInfo sessionInfo : info) 
			{
				if(sessionInfo.getId().equals(uniqueid))
				{
					tempLong.add(sessionInfo.getDumpTimeStamp());					
				}						
			}
			
			Long max = Collections.max(tempLong);
			
			List<String> duplicate = new ArrayList<String>();
			
			for (SessionInfo sessionInfo : info) 
			{
				if(!duplicate.contains(sessionInfo.getId()+""+sessionInfo.getDumpTimeStamp()) && sessionInfo.getId().equals(uniqueid) && max==sessionInfo.getDumpTimeStamp())
				{
					duplicate.add(sessionInfo.getId()+""+sessionInfo.getDumpTimeStamp());					
					local.add(sessionInfo);		
				}						
			}			
			
		}
		
		
		return local;
	}

	
	private Collection<ExecutionData> getUniqueExecutionData(Collection<ExecutionData> temp)
	{
		
		Collection<ExecutionData> tempCollection = new ArrayList<ExecutionData>();
		
		for (ExecutionData executionData : temp) 
		{
			if(!executionData.getName().contains("EnhancerByCGLIB") && !executionData.getName().contains("FastClassByCGLIB"))
			{
				tempCollection.add(executionData);
			}
			
		}
		
		return tempCollection;		
	}
	
	
	
	private void createReport(final IBundleCoverage bundleCoverage) throws IOException 
	{

		// Create a concrete report visitor based on some supplied
		// configuration. In this case we use the defaults
		final HTMLFormatter htmlFormatter = new HTMLFormatter();
		final XMLFormatter xmlFormatter = new XMLFormatter();
		final CSVFormatter csvFormatter = new CSVFormatter();
		
		final IReportVisitor visitor = htmlFormatter.createVisitor(new FileMultiReportOutput(reportDirectory));
		
		final IReportVisitor visitor2 = xmlFormatter.createVisitor(new FileOutputStream(reportDirectory+File.separator+"xml_report.xml"));
		
		final IReportVisitor visitor3 = csvFormatter.createVisitor(new FileOutputStream(reportDirectory + File.separator + "csv_report.csv"));

		// Initialize the report with all of the execution and session
		// information. At this point the report doesn't know about the
		// structure of the report being created
		
		//System.out.println(execFileLoader.getSessionInfoStore().getInfos());
		//System.out.println(execFileLoader.getExecutionDataStore().getContents());		
		
		List<SessionInfo> tempInfo= getUniqueSessionInfo(execFileLoader.getSessionInfoStore().getInfos());
		visitor.visitInfo(tempInfo,getUniqueExecutionData(execFileLoader.getExecutionDataStore().getContents()));
		visitor2.visitInfo(tempInfo,getUniqueExecutionData(execFileLoader.getExecutionDataStore().getContents()));
		visitor3.visitInfo(tempInfo, getUniqueExecutionData(execFileLoader.getExecutionDataStore().getContents()));
		
		try
		{
			logger.info("Available data size: " + execFileLoader.getExecutionDataStore().getContents().size());
		}
		catch(Exception e)
		{
			logger.info("Exeption : "+e);
			e.printStackTrace();
		}
		
		// Populate the report structure with the bundle coverage information.
		// Call visitGroup if you need groups in your report.
		visitor.visitBundle(bundleCoverage, sourceFolders());
		visitor2.visitBundle(bundleCoverage, sourceFolders());
		visitor3.visitBundle(bundleCoverage, sourceFolders());

		// Signal end of structure information to allow report to write all
		// information out
		visitor.visitEnd();
		visitor2.visitEnd();
		visitor3.visitEnd();

	}

	private void loadExecutionData() throws IOException 
	{
		execFileLoader = new ExecFileLoader();
		execFileLoader.load(executionDataFile);
	}

	private IBundleCoverage analyzeStructure() throws IOException 
	{
		final CoverageBuilder coverageBuilder = new CoverageBuilder();
		final Analyzer analyzer = new Analyzer(execFileLoader.getExecutionDataStore(), coverageBuilder);

		analyzer.analyzeAll(classesDirectory);		
		return coverageBuilder.getBundle(title);
	}

	/**
	 * Starts the report generation process
	 * 
	 * @param args
	 *            Arguments to the application. This will be the location of the
	 *            eclipse projects that will be used to generate reports for
	 * @throws IOException
	 */
	public static void main(final String[] args) throws IOException 
	{
		if(args!=null && args.length >= 3)
		{		
			logger.info("Generating report for: "+ Arrays.asList(args).toString());
			
			try
			{
				final ReportGenerator generator = new ReportGenerator(args);
				generator.create();
			}
			catch(Exception e)
			{
				logger.error("Error while generating report for "+Arrays.asList(args).toString());
				e.printStackTrace();
			}
		}
		
	}
}
