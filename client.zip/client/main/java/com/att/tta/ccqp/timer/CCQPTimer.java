package com.att.tta.ccqp.timer;

import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.TimerTask;

import org.jacoco.core.data.ExecutionDataWriter;
import org.jacoco.core.runtime.RemoteControlReader;
import org.jacoco.core.runtime.RemoteControlWriter;

import com.att.tta.ccqp.core.ReportGenerator;
import com.att.tta.ccqp.util.ConfigUtils;

public class CCQPTimer extends TimerTask
{
	
		public CCQPTimer()
		{
			System.out.println("starting ccqp socket connections!!!!");	
			Runtime.getRuntime().addShutdownHook(new Thread(new CloseConnections()));
		}	
		
		
		class CloseConnections extends TimerTask
		{
			public void run() 
			{
				try 
				{
					System.out.println("CCQP Client Stopped!!!");					
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}				
			}
		}
	
	
	  public void run()
	  {
		 
		try 
		{
			synchronized (this) 
			{
				Socket socket = null;
				ExecutionDataWriter localWriter=null;
				FileOutputStream localFile=null;
				
				try
				{
					localFile = new FileOutputStream(ConfigUtils.appendParentPath(ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant"),ConfigUtils.getInstance().getConfigProp().getProperty("data_file")));
					localWriter = new ExecutionDataWriter(localFile);
					// Open a socket to the coverage agent:
					socket = new Socket(InetAddress.getByName(ConfigUtils.getInstance().getConfigProp().getProperty("tcpserver")), Integer.valueOf(ConfigUtils.getInstance().getConfigProp().getProperty("tcpport")));
								
					RemoteControlWriter writer = new RemoteControlWriter(socket.getOutputStream());
					RemoteControlReader reader = new RemoteControlReader(socket.getInputStream());
					
					reader.setSessionInfoVisitor(localWriter);
					reader.setExecutionDataVisitor(localWriter);
			
					// Send a dump command and read the response:
					writer.visitDumpCommand(true, false);
					reader.read();					
				}
				finally
				{
					socket.close();
					localFile.close();	
				}
			
				ReportGenerator.main(new String[] {ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")});	
			}						
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
				
	  }
	
}
