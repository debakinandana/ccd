package com.att.tta.ccqp.core;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.tools.ant.types.resources.FileResource;
import org.jacoco.core.tools.ExecFileLoader;

import com.att.tta.ccqp.util.ConfigUtils;
import com.att.tta.ccqp.util.MergeTask;


/**
 * Help to merge the .exec file comming from mulitiple sources
 * Generate html report
 * @author gs495a
 *
 */
public class MergeAndGenerateReport 
{
	private static Logger logger = Logger.getLogger(MergeAndGenerateReport.class);
	
	private static Timer flushTimer;
	
	private static final String ccqp_parent = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant");
	private static final String merge_exec_location = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant") + System.getProperty("file.separator") + "tmp";
	private static final String temp_file_location = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant") + System.getProperty("file.separator") + "tmp";
	private static String merge_file_name = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant") + System.getProperty("file.separator") + ConfigUtils.getInstance().getConfigProp().getProperty("data_file");
	private static String server_merge = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant") + System.getProperty("file.separator") + ConfigUtils.getInstance().getConfigProp().getProperty("merge_data_file");
	
	public static void main(String[] args) 
	{	
		TimerScheduler.initialize();		
	}	
	
	private static class TimerScheduler
	{
		public TimerScheduler(long reportStartInSeconds, long reportExecutionTimeGap) throws NumberFormatException, UnknownHostException, IOException
		{
			flushTimer = new Timer();
			flushTimer.schedule(new Report(), reportStartInSeconds * 1000, reportExecutionTimeGap * 1000);
		}
		
		public static void initialize()
		{
			try
			{
				new TimerScheduler(60, 60);
			}
			catch (Exception e)
			{
				logger.info("public static void initialize()"+ e.getMessage());
				e.printStackTrace();
			}
		}
	}

	private static class Report extends TimerTask
	{

		public void run()
		{
			try
			{
				
				synchronized (this)
				{
					
						logger.info("Reader Called!!!!Merging and Generating report!!!");
	
						File tempFolder = new File(temp_file_location);
	
						if (tempFolder != null && tempFolder.exists() && tempFolder.isDirectory() && tempFolder.list().length > 0)
						{
							logger.info("merging start for " + merge_exec_location);
							// merge from tmp to parent directory
							if (mergeDataFile(merge_file_name, merge_exec_location, new ArrayList<String>()))
							{
								try
								{
	
									List<String> ignoreList = new ArrayList<String>();
									final String[] SUFFIX =
									{ "exec" }; // use the suffix to
									// filter
									File rootDir = new File(ccqp_parent);
									@SuppressWarnings("unchecked")
									Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, false);
	
									for (Iterator<File> iterator = files.iterator(); iterator.hasNext();)
									{
										File file = iterator.next();
										if (file.getName().startsWith("new_session_"))
										{
											ignoreList.add(file.getName());
										}
									}
	
									// merge everything in parent directory to merge
									// file
									// file
									mergeDataFile(server_merge, ccqp_parent, ignoreList);
									ReportGenerator.main(new String[]
									{ ccqp_parent, ConfigUtils.getInstance().getConfigProp().getProperty("merge_data_file"), ConfigUtils.getInstance().getConfigProp().getProperty("server_merge_sessionid") });
	
									for (Iterator<File> iterator = files.iterator(); iterator.hasNext();)
									{
										// now look for any new session files
										List<String> ignoreList1 = new ArrayList<String>();
										File file = iterator.next();
										if (file.getName().startsWith("jacoco_client") || file.getName().startsWith("server_merge"))
										{
											continue;
										}
	
										List<String> jacocoClients = new ArrayList<String>();
										if (file.getName().startsWith("new_session"))
										{
											for (Iterator<File> iterator2 = files.iterator(); iterator2.hasNext();)
											{
												File file2 = iterator2.next();
												if (file2.getName().startsWith("jacoco_client"))
												{
													jacocoClients.add(file2.getName());
												}
	
												if (file.getName().startsWith("jacoco_client"))
												{
													continue;
												} else if (file2.getName().startsWith("server_merge"))
												{
													ignoreList1.add(file2.getName());
												} else if (!file.getName().equals(file2.getName()))
												{
													ignoreList1.add(file2.getName());
												}
											}
	
											String[] strArray = file.getName().split("_");
											String jacocoNewFile = ccqp_parent + "/jacoco_client_" + strArray[2] + ".exec";
											// merge everything in tmp directory
											logger.info("Merge everything in tmp directory to the jacoco_client_.exec");
											mergeDataFile(jacocoNewFile, merge_exec_location, new ArrayList<String>());
											ignoreList1.remove("jacoco_client_" + strArray[2] + ".exec");
											// merge everything in parent directory
											logger.info("Merge everything in parent directory to new_session_MERGE_SERVER");
											mergeDataFile(file.getPath(), ccqp_parent, ignoreList1);
											logger.info("Generate Report");
											ReportGenerator.main(new String[]
											{ ccqp_parent, file.getName(), file.getName() });
										}
									}
								} catch (Exception e)
								{
									logger.info("Error while generating report: " + e.getMessage());
								}
							} else
							{
								logger.info("Nothing to generate report!!! Skipping the Generate report process!!!");
							}
						}
				}
			
			} 
			catch (Exception e)
			{
				logger.info("Error in report thread "+e.getMessage());
				e.printStackTrace();
			}
		}

		public static Boolean mergeDataFile(String destFile, String mergeLocationExec, List<String> ignoreFileList) throws IOException
		{
			MergeTask mergeTask = new MergeTask();
			mergeTask.setDescription("JavaTCT_Merge_Report");

			File destFileObject = new File(destFile);

			if (!destFileObject.exists())
			{
				destFileObject.createNewFile();
			}

			mergeTask.setDestfile(destFileObject);
			ExecFileLoader execFileLoader = null;

			int count = 0;

			logger.info("Root Folder to search for .exec files" + mergeLocationExec + "dest location: " + destFile);

			final String[] SUFFIX =
			{ "exec" }; // use the suffix to filter

			File rootDir = new File(mergeLocationExec);

			@SuppressWarnings("unchecked")
			Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, false);

			Date currentDate = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(currentDate);
			// cal.add(Calendar.HOUR, -1);
			cal.add(Calendar.MINUTE, -60);
			Date alertDate = cal.getTime();

			for (Iterator<File> iterator = files.iterator(); iterator.hasNext();)
			{
				File file = iterator.next();

				Date modifiedDate = new Date(file.lastModified());

				if (modifiedDate.after(alertDate))
				{
					if (ignoreFileList.contains(file.getName()))
					{
						continue;
					}
					execFileLoader = new ExecFileLoader();
					// logger.info("Loading data file - " + file.getName());
					try
					{
						execFileLoader.load(file);
					} catch (Exception e)
					{
						logger.info("Error while reading file: " + file.getPath() + e.getMessage());
						logger.info("Error " + e.getMessage());
						file.delete();
						logger.info("Deleted Currupted File " + file.getName());
						continue;
					}
					if (execFileLoader.getExecutionDataStore().getContents().size() > 0)
					{
						FileResource fileResource = new FileResource(file);
						mergeTask.addConfigured(fileResource);
						++count;
					}
				}
			}

			if (count > 0)
			{
				mergeTask.execute(false);
				return true;
			}

			return false;
		}

	}

}
