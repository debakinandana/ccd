package com.att.tta.ccqp.util;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.tools.ant.types.resources.FileResource;
import org.jacoco.core.tools.ExecFileLoader;

import com.att.tta.ccqp.core.ReportGenerator;

public class MergeTask2 {
	
	private static String merge_file_name = "C:\\Users\\GS495A\\Documents\\JCoCo\\txcdtl153504sg.api360-100.0.0\\jacoco_client.exec";
	private static final String ccqp_parent = "C:\\Users\\GS495A\\Documents\\JCoCo\\txcdtl153504sg.api360-100.0.0\\archieved";
	
	
	public static void main(String[] args) throws IOException 
	{
		MergeTask mergeTask = new MergeTask();
		File destFileObject = new File(merge_file_name);
		
		mergeTask.setDestfile(destFileObject);
		
		final String[] SUFFIX = {"exec"};  // use the suffix to filter
		
	    File rootDir = new File(ccqp_parent);

	    Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, true);
	    
	    ExecFileLoader execFileLoader = null;
	    
	    for (Iterator iterator = files.iterator(); iterator.hasNext();) 
		{
			File file = (File) iterator.next();	
			
			execFileLoader = new ExecFileLoader();				
			execFileLoader.load(file);
			
			if(execFileLoader.getExecutionDataStore().getContents().size() > 0)
			{
				FileResource fileResource= new FileResource(file);				
				mergeTask.addConfigured(fileResource);	
			}								
		}	
	    
	    mergeTask.execute();
		
		try 
		{
			ReportGenerator.main(new String[] {ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")});
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}	
	}
}