package com.att.tta.ccqp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class ConfigUtils 
{

	private static final String CCQP_PROPERTIES = "ccqp.properties";	
	private static ConfigUtils instance = null; 
	private Properties configProp = new Properties();	
	
	 public ConfigUtils() throws IOException 
	 {
		 if(System.getProperty("ccqp_properies")==null)
			{
				configProp = new Properties();
				InputStream in = ConfigUtils.class.getClassLoader().getResourceAsStream(CCQP_PROPERTIES);
				configProp.load(in);
			}
			else
			{
				
				InputStream cobertura_properies_path_input = new FileInputStream(System.getProperty("ccqp_properies"));
				configProp.load(cobertura_properies_path_input);
				
			}		
	}
	    
    public static ConfigUtils getInstance()
    {
		if (instance == null) 
		{
			try 
			{
				instance = new ConfigUtils();
			} catch (IOException e)
			{
				System.out.println(e.getMessage());
			}
		}
		return instance;
     }

	public Properties getConfigProp() {
		return configProp;
	}

	public void setConfigProp(Properties configProp) {
		this.configProp = configProp;
	}
    
    
	public static String appendParentPath(String parent, String child)
	{
		return parent+System.getProperty("file.separator")+child;
	}
	
	
}
