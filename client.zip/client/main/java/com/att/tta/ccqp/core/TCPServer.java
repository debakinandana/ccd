package com.att.tta.ccqp.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.tools.ant.types.resources.FileResource;
import org.jacoco.ant.MergeTask;
import org.jacoco.core.data.ExecutionData;
import org.jacoco.core.data.ExecutionDataStore;
import org.jacoco.core.data.ExecutionDataWriter;
import org.jacoco.core.data.IExecutionDataVisitor;
import org.jacoco.core.data.ISessionInfoVisitor;
import org.jacoco.core.data.SessionInfo;
import org.jacoco.core.runtime.RemoteControlReader;
import org.jacoco.core.runtime.RemoteControlWriter;

import com.att.tta.ccqp.util.ConfigUtils;

public class TCPServer {

    private static Logger logger = Logger.getLogger(TCPServer.class);

    private static final String ADDRESS = ConfigUtils.getInstance().getConfigProp().getProperty("tcpserver");
    private static final int PORT = Integer.valueOf(ConfigUtils.getInstance().getConfigProp().getProperty("tcpport"));
    private static final String ccqp_parent = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant");
    private static final String temp_file_location = ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant") + System.getProperty("file.separator") + "tmp";

    /**
     * Start the server as a standalone program.
     * 
     * @param args
     * @throws IOException
     */
    public static void main(final String[] args) throws IOException {
	final ServerSocket server = new ServerSocket(PORT, 0, InetAddress.getByName(ADDRESS));

	logger.info("Starting server on PORT: " + PORT + "           and HOST: " + ADDRESS);

	MergeAndGenerateReport.main(null);

	while (true) {
	    String idOne = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	    String bufferFileName = temp_file_location + File.separator + "jacoco_client_buffer_" + idOne + ".exec";
	    File bufferFile = new File(bufferFileName);
	    String mergeFileName = temp_file_location + File.separator + "jacoco_client_" + idOne + ".exec";
	    File mergeFile = new File(mergeFileName);

	    logger.info("File created in tmp folder :" + idOne);
	    final Handler handler = new Handler(server.accept(), bufferFile, mergeFile, idOne);
	    logger.info("New TCP socket connection started");

	    new Thread(handler).start();
	    logger.info("New Thread started to handle the request");
	}
    }

    private static class Handler implements Runnable, ISessionInfoVisitor, IExecutionDataVisitor {

	private final Socket socket;

	private final RemoteControlReader reader;

	// private final RemoteControlWriter writer;

	private ExecutionDataWriter fileWriter;
	
	private FileOutputStream fileOutputStream;

	private final File mergeFile;

	private final File bufferFile;

	private ExecutionDataStore dataStores;

	private MergeExecFiles mergeExecFiles;

	private List<String> history;

	private int sessionsCount;
	
	private long count;

	private String idOne;

	Handler(final Socket socket, final File bufferFile, final File mergeFile, final String idOne) throws IOException {
	    logger.info("Called Handler!!!" + socket.getRemoteSocketAddress());
	    this.socket = socket;
	    this.bufferFile = bufferFile;
	    this.mergeFile = mergeFile;
	    this.idOne = idOne;
	    this.fileOutputStream = new FileOutputStream(bufferFile);
	    this.fileWriter = new ExecutionDataWriter(fileOutputStream);

	    history = new ArrayList<String>();

	    // Just send a valid header:
	    // writer = new RemoteControlWriter(socket.getOutputStream());
	    reader = new RemoteControlReader(socket.getInputStream());

	    reader.setSessionInfoVisitor(this);
	    reader.setExecutionDataVisitor(this);
	    mergeExecFiles = new MergeExecFiles();
	    mergeExecFiles.addConfigured(new FileResource(bufferFile));
	    mergeExecFiles.addConfigured(new FileResource(mergeFile));
	    mergeExecFiles.setDestfile(mergeFile);

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void run() {
	    try {
		while (reader.read()) {
		    final String[] SUFFIX = { "exec" };
		    if (!mergeFile.exists()) {
			mergeFile.createNewFile();
		    }
		    File rootDir = new File(ccqp_parent);

		    @SuppressWarnings("unchecked")
		    Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, false);

		    for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) {
			File file1 = iterator.next();
			if (file1.getName().startsWith("new_session_") && !history.contains(file1.getName())) {
			    history.add(file1.getName());
			    this.fileWriter = new ExecutionDataWriter(new FileOutputStream(this.bufferFile));
			    reader.setSessionInfoVisitor(this);
			    reader.setExecutionDataVisitor(this);
			}
		    }

		    System.out.println("Called Handler!!!" + socket.getRemoteSocketAddress());
		}

		fileWriter.flush();

		socket.close();

	    } catch (Exception e) {
		logger.info("Excepton: ", e);
		e.printStackTrace();
	    }
	}

	public void visitSessionInfo(final SessionInfo info) {

	    logger.info("Retrieving execution Data for session: " + info.getId());

	    synchronized (fileWriter) {
		if (sessionsCount  >= 5) {
		    try {
			fileWriter.flush();
			fileOutputStream.close();
			logger.info("Sessions Count is: " + sessionsCount);
			logger.info("Executing Merge Task");
			mergeExecFiles.execute();
			fileOutputStream = new FileOutputStream(bufferFile);
			this.fileWriter = new ExecutionDataWriter(fileOutputStream);
		    } catch (IOException e) {
			logger.info("Excepton: ", e);
			e.printStackTrace();
		    }
//		    reader.setSessionInfoVisitor(this);
//		    reader.setExecutionDataVisitor(this);
		    sessionsCount = 0;
		}
		fileWriter.visitSessionInfo(info);
		sessionsCount++;
		logger.info("Total Count is: " + count);
		count++;
	    }
	}

	public void visitClassExecution(final ExecutionData data) {
	    synchronized (fileWriter) {
//		logger.info(String.format("ID: %d%n, VM Name: %s, Probes array: [%s]", data.getId(), data.getName(), Arrays.toString(data.getProbes())));
		if (isAppend(data.getProbes())) { //this check is useful as the agent is sending all-false probes as well. Need add functionality on the agent to not send all-false execution data 
		    fileWriter.visitClassExecution(data);
		}
	    }

	}

    }

    private static Boolean isAppend(boolean[] probes) {
	for (boolean b : probes) {
	    if (b) {
		return true;
	    }
	}

	return false;
    }

    private TCPServer() {

    }
}
