package com.att.tta.ccqp.util;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;
import org.jacoco.core.data.ExecutionData;
import org.jacoco.core.data.IExecutionDataVisitor;
import org.jacoco.core.data.ISessionInfoVisitor;
import org.jacoco.core.data.SessionInfo;
import org.jacoco.core.internal.data.CompactDataInput;

import com.att.tta.ccqp.core.TCPServer;

public class ExecutionDataReader {

	private static Logger logger = Logger.getLogger(ExecutionDataReader.class);
	protected final CompactDataInput in;
	private ISessionInfoVisitor sessionInfoVisitor = null;

	private IExecutionDataVisitor executionDataVisitor = null;

	private boolean firstBlock = true;

	public ExecutionDataReader(InputStream input) {
		this.in = new CompactDataInput(input);
	}

	public void setSessionInfoVisitor(ISessionInfoVisitor visitor) {
		this.sessionInfoVisitor = visitor;
	}

	public void setExecutionDataVisitor(IExecutionDataVisitor visitor) {
		this.executionDataVisitor = visitor;
	}

	public boolean read() throws IOException 
	{
		try 
		{
			byte type = this.in.readByte();
			
			System.out.println(type);
			
			if ((this.firstBlock) && (type != 1)) {
				throw new IOException("Invalid execution data file.");
			}
			this.firstBlock = false;
			if (!(readBlock(type)))
				;
			return true;
		} catch (EOFException e) {
		}
		return false;
	}

	protected boolean readBlock(byte blocktype) throws IOException {
		logger.info("Inside readBlock");
		switch (blocktype) {
		case 1:
			logger.info("Calling readHeader method");
			readHeader();
			return true;
		case 16:
			logger.info("Calling readSessionInfo method");
			readSessionInfo();
			return true;
		case 17:
			logger.info("Calling readExecutionData method");
			readExecutionData();
			return true;
		}
		throw new IOException(String.format("Unknown block type %x.",
				new Object[] { Byte.valueOf(blocktype) }));
	}

	private void readHeader() throws IOException {
		if (this.in.readChar() != 49344) {
			throw new IOException("Invalid execution data file.");
		}
		char version = this.in.readChar();
		if (version != 4103)
			throw new IOException(String.format("Incompatible version %x.",
					new Object[] { Integer.valueOf(version) }));
		logger.info("Valid Data file Header");
	}

	private void readSessionInfo() throws IOException {
		if (this.sessionInfoVisitor == null) {
			throw new IOException("No session info visitor.");
		}
		String id = this.in.readUTF();
		long start = this.in.readLong();
		long dump = this.in.readLong();
		this.sessionInfoVisitor.visitSessionInfo(new SessionInfo(id, start,
				dump));
		logger.info("Valid readSessionInfo");
	}

	private void readExecutionData() throws IOException {
		if (this.executionDataVisitor == null) {
			throw new IOException("No execution data visitor.");
		}
		long id = this.in.readLong();
		String name = this.in.readUTF();
		boolean[] probes = this.in.readBooleanArray();
		this.executionDataVisitor.visitClassExecution(new ExecutionData(id,
				name, probes));
		logger.info("readExecutionData - Valid data file");
	}
}
