package com.att.tta.ccqp.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Resource;
import org.apache.tools.ant.types.ResourceCollection;
import org.apache.tools.ant.types.resources.Union;
import org.apache.tools.ant.util.FileUtils;
import org.jacoco.core.tools.ExecFileLoader;

public class MergeTask extends Task 
{
	private File destfile;
	private final Union files;

	public MergeTask() {
		this.files = new Union();
	}

	public void setDestfile(File destfile) {
		this.destfile = destfile;
	}

	public void addConfigured(ResourceCollection resources) {
		this.files.add(resources);
	}

	public void execute(Boolean append) throws BuildException 
	{
		if (this.destfile == null) 
		{
			throw new BuildException("Destination file must be supplied",getLocation());
		}

		ExecFileLoader loader = new ExecFileLoader();
		load(loader);
		save(loader,append);
	}

	private void load(ExecFileLoader loader) 
	{
		Iterator<Resource> resourceIterator = this.files.iterator();
		
		while (resourceIterator.hasNext())
		{
			Resource resource = (Resource) resourceIterator.next();

			if (resource.isDirectory())
			{
				continue;
			}

			log(String.format("Loading execution data file %s", new Object[] { resource }));

			InputStream resourceStream = null;
			
			try 
			{
				resourceStream = resource.getInputStream();
				loader.load(resourceStream);
			} 
			catch (IOException e) 
			{
				throw new BuildException(String.format("Unable to read %s", new Object[1]), e, getLocation());
			} 
			finally 
			{
				FileUtils.close(resourceStream);
			}
		}
	}
	
	

	private void save(ExecFileLoader loader, Boolean append)
	{
		
		log(String.format("Writing merged execution data to %s", new Object[] { this.destfile.getAbsolutePath() }));
		
		try 
		{
			loader.save(this.destfile, append);
		} 
		catch (IOException e) 
		{
			throw new BuildException(String.format( "Unable to write merged file %s", new Object[] { this.destfile.getAbsolutePath() }), e, getLocation());
		}
	}
}
