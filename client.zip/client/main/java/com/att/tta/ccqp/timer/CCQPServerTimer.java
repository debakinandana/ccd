package com.att.tta.ccqp.timer;

import java.util.TimerTask;

import com.att.tta.ccqp.core.ReportGenerator;
import com.att.tta.ccqp.util.ConfigUtils;

public class CCQPServerTimer extends TimerTask
{
	
		public CCQPServerTimer()
		{
			System.out.println("starting ccqp socket connections!!!!");	
			Runtime.getRuntime().addShutdownHook(new Thread(new CloseConnections()));
		}	
		
		
		class CloseConnections extends TimerTask
		{
			public void run() 
			{
				try 
				{
					System.out.println("CCQP Client Stopped!!!");					
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}				
			}
		}
	
	
	  public void run()
	  {
		 
		try 
		{
			synchronized (this) 
			{
				ReportGenerator.main(new String[] {ConfigUtils.getInstance().getConfigProp().getProperty("ccqp_parant")});	
			}						
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
				
	  }
	
}
