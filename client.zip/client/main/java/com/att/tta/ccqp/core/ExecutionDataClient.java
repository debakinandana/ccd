package com.att.tta.ccqp.core;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import com.att.tta.ccqp.timer.CCQPTimerScheduler;

public class ExecutionDataClient 
{
	/**
	 * Starts the execution data request.
	 * 
	 * @param args
	 * @throws IOException
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public static void main(final String[] args) throws IOException, NoSuchAlgorithmException, KeyManagementException 
	{
		CCQPTimerScheduler.initialize();
	}

	private ExecutionDataClient() 
	{
		
	}

}
