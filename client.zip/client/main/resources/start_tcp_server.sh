#!/bin/bash

export JAVA_HOME=/opt/app/java/jdk/jdk170

ROOT=/opt/app/tomcat/JavaTCT
CONFIG=$ROOT/$1/config
LIB=$ROOT/lib/*

export CLASSPATH=$CONFIG:$LIB

JAVA="$JAVA_HOME/bin/java"
CLASSPATH_OPTS=" -classpath $CLASSPATH"
MEMORY_OPTS="-Xms512M -Xmx1024M -XX:MaxPermSize=256M"
LOG_OPTS="-Dlog4j.configuration=file:$CONFIG/log4j.properties"
TIMEZONE="-Duser.timezone=America/Chicago"

MAIN_OPTS="com.att.tta.ccqp.core.TCPServer"
JAVA_OPTS="$JAVA $TIMEZONE $CLASSPATH_OPTS $MEMORY_OPTS $LOG_OPTS $MAIN_OPTS"

echo $JAVA_OPTS
$JAVA_OPTS &

