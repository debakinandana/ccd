#!/bin/bash




output=`lsof -Pi :$1 -sTCP:LISTEN -t`

if [ -n "$output" ]; then
    
	echo "TCP PORT is running"
        kill -9 $output
else 
        echo "TCP PORT is not running"
fi
