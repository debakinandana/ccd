#!/bin/bash

if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null ; then
    echo "RUNNING"
else
    echo "NOT-RUNNING"
fi
