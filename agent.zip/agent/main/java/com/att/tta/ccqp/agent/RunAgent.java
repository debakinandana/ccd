package com.att.tta.ccqp.agent;

public class RunAgent
{
	
	public static void main(String[] args)
	{
		
	}

}
