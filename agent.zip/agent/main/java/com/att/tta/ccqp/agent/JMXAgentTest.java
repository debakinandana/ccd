package com.att.tta.ccqp.agent;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;

import com.att.tta.ccqp.jmx.CCQPManager;
import com.att.tta.ccqp.util.ConfigUtils;

public class JMXAgentTest 
{
	public static void main(String[] args) throws InterruptedException, MalformedObjectNameException, NullPointerException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException 
	{
		try 
		{ 
	         // Instantiate the MBean server 
	         // http://docs.oracle.com/cd/E19698-01/816-7609/connectors-116/index.html
	         MBeanServer mbs = MBeanServerFactory.createMBeanServer(); 
	         
	         CCQPManager mBean = new CCQPManager(null);
	         ObjectName name = new ObjectName(ConfigUtils.getInstance().getPropetiesValue("ccqp_jmx_object_name"));
	         mbs.registerMBean(mBean, name);
	         
	         // Create a JMXMP connector server 
	         JMXServiceURL url =   new JMXServiceURL("jmxmp", "txcdtl153504sg.itservices.sbc.com", 9001); 
	         JMXConnectorServer cs =  JMXConnectorServerFactory.newJMXConnectorServer(url,   null, mbs); 
	         
	         cs.start(); 
	       } 
		    catch (Exception e) 
			{ 
				e.printStackTrace(); 
	        } 
	}

}
