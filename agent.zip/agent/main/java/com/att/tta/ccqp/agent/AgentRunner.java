package com.att.tta.ccqp.agent;

import java.lang.instrument.Instrumentation;

import com.att.tta.ccqp.timer.CCQPTimerScheduler;
import com.att.tta.ccqp.util.ConfigUtils;


public class AgentRunner 
{
	public static void premain(String args, Instrumentation inst) throws Exception 
	{
		try
		{
			System.out.println("javaCTC/CCQP agent args: "+ConfigUtils.getInstance().getAgentArgs());
					
			try
			{
				//0.7.4
				org.jacoco.agent.rt.internal_773e439.PreMain.premain(ConfigUtils.getInstance().getAgentArgs(),inst); 
				
				//0.7.6
				//org.jacoco.agent.rt.internal_14f7ee5.PreMain.premain(ConfigUtils.getInstance().getAgentArgs(),inst);
				
				if("tcpclient".equals(ConfigUtils.getInstance().getPropetiesValue("output")))
				{
					CCQPTimerScheduler.initialize();
				}					
				
				if(Boolean.valueOf(ConfigUtils.getInstance().getPropetiesValue("ccqp_custom_jmx")))
				{
					CCQJMXRunner.main(inst);
				}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
						
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

}
