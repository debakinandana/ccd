package com.att.tta.ccqp.timer;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Timer;

import com.att.tta.ccqp.util.ConfigUtils;

public class CCQPTimerScheduler
{
	
	Timer flushTimer;	
		
	public CCQPTimerScheduler(long reportStartInSeconds,long reportExecutionTimeGap) throws NumberFormatException, UnknownHostException, IOException 
	{
		flushTimer = new Timer();
		flushTimer.schedule(new CCQPTimer(), reportStartInSeconds * 1000, reportExecutionTimeGap * 1000);
	}

	public static void initialize()
	{
		try 
		{
			new CCQPTimerScheduler(Long.valueOf(ConfigUtils.getInstance().getPropetiesValue("ccqp_flush_initial_delay")),Long.valueOf(ConfigUtils.getInstance().getPropetiesValue("ccqp_flush_delay")));
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
}


