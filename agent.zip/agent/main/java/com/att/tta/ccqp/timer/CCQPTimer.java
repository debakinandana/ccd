package com.att.tta.ccqp.timer;

import java.util.TimerTask;

import org.jacoco.agent.rt.IAgent;
import org.jacoco.agent.rt.RT;

public class CCQPTimer extends TimerTask
{
	
		IAgent agent = null;
	
		public CCQPTimer()
		{
			System.out.println("starting ccqp socket connections!!!!");	
			agent = RT.getAgent();
		}	
		
		
	  public void run()
	  {
		 
		try 
		{
			synchronized (this) 
			{
				agent.dump(true);
				System.out.println("CCQP-AGENT: coverage data length in bytes: " +agent.getExecutionData(false).length);
			}						
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
				
	  }
	
}
