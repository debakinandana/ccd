package com.att.tta.ccqp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;


public class ConfigUtils 
{

	private static final String CCQP_AGENT_PROPERTIES = "ccqp.properties";
	
	private static ConfigUtils instance = null; 	
	private Properties configAgentProp = new Properties();
	
	 private ConfigUtils() throws IOException 
	 {
		 try
		 {
			 	if(System.getProperty("ccqp_properties")==null)
				{
					configAgentProp = new Properties();
					InputStream ins = ConfigUtils.class.getClassLoader().getResourceAsStream(CCQP_AGENT_PROPERTIES);
					configAgentProp.load(ins);
				}	
				else
				{
					InputStream cobertura_properies_path_input = new FileInputStream(System.getProperty("ccqp_properties"));
					configAgentProp.load(cobertura_properies_path_input);
				}
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }		
	}
	    
    public static ConfigUtils getInstance()
    {
		if (instance == null) 
		{
			try 
			{
				instance = new ConfigUtils();
			} 
			catch (IOException e)
			{
				System.out.println(e.getMessage());
			}
		}
		return instance;
     }

	public Properties getConfigAgentProp() 
	{
		return configAgentProp;
	}

	public void setConfigAgentProp(Properties configAgentProp)
	{
		this.configAgentProp = configAgentProp;
	}
	
	public String getPropetiesValue(String key)
	{
		
		if(System.getProperty(key)!=null)
		{
			return System.getProperty(key);
		}
		
		return (String) configAgentProp.get(key);		
	}
	
	
	public String getAgentArgs()
	{
		StringBuilder agentArgs = new StringBuilder();
		
		Set<Object> keys = configAgentProp.keySet();
		
		for (Iterator iterator= keys.iterator(); iterator.hasNext();) 
		{
			String object = (String) iterator.next();
			
			if(!object.startsWith("ccqp_"))
			{
				if(System.getProperty(object)!=null)
				{
					agentArgs.append(object).append("=").append(System.getProperty(object)).append(",");
				}
				else
				{
					agentArgs.append(object).append("=").append(configAgentProp.get(object)).append(",");
				}
			}
			
		}
		if(System.getProperty("sessionid")!=null) 
		{
			agentArgs.append("sessionid").append("=").append(System.getProperty("sessionid"));
		}
		
		return agentArgs.toString();
	}
	
}
