package com.att.tta.ccqp.agent;

import java.lang.instrument.Instrumentation;
import java.rmi.RemoteException;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;

import com.att.tta.ccqp.jmx.CCQPManager;
import com.att.tta.ccqp.util.ConfigUtils;


public class CCQJMXRunner 
{
	
	public static void main(Instrumentation inst) throws MalformedObjectNameException, InterruptedException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException, RemoteException
    {
		try 
		{ 
	         // Instantiate the MBean server 
	         // http://docs.oracle.com/cd/E19698-01/816-7609/connectors-116/index.html
	         MBeanServer mbs = MBeanServerFactory.createMBeanServer(); 
	         
	         CCQPManager mBean = new CCQPManager(inst);
	         ObjectName name = new ObjectName(ConfigUtils.getInstance().getPropetiesValue("ccqp_jmx_object_name"));
	         mbs.registerMBean(mBean, name);
	         
	         // Create a JMXMP connector server 
	         JMXServiceURL url =   new JMXServiceURL("jmxmp", ConfigUtils.getInstance().getPropetiesValue("address"), Integer.valueOf(ConfigUtils.getInstance().getPropetiesValue("ccqp_jmx_port"))); 
	         JMXConnectorServer cs =  JMXConnectorServerFactory.newJMXConnectorServer(url,   null, mbs); 	         
	         cs.start();
	       } 
		   catch (Exception e) 
		   { 
			   e.printStackTrace(); 
	       } 
    }
}
