package com.att.tta.ccqp.agent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;


public class JMXMPClient
{
	
	public static void main(String[] args) {
		

		 try { 
		        // Create a JMXMP connector client 
		        // 
		        System.out.println("\nCreate a JMXMP connector client"); 
		        JMXServiceURL url =  new JMXServiceURL("service:jmx:jmxmp://txcdtl153504sg.itservices.sbc.com:9001"); 
		        JMXConnector jmxc = JMXConnectorFactory.connect(url, null); 
		        MBeanServerConnection mbsc = jmxc.getMBeanServerConnection(); 
		 
		        IProxy proxy = (IProxy) MBeanServerInvocationHandler.newProxyInstance(mbsc, new ObjectName("com.tta.ccqp.jmx:type=CCQPManager"),IProxy.class, false);

				List<String> params = new ArrayList<String>();
				
				System.out.println(proxy.getCCQPConfigurations());
				System.out.println(proxy.disableCCQP(params));
				System.out.println(proxy.enableCCQP(params));
				System.out.println(proxy.bounceServer(params));
				
				for(String value: proxy.listAllLoadedClass())
				{
					//if(value.contains("com.att"))
					System.out.println(value);
				}
				
				jmxc.close();
				
		       
		     } catch (Exception e) { 
		       e.printStackTrace(); 
		     } 
		 
	}
	
	private interface IProxy 
	{
		
		public Map<String,String> getCCQPConfigurations();
		public String enableCCQP(List<String> params);
		public String disableCCQP(List<String> params);
		public List<String> listAllLoadedClass();
		public String bounceServer(List<String> params);
	}
	
}
