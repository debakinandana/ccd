package com.att.tta.ccqp.jmx;

import java.util.List;
import java.util.Map;

public interface CCQPManagerMBean 
{
	public Map<String,String> getCCQPConfigurations();
	public String enableCCQP(List<String> params);
	public String disableCCQP(List<String> params);
	public List<String> listAllLoadedClass();
	public String bounceServer(List<String> params);
}
