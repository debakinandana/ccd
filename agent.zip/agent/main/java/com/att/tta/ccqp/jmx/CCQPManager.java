package com.att.tta.ccqp.jmx;

import java.lang.instrument.Instrumentation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.att.tta.ccqp.util.ConfigUtils;


public class CCQPManager implements CCQPManagerMBean
{
	
	private List<String> loadedClasses = new ArrayList<String>();
	private Instrumentation inst=null;
	
	
	public String bounceServer(List<String> params) 
	{
		return ConfigUtils.getInstance().getPropetiesValue("ccqp_server_bounce_script")+" "+params.toString();
	}
	
	public String disableCCQP(List<String> params)
	{
		return ConfigUtils.getInstance().getPropetiesValue("ccqp_disable_script")+" "+params.toString();
	}
	
	public String enableCCQP(List<String> params) 
	{
		return ConfigUtils.getInstance().getPropetiesValue("ccqp_enable_script")+" "+params.toString();
	}
	
	public Map<String, String> getCCQPConfigurations() 
	{
		Map<String,String> returnMap = new HashMap<String, String>();		
		returnMap.put("ccqp", ConfigUtils.getInstance().getConfigAgentProp().toString());	
		return returnMap;
		
	}
	
	public List<String> listAllLoadedClass() 
	{
		if(this.inst!=null)
		{
			this.loadedClasses = new ArrayList<String>();
			
			for (Class<?> clazz: this.inst.getAllLoadedClasses()) 
			{
				try
				{ 
					this.loadedClasses.add(clazz.getName()+"#"+clazz.getPackage().getName());	            
				}
				catch(Exception e){}	
		    }
		}
		
		return this.loadedClasses;
	}	
	
	
	public CCQPManager(Instrumentation inst) throws InterruptedException 
	{
		this.inst=inst;			
		System.out.println("Initialized CCQP Mbean!!!");
	}	
	
}
