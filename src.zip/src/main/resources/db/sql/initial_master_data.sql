/*
select * from JAVA_TCT_CONFIG_MASTER;
select * from JAVA_TCT_CP_MASTER;
select * from JAVA_TCT_JVM_ARGS_MASTER;
select * from JAVA_TCT_STATUS_MASTER;
*/

 
  
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (1, 'ccqp_flush_initial_delay', 'client','60','Initial time in seconds to start receiving code coverage from javaagent running in tcpserver mode');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (2, 'ccqp_flush_delay', 'client','30','Time in seconds to receive coverage from tcpserver socket running on javaagent  running in tcpserver mode');

insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (3, 'ccqp_parant', 'client','<PATH_TO_TCPSERVER>/<APP_NAME>','This is the parent folder name where client tcpserver is configured');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (4, 'data_file', 'client','jacoco_client.exec','coverage data file name');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (5, 'merge_data_file', 'client','server_merge.exec','merge coverage data file name');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (6, 'classes_directory', 'client','<PATH_TO_ACTUAL_CLASS_DEPLOYED_ON_AGENT_SERVER>','Copy the same version of classes which are deployed on agent server');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (7, 'classes_original_directory', 'client','<PATH_TO_ACTUAL_CLASS_DEPLOYED_ON_AGENT_SERVER>','upload the same version of classes which are deployed on agent/host server');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (8, 'source_directory', 'client','<PATH_TO_SOURCE_CODE_DIRECTORY>','upload the same version of source code which are deployed on agent/host server');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (9, 'coverage_report', 'client','<PATH_TO_REPORT_GENERATION_DIRECTORY>','provide path where to generate report. this may be tomcat webapps directory');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (10, 'tcpserver', 'client','localhost','put localhost in case of javatct is behaving as server else put agent host server name');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (11, 'tcpport', 'client','630X','make sure, every tcpserver running on unique port');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (12, 'sessionid', 'client','<HOST_NAME>-<JVM_NAME>-<NODE_NAME>-<APP_NAME>-<VERSION>','This should be unique accross all applications configured in JAVATCT-CLIENT');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (13, 'server_merge_sessionid', 'client','MERGE-SERVER-<HOST_NAME>-<JVM_NAME>-<NNODE_NAME>-<APP_NAME>-<VERSION>','This should be unique accross all applications configured in JAVATCT-CLIENT');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (14, 'jmx_port', 'client','999X','JMX port, if agent is running using JMX');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (15, 'jmx_url', 'client','service:jmx:rmi:///jndi/rmi://_HOST_:_PORT_/jmxrmi','URL to connect JMX: Do not change');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (16, 'ccqp_jmx_port', 'client','900X','use this, if you want to perform dynamic actions on agent/host');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (17, 'ccqp_jmx_url', 'client','service:jmx:jmxmp://_HOST_:_PORT_','do not change');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (18, 'ccqp_merger_parent', 'client','<PATH TO MERGE DIRECTORY>','This option is applicable only if agent is running in output=tctserver');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (19, 'owner_email_id', 'client','abc@att.com','contact email id');


insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (20, 'output', 'agent','tcpclient','output can be tcpserver or tcpclient, please read documenation');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (21, 'exclclassloader', 'agent','sun.*','seperate all packages using colon which you want to exclude' );
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (22, 'inclbootstrapclasses', 'agent','false','keep it false for now');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (23, 'address', 'agent','<TCP_SERVER_HSOT_NAME>','provide tcpserver host name where you report/javatct client is running ');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (24, 'port', 'agent','930X','provide tcpserver port number where you report/javatct client is running');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (25, 'includes', 'agent','com.att.*','provide all class or packages seperated by colon to include in dynamic instrumenation and to generate coverage report');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (26, 'jmx', 'agent','false','default is false, set it true if you want to receive coverage using JMX, you will have to start port on each jvm and need to setup javatct client for each jvm');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (27, 'ccqp_custom_jmx', 'agent','false','default is false, set this true if you want to receive commands from javatct client, you will have to specify another unique port on each jvm');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (28, 'ccqp_jmx_port', 'agent','900X','custorm JMX will run on this port');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (29, 'ccqp_jmx_object_name', 'agent','com.tta.ccqp.jmx:type=CCQPManager','keep it same');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (30, 'ccqp_server_bounce_script', 'agent','fake_path','provide the script name which you want to execute, when javatct client send bounce command');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (31, 'ccqp_disable_script', 'agent','fake_path','provide the script name which you want to execute, when javatct client send disable command');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (32, 'ccqp_enable_script', 'agent','fake_path','provide the script name which you want to execute, when javatct client send enable command');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (33, 'ccqp_dump_reset', 'agent','false','keep it false for now');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (34, 'ccqp_flush_initial_delay', 'agent','60','Initial time in seconds to start tcpclient socket connection to start sending code coverage');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (35, 'ccqp_flush_delay', 'agent','30','Time in seconds to send coverage from tcpclient to tcpserver socket running on javatct_reporting server');

insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (36, 'running','status','false', 'value could be true or false, scheduler will be running to keep checking the status of running tcpservers and resources');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (37, 'last_feed_received','status','NA','time when the last feed received');

insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (38, 'ccqp_properties', 'agent_config','-Dccqp_properties=<path to file>','set this properties as system/custom properties and provide the path to the ccqp-agent.jar file. exanple -Dccqp_properties=<path to file>');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (39, 'sessionid', 'agent_config','-Dsessionid=<unique session id across all jvm and hosts>','format should be <HOST_NAME>-<JVM_NAME>-<NNODE_NAME>-<APP_NAME>-<VERSION>, use this feature to not to have multiple ccqp.properites while configuring agent on multi level jvms environment. -Dsessionid=<unique session id across all jvm and hosts>');
insert into JAVA_TCT_CONFIG_MASTER (ID,KEY,TYPE,DEFAULT_VALUE,HINT) values (40, 'javaagent', 'agent_config','-ccqp-agent.jar=<path to jar file>','path to ccqp-agent.jar file. example -ccqp-agent.jar=<path to jar file>');




