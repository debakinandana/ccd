create table if not exists JAVA_TCT_GLOBAL_TABLE (
TEXT VARCHAR(100)
);

