package com.att.tta.ccqp.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.att.tta.ccqp.dao.JavaTCTAppDAO;
import com.att.tta.ccqp.dao.JavaTCTConfigMasterDAO;
import com.att.tta.ccqp.model.ExecDashboardOverAllStats;
import com.att.tta.ccqp.model.KeyValue;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.schema.JavaTCTConfigMaster;
import com.att.tta.ccqp.utils.GlobalUtils;

@Service
public class JavaTCTAppServiceImpl implements JavaTCTAppService
{

	@Autowired
	JavaTCTAppDAO javaTCTAppDAOImpl;

	@Autowired
	JavaTCTConfigMasterDAO javaTCTConfigMasterDAOImpl;

	@Value("${java_tct_home}")
	String javaTCTParentFolderName;

	@Value("${java_tct_client_folders}")
	String javaTCTFolderNames;

	@Value("${java_tct_ccqp_prop_file_name}")
	String java_tct_ccqp_prop_file_name;

	@Value("${java_tct_tcp_server_address}")
	String java_tct_tcp_server_address;

	@Value("${java_tct_coverage_report_home}")
	String java_tct_coverage_report_home;

	@Value("${java_tct_report_server_address}")
	String java_tct_report_server_address;

	@Override
	public List<KeyValue> fetchSessinList(long id) throws Exception
	{
		JavaTCTApp javaTCTApp = fetch(id);

		Set<JavaTCTConfig> javaTCTConfigs = javaTCTApp.getJavaTCTConfig();

		String server_merge_session_id = null;

		for (JavaTCTConfig javaTCTConfig : javaTCTConfigs)
		{
			if (javaTCTConfig.getConfig_key().equals("server_merge_sessionid"))
			{
				server_merge_session_id = javaTCTConfig.getConfig_value();
			}
		}

		return GlobalUtils.fetchSessionList(javaTCTParentFolderName, javaTCTApp.getAppFolderName(), server_merge_session_id);
	}

	@Override
	public String startNewSession(long id) throws Exception
	{

		JavaTCTApp javaTCTApp = fetch(id);

		Long maxId = GlobalUtils.getMaxNewSessionId(javaTCTParentFolderName, javaTCTApp.getAppFolderName());

		Set<JavaTCTConfig> javaTCTConfigs = javaTCTApp.getJavaTCTConfig();

		String sessionId = null;
		String jacocoClient = null;

		for (JavaTCTConfig javaTCTConfig : javaTCTConfigs)
		{

			if (javaTCTConfig.getConfig_key().equals("server_merge_sessionid"))
			{
				sessionId = "new_session_" + maxId + "_" + javaTCTConfig.getConfig_value() + ".exec";
				jacocoClient = "jacoco_client_" + maxId + ".exec";
			}
		}

		if (sessionId != null)
		{

			File newFile = new File(javaTCTParentFolderName + File.separator + javaTCTApp.getAppFolderName() + File.separator + sessionId);
			File newJaCoCoFile = new File(javaTCTParentFolderName + File.separator + javaTCTApp.getAppFolderName() + File.separator + jacocoClient);
			if (!newFile.exists())
			{
				newFile.createNewFile();
				newJaCoCoFile.createNewFile();
			}
		}

		return sessionId;
	}

	@Override
	public String stopNewSession(String sessionData) throws Exception
	{
		String[] strArray = sessionData.split("_");
		JavaTCTApp javaTCTApp = fetch(Long.parseLong(strArray[0]));

		// Long maxId = GlobalUtils.getMaxNewSessionId(javaTCTParentFolderName,
		// javaTCTApp.getAppFolderName());
		String jacocoClientId = strArray[3];
		Set<JavaTCTConfig> javaTCTConfigs = javaTCTApp.getJavaTCTConfig();

		String sessionId = null;
		String jacocoClient = null;

		for (JavaTCTConfig javaTCTConfig : javaTCTConfigs)
		{
			if (javaTCTConfig.getConfig_key().equals("server_merge_sessionid"))
			{
				sessionId = "new_session_" + jacocoClientId + "_" + javaTCTConfig.getConfig_value() + ".exec";
				jacocoClient = "jacoco_client_" + jacocoClientId + ".exec";
			}
		}

		if (sessionId != null)
		{
			File stopppingJaCoCoFile = new File(javaTCTParentFolderName + File.separator + javaTCTApp.getAppFolderName() + File.separator + jacocoClient);
			if (stopppingJaCoCoFile.exists())
			{
				File stoppedJacocoFile = new File(javaTCTParentFolderName + File.separator + javaTCTApp.getAppFolderName() + File.separator + "stop_" + jacocoClient);
				stopppingJaCoCoFile.renameTo(stoppedJacocoFile);
			}
		}
		return sessionId;
	}

	@Override
	public List<KeyValue> fetchAllPackagesClassStrutures(String appName) throws Exception
	{
		String path = javaTCTParentFolderName + File.separator + appName + File.separator + "bin" + File.separator + "include.txt";

		File file = new File(path);
		List<KeyValue> list = new ArrayList<KeyValue>();

		if (file.exists())
		{
			List<String> pathList = FileUtils.readLines(file);
			Collections.sort(pathList);

			list = new ArrayList<KeyValue>();

			for (String string : pathList)
			{
				list.add(new KeyValue(string, string));
			}
		}
		return list;
	}

	@Override
	public Map<String, String> fetchCoverageReportDetail() throws Exception
	{
		Map<String, String> detail = new HashMap<String, String>();
		detail.put("java_tct_report_server_address", java_tct_report_server_address);
		return detail;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
	public long createApplication(JavaTCTApp javaTCTApp) throws Exception
	{
		Long returnVal = javaTCTAppDAOImpl.create(javaTCTApp);

		if (returnVal > 0)
		{
			
			//Check if folder is available		
			File topFolder = new File(javaTCTParentFolderName);		
			
			if(topFolder.exists() && !new File(javaTCTParentFolderName+"/bin").exists())
			{
				//create top folder
				topFolder.mkdir();			
				String client_setup_folder = this.getClass().getClassLoader().getResource("../client-setup").getPath();			
				FileUtils.copyDirectory(new File(client_setup_folder),topFolder );		
				
				
				//update path in scripts
				File dir = new File(topFolder.getPath()+File.separator+"bin");
				
				String[] extensions = new String[] { "bat", "sh" };
				
				System.out.println("Getting all .txt and .jsp files in " + dir.getCanonicalPath()+ " including those in subdirectories");
				
				@SuppressWarnings("unchecked")
				List<File> files = (List<File>) FileUtils.listFiles(dir, extensions, false);
				
				for (File file : files) 
				{
					//_JAVA_TCT_HOME_
					FileUtils.writeStringToFile(file, FileUtils.readFileToString(file).replace("_JAVA_TCT_HOME_", javaTCTParentFolderName));
				}
				
			}
			
			/*
			 * Create folder structure
			 */
			GlobalUtils.generateFolderStructure(javaTCTApp.getAppFolderName(), javaTCTFolderNames, javaTCTParentFolderName);
		}

		return returnVal;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
	public long create(JavaTCTApp javaTCTConfigMaster) throws Exception
	{
		List<JavaTCTConfigMaster> tctConfigMasters = javaTCTConfigMasterDAOImpl.fetchAllRequired();
		Set<JavaTCTConfig> javaTCTConfigs = javaTCTConfigMaster.getJavaTCTConfig();

		/*
		 * update some mendatory default values
		 */
		GlobalUtils.updateExtraDefaultValues(javaTCTAppDAOImpl.giveMeAvailablePort(), java_tct_coverage_report_home, javaTCTConfigMaster, javaTCTParentFolderName, java_tct_tcp_server_address, javaTCTConfigs);

		/*
		 * Validate required configurations before creating record
		 */
		GlobalUtils.validateAppConfigRequiredFields(tctConfigMasters, javaTCTConfigs);

		Long returnVal = javaTCTAppDAOImpl.create(javaTCTConfigMaster);

		if (returnVal > 0)
		{
			/*
			 * Create folder structure
			 */
			GlobalUtils.generateFolderStructure(javaTCTConfigMaster.getAppFolderName(), javaTCTFolderNames, javaTCTParentFolderName);

			/*
			 * create config file
			 */
			GlobalUtils.generateCCQPClientProperties(javaTCTParentFolderName, javaTCTConfigMaster.getAppFolderName(), "config", java_tct_ccqp_prop_file_name, javaTCTConfigMaster.getJavaTCTConfig());

			// Copy log4j
			String client_setup_folder = this.getClass().getClassLoader().getResource("../client-setup/log4j.properties").getPath();
			String log4jStr = FileUtils.readFileToString(new File(client_setup_folder));
			log4jStr = log4jStr.replace("_LOG_PATH_", javaTCTParentFolderName + "/" + javaTCTConfigMaster.getAppFolderName() + "/" + "logs" + "/" + "ccqp.log");
			String logjPath = javaTCTParentFolderName + "/" + javaTCTConfigMaster.getAppFolderName() + "/" + "config" + "/" + "log4j.properties";
			FileUtils.writeStringToFile(new File(logjPath), log4jStr);
		}

		return returnVal;
	}

	@Override
	public JavaTCTApp updateConfig(JavaTCTApp javaTCTApp) throws Exception
	{
		return javaTCTAppDAOImpl.update(javaTCTApp);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
	public JavaTCTApp update(JavaTCTApp javaTCTConfigMaster) throws Exception
	{

		List<JavaTCTConfigMaster> tctConfigMasters = javaTCTConfigMasterDAOImpl.fetchAllRequired();
		Set<JavaTCTConfig> javaTCTConfigs = javaTCTConfigMaster.getJavaTCTConfig();

		/*
		 * update some mendatory default values
		 */
		GlobalUtils.updateExtraDefaultValues(javaTCTAppDAOImpl.giveMeAvailablePort(), java_tct_coverage_report_home, javaTCTConfigMaster, javaTCTParentFolderName, java_tct_tcp_server_address, javaTCTConfigs);

		/*
		 * Validate required configurations before creating record
		 */
		GlobalUtils.validateAppConfigRequiredFields(tctConfigMasters, javaTCTConfigs);

		JavaTCTApp returnVal = javaTCTAppDAOImpl.update(javaTCTConfigMaster);

		/*
		 * create config file
		 */
		GlobalUtils.generateCCQPClientProperties(javaTCTParentFolderName, javaTCTConfigMaster.getAppFolderName(), "config", java_tct_ccqp_prop_file_name, javaTCTConfigMaster.getJavaTCTConfig());

		// Copy log4j
		String client_setup_folder = this.getClass().getClassLoader().getResource("../client-setup/log4j.properties").getPath();
		String log4jStr = FileUtils.readFileToString(new File(client_setup_folder));
		log4jStr = log4jStr.replace("_LOG_PATH_", javaTCTParentFolderName + "/" + javaTCTConfigMaster.getAppFolderName() + "/" + "logs" + "/" + "ccqp.log");
		String logjPath = javaTCTParentFolderName + "/" + javaTCTConfigMaster.getAppFolderName() + "/" + "config" + "/" + "log4j.properties";
		FileUtils.writeStringToFile(new File(logjPath), log4jStr);

		return returnVal;

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
	public void delete(JavaTCTApp javaTCTApp) throws Exception
	{
		javaTCTAppDAOImpl.delete(javaTCTApp);

	}

	@Override
	public List<JavaTCTApp> fetchAll() throws Exception
	{
		return javaTCTAppDAOImpl.fetchAll();
	}

	@Override
	public JavaTCTApp fetch(long id) throws Exception
	{

		JavaTCTApp javaTCTApp = javaTCTAppDAOImpl.fetch(id);

		if (javaTCTApp == null)
		{
			throw new Exception("Application not found in database!!!!");
		}

		return javaTCTApp;
	}

	@Override
	public List<JavaTCTApp> fetchAll(String textStr) throws Exception
	{
		return javaTCTAppDAOImpl.fetchAll(textStr);
	}

	@Override
	public ExecDashboardOverAllStats fetchExecDashboardOverAllStats() throws Exception
	{
		return javaTCTAppDAOImpl.fetchExecDashboardOverAllStats();
	}

	@Override
	public Boolean archiveReport(long id) throws Exception
	{
		JavaTCTApp javaTCTApp = javaTCTAppDAOImpl.fetch(id);
		GlobalUtils.archiveCoverage(javaTCTParentFolderName, javaTCTApp.getAppFolderName(), java_tct_coverage_report_home);
		return true;
	}
}
