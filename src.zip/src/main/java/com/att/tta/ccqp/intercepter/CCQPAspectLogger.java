package com.att.tta.ccqp.intercepter;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class CCQPAspectLogger 
{
	
	

	@Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
	public void controllerBean() 
	{
	    System.out.println(" Pointcut ");
	}
	
	 @Pointcut("execution(* *(..))")
    public void methodPointcut() 
    {
    	    	
    }

 	@Around("controllerBean()")
    public Object aroundControllerMethod(ProceedingJoinPoint joinPoint) throws Throwable
    {
 		System.out.println(joinPoint.getSignature().toString());	 
 		return joinPoint.proceed();
    }
}
