package com.att.tta.ccqp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tta.ccqp.dao.JavaTCTConfigMasterDAO;
import com.att.tta.ccqp.schema.JavaTCTConfigMaster;


@Service
public class JavaTCTConfigMasterServiceImpl implements JavaTCTConfigMasterService
{
	
	@Autowired
	JavaTCTConfigMasterDAO javaTCTConfigMaterDAOImpl;
	
	@Override
	public long create(JavaTCTConfigMaster javaTCTConfigMaster) 
	{
		return javaTCTConfigMaterDAOImpl.create(javaTCTConfigMaster);
	}

	@Override
	public JavaTCTConfigMaster update(JavaTCTConfigMaster javaTCTConfigMaster) 
	{
		return javaTCTConfigMaterDAOImpl.update(javaTCTConfigMaster);
	}

	@Override
	public void delete(JavaTCTConfigMaster javaTCTConfigMaster) 
	{
		javaTCTConfigMaterDAOImpl.delete(javaTCTConfigMaster);
		
	}

	@Override	
	public List<JavaTCTConfigMaster> fetchAllStrategy(String strategy) 
	{
		return javaTCTConfigMaterDAOImpl.fetchAllStrategy(strategy);
	}

	@Override
	public JavaTCTConfigMaster fetch(long id)
	{
		return javaTCTConfigMaterDAOImpl.fetch(id);
	}

	@Override
	public List<JavaTCTConfigMaster> fetchAll(String textStr)
	{
		return javaTCTConfigMaterDAOImpl.fetchAll(textStr);
	}

}
