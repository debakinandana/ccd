package com.att.tta.ccqp.schema;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "JAVA_TCT_APP", uniqueConstraints = @UniqueConstraint(columnNames =
{ "APP_NAME", "APP_ENV", "HOST_NAME", "VERSION" }))
public class JavaTCTApp implements Serializable
{

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "JAVA_TCT_APP_SEQ", sequenceName = "JAVA_TCT_APP_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "JAVA_TCT_APP_SEQ")
	@Column(name = "APP_ID")
	private Long app_id;

	@Column(nullable = false, name = "APP_NAME")
	private String app_name;
	

	@Column(nullable = false, name = "APP_ENV")
	private String app_env;

	@Column(nullable = false, name = "HOST_NAME")
	private String host_name;

	@Column(nullable = false, name = "VERSION")
	private String version;

	@Column(nullable = false, name = "STRATEGY")
	private String strategy;

	@Column(nullable = false, name = "OWNER_EMAIL_ID")
	private String owner_email_id;

	@Column(nullable = false, name = "DESCRIPTION", length = 3000)
	private String desc;

	@Column(nullable = false, name = "RELEASE")
	private String release;

	@Column(nullable = false, name = "BUILD")
	private String build;

	@Transient
	private String appFolderName;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "APP_ID", nullable = false)
	Set<JavaTCTConfig> javaTCTConfig = new HashSet<JavaTCTConfig>();

	public JavaTCTApp()
	{

	}

	public JavaTCTApp(Long app_id, String app_name, String app_env, String host_name, String version, String strategy, String owner_email_id, String desc, String release, String build,Set<JavaTCTConfig> javaTCTConfig)
	{
		super();
		this.app_id = app_id;
		this.app_name = app_name;
		this.app_env = app_env;
		this.host_name = host_name;
		this.version = version;
		this.strategy = strategy;
		this.owner_email_id = owner_email_id;
		this.desc = desc;
		this.release = release;
		this.build = build;
		
		this.javaTCTConfig = javaTCTConfig;
	}

	public String getAppFolderName()
	{
		String hash = this.app_env + "" + this.host_name + "" + this.version;
		return this.app_name + "-" + hash.hashCode();
	}

	public void setAppFolderName(String appFolderName)
	{
		this.appFolderName = appFolderName;
	}

	public Long getApp_id()
	{
		return app_id;
	}

	public void setApp_id(Long app_id)
	{
		this.app_id = app_id;
	}

	

	public String getApp_name()
	{
		return app_name;
	}

	public void setApp_name(String app_name)
	{
		this.app_name = app_name;
	}

	

	public String getApp_env()
	{
		return app_env;
	}

	public void setApp_env(String app_env)
	{
		this.app_env = app_env;
	}

	public String getHost_name()
	{
		return host_name;
	}

	public void setHost_name(String host_name)
	{
		this.host_name = host_name;
	}

	public String getVersion()
	{
		return version;
	}

	public void setVersion(String version)
	{
		this.version = version;
	}

	public String getStrategy()
	{
		return strategy;
	}

	public void setStrategy(String strategy)
	{
		this.strategy = strategy;
	}

	public String getOwner_email_id()
	{
		return owner_email_id;
	}

	public void setOwner_email_id(String owner_email_id)
	{
		this.owner_email_id = owner_email_id;
	}

	public String getDesc()
	{
		return desc;
	}

	public void setDesc(String desc)
	{
		this.desc = desc;
	}

	public String getRelease()
	{
		return release;
	}

	public void setRelease(String release)
	{
		this.release = release;
	}

	public String getBuild()
	{
		return build;
	}

	public void setBuild(String build)
	{
		this.build = build;
	}

	public Set<JavaTCTConfig> getJavaTCTConfig()
	{
		return javaTCTConfig;
	}

	public void setJavaTCTConfig(Set<JavaTCTConfig> javaTCTConfig)
	{
		this.javaTCTConfig = javaTCTConfig;
	}

}
