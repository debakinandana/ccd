package com.att.tta.ccqp.utils;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.lingala.zip4j.core.ZipFile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.springframework.web.multipart.MultipartFile;

import com.att.tta.ccqp.model.KeyValue;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.schema.JavaTCTConfigMaster;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class GlobalUtils {

    public static final String DOWLOADED_ZIP_FILE_LOCATION = "C:/tmp/yn726h.zip";
    public static final String SFTP_HOST = "zlt08087.vci.att.com";
    public static final String PASS_PHRASE = "yasodhan";
    public static final String SFTP_USER = "yn726h";
    public static final String PRIVATE_KEY_FILE_LOCATION = "C:/Users/yn726h/Documents/yn726h.ppk";
    public static final String SFTP_WORKING_DIRECTORY = "/home/yn726h";
    public static final String SFTP_HOST_ZIP_FILENAME = "/yn726h.zip";

    public static Boolean isWindows() {
	if (System.getProperty("os.name").startsWith("Windows")) {
	    return true;
	}

	return false;
    }

    public static List<KeyValue> fetchSessionList(String parentFolder, String appName, String server_merge_session_id) {

	final String[] SUFFIX = { "exec" }; // use the suffix to filter

	File rootDir = new File(parentFolder + File.separator + appName);

	@SuppressWarnings("unchecked")
	Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, true);

	List<KeyValue> sessionList = new ArrayList<KeyValue>();

	for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) {
	    File file = iterator.next();

	    if (file.getName().startsWith("jacoco_client")) {
		continue;
	    } else if (file.getName().startsWith("server_merge")) {
		sessionList.add(0, new KeyValue(server_merge_session_id, server_merge_session_id));
	    } else {
		sessionList.add(new KeyValue(file.getName(), file.getName()));
	    }
	}

	return sessionList;
    }

    public static Long getMaxNewSessionId(String parentFolder, String appName) {

	final String[] SUFFIX = { "exec" }; // use the suffix to filter

	File rootDir = new File(parentFolder + File.separator + appName);

	@SuppressWarnings("unchecked")
	Collection<File> files = FileUtils.listFiles(rootDir, SUFFIX, true);

	List<Long> sessionNumber = new ArrayList<Long>();

	for (Iterator<File> iterator = files.iterator(); iterator.hasNext();) {
	    File file = iterator.next();

	    if (file.getName().startsWith("new_session")) {
		sessionNumber.add(Long.valueOf(file.getName().split("_")[2]));
	    }
	}

	if (sessionNumber.isEmpty()) {
	    return 1L;
	}

	return Collections.max(sessionNumber) + 1L;
    }

    public static void generateFolderStructure(String appName, String folderNameStr, String parentFolder) throws IOException {

	if (!new File(parentFolder + File.separator + appName).exists()) {
	    new File(parentFolder + File.separator + appName).mkdir();
	}

	for (String folderName : folderNameStr.split(",")) {
	    new File(parentFolder + File.separator + appName + File.separator + folderName).mkdir();
	}

    }

    public static void generateCCQPClientProperties(String parentFolder, String appName, String configFolderName, String fileName, Set<JavaTCTConfig> javaTCTConfig) throws IOException {
	List<String> ccqpProp = new ArrayList<String>();

	for (JavaTCTConfig javaTCTConfig2 : javaTCTConfig) {
	    if (javaTCTConfig2.getConfig_type().equals("client")) {
		ccqpProp.add(javaTCTConfig2.getConfig_key() + "=" + javaTCTConfig2.getConfig_value());
	    }
	}

	FileUtils.writeLines(new File(parentFolder + File.separator + appName + File.separator + configFolderName + File.separator + fileName), ccqpProp);
    }

    public static void validateAppConfigRequiredFields(List<JavaTCTConfigMaster> tctConfigMasters, Set<JavaTCTConfig> javaTCTConfigs) throws Exception {
	Boolean found = false;

	for (JavaTCTConfigMaster javaTCTConfigMaster2 : tctConfigMasters) {
	    found = false;

	    for (JavaTCTConfig javaTCTConfig : javaTCTConfigs) {
		if (javaTCTConfigMaster2.getKey().equals(javaTCTConfig.getConfig_key()) && javaTCTConfigMaster2.getType().equals(javaTCTConfig.getConfig_type())) {
		    found = true;
		    break;
		}
	    }

	    if (!found) {
		throw new Exception("Required field validation failed!!!");
	    }
	}
    }

    public static Boolean extractClassPackagesToInclude(String parentFolder, String appName, String srcFolderName) throws Exception {
	String fileStr = parentFolder + File.separator + appName + File.separator + srcFolderName;

	Set<String> output = new HashSet<String>();

	final String[] SUFFIX = { "class" }; // use the suffix to filter

	for (File file : new File(fileStr).listFiles((FileFilter) FileFilterUtils.directoryFileFilter())) {
	    Collection<File> files = FileUtils.listFiles(file, SUFFIX, true);

	    for (File file2 : files) {
		String packageStr = file2.getPath().replace(file.getPath() + File.separator, "").replace(File.separator, ",");
		String[] splitArray = packageStr.split(",");

		String oldStr = "";

		for (String string : splitArray) {
		    if (!string.endsWith(".class")) {
			oldStr = oldStr + string + ".";
			output.add(oldStr + "*");
		    } else {
			oldStr = oldStr + string;
			output.add(oldStr);
		    }
		}
	    }
	}

	if (output.size() > 0) {
	    FileUtils.writeLines(new File(fileStr + File.separator + "include.txt"), output);
	    return true;
	}

	return false;
    }

    public static Boolean uploadSource(String parentFolder, String appName, MultipartFile file, String fileName, String srcFolderName) throws Exception {

	File newFile = null;
	String fileStr = null;
	String fileExt = FilenameUtils.getExtension(fileName);

	fileStr = parentFolder + File.separator + appName + File.separator + srcFolderName + File.separator + fileName;
	newFile = new File(fileStr);

	/**
	 * only for zip and jar files
	 */
	if (fileExt.equals("zip") || fileExt.equals("jar")) {
	    byte[] bytes = file.getBytes();
	    BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(newFile));
	    stream.write(bytes);
	    stream.close();

	    if (fileExt.equals("zip")) {
		decompress(fileStr, parentFolder + File.separator + appName + File.separator + srcFolderName);
	    } else {
		decompress(fileStr, parentFolder + File.separator + appName + File.separator + srcFolderName + File.separator + fileName.replace(fileExt, ""));
	    }

	    return true;
	}

	return false;
    }

    public static void decompress(String compressedFile, String destination) throws Exception {
	ZipFile zipFile = new ZipFile(compressedFile);
	zipFile.extractAll(destination);
    }

    public static void updateExtraDefaultValues(Long port, String java_tct_coverage_report_home, JavaTCTApp javaTCTApp, String javaTCTParentFolderName, String java_tct_tcp_server_address,
	    Set<JavaTCTConfig> javaTCTConfigs) {
	Map<String, String> localMa = new HashMap<String, String>();

	for (JavaTCTConfig javaTCTConfig : javaTCTConfigs) {
	    localMa.put(javaTCTConfig.getConfig_key(), javaTCTConfig.getConfig_value());
	}

	javaTCTConfigs.add(new JavaTCTConfig("address", java_tct_tcp_server_address, "agent"));
	javaTCTConfigs.add(new JavaTCTConfig("ccqp_parant", javaTCTParentFolderName + "/" + javaTCTApp.getAppFolderName(), "client"));
	javaTCTConfigs.add(new JavaTCTConfig("coverage_report", java_tct_coverage_report_home, "client"));
	javaTCTConfigs.add(new JavaTCTConfig("classes_directory", "bin", "client"));
	javaTCTConfigs.add(new JavaTCTConfig("data_file", "jacoco_client.exec", "client"));
	javaTCTConfigs.add(new JavaTCTConfig("merge_data_file", "server_merge.exec", "client"));
	javaTCTConfigs.add(new JavaTCTConfig("server_merge_sessionid", "MERGE-SERVER-" + javaTCTApp.getAppFolderName(), "client"));
	javaTCTConfigs.add(new JavaTCTConfig("port", String.valueOf(port), "agent"));
	javaTCTConfigs.add(new JavaTCTConfig("tcpport", String.valueOf(port), "client"));
	javaTCTConfigs.add(new JavaTCTConfig("source_directory", "src", "client"));
	javaTCTConfigs.add(new JavaTCTConfig("tcpserver", java_tct_tcp_server_address, "client"));
	javaTCTConfigs.add(new JavaTCTConfig("inclbootstrapclasses", "false", "agent"));
	javaTCTConfigs.add(new JavaTCTConfig("jmx", "false", "agent"));
	javaTCTConfigs.add(new JavaTCTConfig("output", "tcpclient", "agent"));
	javaTCTConfigs.add(new JavaTCTConfig("exclclassloader", "sun.*", "agent"));
	javaTCTConfigs.add(new JavaTCTConfig("ccqp_custom_jmx", "false", "agent"));

	/*
	 * javaTCTConfigs.add(new JavaTCTConfig("ccqp_properties",
	 * "-Dccqp_properties=<PATH_TO_CCQP_PROPERTIES_FILE>", "agent_config"));
	 * javaTCTConfigs.add(new JavaTCTConfig("javaagent",
	 * "-javaagent=<PATH_TO_CCQP_AGENT_JAR_FILE>", "agent_config"));
	 * javaTCTConfigs.add(new JavaTCTConfig("sessionid",
	 * "-Dsessionid=<unique session id across all jvm and hosts>",
	 * "agent_config"));
	 */

	javaTCTConfigs.add(new JavaTCTConfig("class_file_uploaded", "false", "status"));
	javaTCTConfigs.add(new JavaTCTConfig("last_feed_received", "NA", "status"));
	javaTCTConfigs.add(new JavaTCTConfig("running", "false", "status"));
	javaTCTConfigs.add(new JavaTCTConfig("source_file_uploaded", "false", "status"));
    }

    public static void archiveCoverage(String javaTCTParentFolderName, String appFolderName, String java_tct_coverage_report_home) throws IOException {
	/*
	 * Archive generated coverage data file
	 */
	String rootFolder = javaTCTParentFolderName + File.separator + appFolderName;
	String archivedFolder = rootFolder + File.separator + "archieved";
	File archievedFolderFile = new File(archivedFolder);

	/*
	 * if(!archievedFolderFile.exists()) { archievedFolderFile.mkdir(); }
	 */

	String idOne = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
	// File folder = new File(archievedFolderFile+File.separator+idOne);

	final String[] SUFFIX = { "exec" }; // use the suffix to filter

	Collection<File> files = FileUtils.listFiles(new File(rootFolder), SUFFIX, false);

	for (File file : files) {
	    file.renameTo(new File(file.getPath() + "-" + idOne + "-Archived"));
	}

	/**
	 * Archive coverage report
	 */
	String reportRootFolder = java_tct_coverage_report_home;

	for (File file : new File(reportRootFolder).listFiles((FileFilter) FileFilterUtils.directoryFileFilter())) {
	    if (file.getName().contains(appFolderName)) {
		file.renameTo(new File(file.getPath() + "-" + idOne + "-Archived"));
	    }

	}

    }
    
}

