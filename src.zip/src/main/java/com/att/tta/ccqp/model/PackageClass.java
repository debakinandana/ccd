package com.att.tta.ccqp.model;

import java.util.List;

import org.apache.commons.lang3.builder.HashCodeBuilder;

public class PackageClass {
    String packageName;
    List<ClassInfo> classNames;

    public String getPackageName() {
	return packageName;
    }

    public void setPackageName(String packageName) {
	this.packageName = packageName;
    }

    public List<ClassInfo> getClassNames() {
	return classNames;
    }

    public void setClassNames(List<ClassInfo> classNames) {
	this.classNames = classNames;
    }

    public PackageClass(String packageName, List<ClassInfo> classNames) {
	this.packageName = packageName;
	this.classNames = classNames;
    }

    // @Override
    // public boolean equals(Object obj) {
    // if (!(obj instanceof PackageClass))
    // return false;
    // if (obj == this)
    // return true;
    // PackageClass rhs = (PackageClass) obj;
    // return new EqualsBuilder().
    // append(packageName, rhs.getPackageName()).isEquals();
    // }
    @Override
    public boolean equals(Object object) {
	boolean equal = false;
	if (object != null && object instanceof PackageClass) {
	    equal = this.packageName.equals(((PackageClass) object).packageName);
	}
	return equal;
    }

    @Override
    public int hashCode() {
	return new HashCodeBuilder(17, 31).append(packageName).toHashCode();
    }
}
