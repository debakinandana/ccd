package com.att.tta.ccqp.dao;

import java.util.List;

import com.att.tta.ccqp.schema.JavaTCTConfigMaster;


public interface JavaTCTConfigMasterDAO 
{
	
	public long create(JavaTCTConfigMaster javaTCTConfigMaster);
	public JavaTCTConfigMaster update(JavaTCTConfigMaster javaTCTConfigMaster);
	public void delete(JavaTCTConfigMaster javaTCTConfigMaster);
	public List<JavaTCTConfigMaster> fetchAllStrategy(String strategy);
	public List<JavaTCTConfigMaster> fetchAllRequired();
	public JavaTCTConfigMaster fetch(long id);
	public List<JavaTCTConfigMaster> fetchAll(String textStr);

}
