package com.att.tta.ccqp.config;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class ConfigTCPServer
{
	
	@Value("${java_tct_home}")
	String javaTCTParentFolderName;
	
	
	@PostConstruct
	public void setupTCTFirstTime() throws IOException
	{
		
		//Check if folder is available		
		File topFolder = new File(javaTCTParentFolderName);		
		
		if(!topFolder.exists())
		{
			//create top folder
			topFolder.mkdir();			
			String client_setup_folder = this.getClass().getClassLoader().getResource("../client-setup").getPath();			
			FileUtils.copyDirectory(new File(client_setup_folder),topFolder );		
			
			
			//update path in scripts
			File dir = new File(topFolder.getPath()+File.separator+"bin");
			
			String[] extensions = new String[] { "bat", "sh" };
			
			System.out.println("Getting all .txt and .jsp files in " + dir.getCanonicalPath()+ " including those in subdirectories");
			
			@SuppressWarnings("unchecked")
			List<File> files = (List<File>) FileUtils.listFiles(dir, extensions, false);
			
			for (File file : files) 
			{
				//_JAVA_TCT_HOME_
				FileUtils.writeStringToFile(file, FileUtils.readFileToString(file).replace("_JAVA_TCT_HOME_", javaTCTParentFolderName));
			}
			
		}
		
		
	}

}
