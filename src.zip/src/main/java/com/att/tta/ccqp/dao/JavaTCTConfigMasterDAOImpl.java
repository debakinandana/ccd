package com.att.tta.ccqp.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.att.tta.ccqp.schema.JavaTCTConfigMaster;

@Repository
public class JavaTCTConfigMasterDAOImpl implements JavaTCTConfigMasterDAO 
{
	public JavaTCTConfigMasterDAOImpl()
	{
		
	}
	
	@Autowired
	private HibernateUtil hibernateUtil;

	@Override	
	public long create(JavaTCTConfigMaster javaTCTConfigMaster) 
	{		
		return (Long) hibernateUtil.create(javaTCTConfigMaster);
	}

	@Override
	public JavaTCTConfigMaster update(JavaTCTConfigMaster javaTCTConfigMaster) 
	{
		return hibernateUtil.update(javaTCTConfigMaster);
	}

	@Override
	public void delete(JavaTCTConfigMaster javaTCTConfigMaster)
	{
		hibernateUtil.delete(javaTCTConfigMaster);
	}

	@Override
	public List<JavaTCTConfigMaster> fetchAllStrategy(String strategy) 
	{
		String query = "SELECT ID,KEY,TYPE,DEFAULT_VALUE,HINT,required,strategy FROM JAVA_TCT_CONFIG_MASTER e WHERE required=0 and strategy = '"+strategy+"'";
		
		@SuppressWarnings("unchecked")
		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		List<JavaTCTConfigMaster> GlobalModels = new ArrayList<JavaTCTConfigMaster>();

		for (Object[] globalModelObject : GlobalModelObjects) 
		{
			JavaTCTConfigMaster javaTCTStatusMaster = new JavaTCTConfigMaster();
			
			long id = Long.valueOf(String.valueOf(globalModelObject[0]));
			
			String key = (String) globalModelObject[1];
			String type = (String) globalModelObject[2];
			String default_value = (String) globalModelObject[3];
			String hint = (String) globalModelObject[4];
			Character required = (Character) globalModelObject[5];
			String strategyStr = (String) globalModelObject[6];

			javaTCTStatusMaster.setConfig_master_id(id);
			javaTCTStatusMaster.setKey(key);
			javaTCTStatusMaster.setType(type);
			javaTCTStatusMaster.setDefault_value(default_value);
			javaTCTStatusMaster.setHint(hint);
			javaTCTStatusMaster.setRequired(required);	
			javaTCTStatusMaster.setStrategy(strategyStr);
			
			GlobalModels.add(javaTCTStatusMaster);
		}
		
		return GlobalModels;	
	}

	@Override
	public JavaTCTConfigMaster fetch(long id) 
	{
		return hibernateUtil.fetchById(id, JavaTCTConfigMaster.class);
	}

	@Override
	public List<JavaTCTConfigMaster> fetchAll(String textStr) 
	{
		String query = "SELECT ID,KEY,TYPE,DEFAULT_VALUE,HINT,required,strategy FROM JAVA_TCT_CONFIG_MASTER e WHERE upper(key) like upper('%"+ textStr + "%')";
		
		@SuppressWarnings("unchecked")
		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		List<JavaTCTConfigMaster> GlobalModels = new ArrayList<JavaTCTConfigMaster>();

		for (Object[] globalModelObject : GlobalModelObjects) 
		{
			JavaTCTConfigMaster javaTCTStatusMaster = new JavaTCTConfigMaster();
			
			long id = Long.valueOf(String.valueOf(globalModelObject[0]));
			
			String key = (String) globalModelObject[1];
			String type = (String) globalModelObject[2];
			String default_value = (String) globalModelObject[3];
			String hint = (String) globalModelObject[4];
			Character required = (Character) globalModelObject[5];
			String strategy = (String) globalModelObject[6];

			javaTCTStatusMaster.setConfig_master_id(id);
			javaTCTStatusMaster.setKey(key);
			javaTCTStatusMaster.setType(type);
			javaTCTStatusMaster.setDefault_value(default_value);
			javaTCTStatusMaster.setHint(hint);
			javaTCTStatusMaster.setRequired(required);	
			javaTCTStatusMaster.setStrategy(strategy);
			GlobalModels.add(javaTCTStatusMaster);
		}
		
		return GlobalModels;		
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<JavaTCTConfigMaster> fetchAllRequired() 
	{
		String query = "SELECT distinct ID,KEY,TYPE,required FROM JAVA_TCT_CONFIG_MASTER  WHERE required='0'";
		
		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		List<JavaTCTConfigMaster> GlobalModels = new ArrayList<JavaTCTConfigMaster>();

		for (Object[] globalModelObject : GlobalModelObjects) 
		{
			JavaTCTConfigMaster javaTCTStatusMaster = new JavaTCTConfigMaster();
			
			//ID,KEY,TYPE,DEFAULT_VALUE,HINT,required
			long id = Long.valueOf(String.valueOf(globalModelObject[0]));
			
			String key = (String) globalModelObject[1];
			String type = (String) globalModelObject[2];			
			Character required = (Character) globalModelObject[3];

			javaTCTStatusMaster.setConfig_master_id(id);
			javaTCTStatusMaster.setKey(key);
			javaTCTStatusMaster.setType(type);			
			javaTCTStatusMaster.setRequired(required);			
			GlobalModels.add(javaTCTStatusMaster);
		}
		
		return GlobalModels;		
	}
}
