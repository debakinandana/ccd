package com.att.tta.ccqp.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ScriptExecutorTask 
{
	public ScriptExecutorTask() {
				
	}
	
	public void executeCommand(List<String> list) throws Exception 
	{
		
		System.out.println(list.toString());			
		String [] args = list.toArray(new String[list.size()]);
		ProcessBuilder p = new ProcessBuilder(args);
		Process p2 = p.start();
		
	}
	
	public List<String> call(List<String> list) throws Exception 
	{
			List<String> result = new ArrayList<String>();
		
		
			String [] args = list.toArray(new String[list.size()]);
			ProcessBuilder p = new ProcessBuilder(args);
			Process p2 = p.start();
			BufferedReader br = new BufferedReader(new InputStreamReader(p2.getInputStream()));
		    String line;
		    
		    while ((line = br.readLine()) != null)
		    {
		    	result.add(line);
		    	System.out.println(line);
		    }
		   	   
		    p2.equals(args);
		    p2.destroy();			
		

		    return result;
	}


}
