package com.att.tta.ccqp.model;

public class ClassInfo {
    String className;
    String classReportLink;

    public ClassInfo(String className, String classReportLink) {
	super();
	this.className = className;
	this.classReportLink = classReportLink;
    }

    public String getClassName() {
	return className;
    }

    public void setClassName(String className) {
	this.className = className;
    }

    public String getClassReportLink() {
	return classReportLink;
    }

    public void setClassReportLink(String classReportLink) {
	this.classReportLink = classReportLink;
    }
}
