package com.att.tta.ccqp.api;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.att.tta.ccqp.model.Response;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.service.JavaTCTAppService;
import com.att.tta.ccqp.service.JavaTCTConfigService;
import com.att.tta.ccqp.utils.GlobalKeys;


@RestController
@RequestMapping(value="/config")
public class JavaTCTConfigController
{

	@Autowired
	JavaTCTConfigService javaTCTConfigServiceImpl;
	
	@Autowired
	JavaTCTAppService javaTCTAppServiceImpl;
	
	
	@RequestMapping(value = "/create/{parent_id}", method=RequestMethod.POST)	
	public ResponseEntity<Response> create(@RequestBody JavaTCTConfig javaTCTConfig, @PathVariable Long parent_id) throws Exception 
    {	
		try
		{
			JavaTCTApp javaTCTApp =  javaTCTAppServiceImpl.fetch(parent_id);			
			javaTCTApp.getJavaTCTConfig().add(javaTCTConfig);			
			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
		}
		catch(Exception e)
		{
			System.out.println("Exception creating app "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/update/{parent_id}", method=RequestMethod.PUT)	
	public ResponseEntity<Response> update(@RequestBody JavaTCTConfig javaTCTConfig, @PathVariable Long parent_id ) throws Exception 
    {	
		try
		{
			JavaTCTApp javaTCTApp =  javaTCTAppServiceImpl.fetch(parent_id);
			
			Set<JavaTCTConfig> javaTCTConfigTemp = javaTCTApp.getJavaTCTConfig();
			
			if(javaTCTConfigTemp.contains(javaTCTConfig))
			{
				javaTCTConfigTemp.remove(javaTCTConfig);							
			}
			
			javaTCTConfigTemp.add(javaTCTConfig);	
			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
						
		}
		catch(Exception e)
		{
			System.out.println("Exception updating app "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}
	
	
	@RequestMapping(value = "/delete", method=RequestMethod.DELETE)	
	public ResponseEntity<Response> delete(@RequestBody JavaTCTConfig javaTCTConfig) throws Exception 
    {	
		try
		{
			javaTCTConfigServiceImpl.delete(javaTCTConfig);
		}
		catch(Exception e)
		{
			System.out.println("Exception creating app "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/delete/{id}", method=RequestMethod.DELETE)	
	public ResponseEntity<Response> deleteById(@PathVariable Long id) throws Exception 
    {	
		try
		{
			javaTCTConfigServiceImpl.delete(javaTCTConfigServiceImpl.fetch(id));
		}
		catch(Exception e)
		{
			System.out.println("Exception creating app "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/search/{id}", method=RequestMethod.GET)	
	public ResponseEntity<JavaTCTConfig> searchById(@PathVariable Long id) throws Exception 
    {	
		JavaTCTConfig javaTCTConfig=null;
		try
		{
			javaTCTConfig = javaTCTConfigServiceImpl.fetch(id);
		}
		catch(Exception e)
		{
			System.out.println("Exception creating app "+e.getMessage());
			return new ResponseEntity<JavaTCTConfig>(javaTCTConfig, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<JavaTCTConfig>(javaTCTConfig, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/search/all", method=RequestMethod.GET)	
	public ResponseEntity<List<JavaTCTConfig>> searchAll() throws Exception 
    {	
		List<JavaTCTConfig> javaTCTConfigs=null;
		try
		{
			javaTCTConfigs = javaTCTConfigServiceImpl.fetchAll();
		}
		catch(Exception e)
		{
			System.out.println("Exception creating app "+e.getMessage());
			return new ResponseEntity<List<JavaTCTConfig>>(javaTCTConfigs, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<List<JavaTCTConfig>>(javaTCTConfigs, HttpStatus.OK);
	}
	
	
		
}
