package com.att.tta.ccqp.api;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.att.tta.ccqp.model.PackageClass;
import com.att.tta.ccqp.model.Response;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.service.JavaTCTAppService;
import com.att.tta.ccqp.utils.ChangesProcessingAndValidation;
import com.att.tta.ccqp.utils.GlobalKeys;
import com.att.tta.ccqp.utils.GlobalUtils;

@RestController
@RequestMapping(value = "/upload")
public class JavaTCTAppUpload {

    @Autowired
    JavaTCTAppService javaTCTAppServiceImpl;
    @Autowired
    ChangesProcessingAndValidation changesProcessingAndValidation;

    @Value("${java_tct_home}")
    String javaTCTParentFolderName;

    @Value("${java_tct_coverage_report_home}")
    String javaTCTCoverageReportFolder;

    /*
     * @ExceptionHandler(Exception.class)
     * 
     * @ResponseStatus(value=HttpStatus.BAD_REQUEST) public
     * ResponseEntity<Response> handleException(Exception e ) { return new
     * ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED,
     * HttpStatus.BAD_REQUEST.toString(),e.getMessage()),
     * HttpStatus.BAD_REQUEST); }
     */

    @RequestMapping(value = "/source/{app_id}", method = RequestMethod.POST)
    public ResponseEntity<Response> uploadSource(@PathVariable Long app_id, @RequestParam("file") List<MultipartFile> files) throws Exception {
	return process("source", app_id, files);
    }

    @RequestMapping(value = "/classes/{app_id}", method = RequestMethod.POST)
    public ResponseEntity<Response> uploadClasses(@PathVariable Long app_id, @RequestParam("file") List<MultipartFile> files) throws Exception {
	return process("classes", app_id, files);
    }

    @RequestMapping(value = "/changes/{app_id}", method = RequestMethod.POST)
    public ResponseEntity<List<PackageClass>> uploadChanges(@PathVariable Long app_id, @RequestParam("file") MultipartFile multipart) throws Exception {
	String fileExtension = FilenameUtils.getExtension(multipart.getOriginalFilename());
	if ("xlsx".equals(fileExtension)) {
	    return changesProcessingAndValidation.xlsxFileNamesExtractor(multipart, app_id);
	} else if ("xls".equals(fileExtension)) {
	    return changesProcessingAndValidation.xlsFileNamesExtractor(multipart, app_id);
	} else if ("csv".equals(fileExtension)) {
	    return changesProcessingAndValidation.csvFileNamesExtractor(multipart, app_id);
	} else {
	    ArrayList<PackageClass> errorList = new ArrayList<PackageClass>();
	    errorList.add(new PackageClass("File not supported", null));
	    return new ResponseEntity<List<PackageClass>>(errorList, HttpStatus.BAD_REQUEST);
	}
    }

    @RequestMapping(value = "/test_flow/{appId}/{sessionId}", method = RequestMethod.POST)
    public ResponseEntity<Response> uploadTestFlow(@PathVariable Long appId, @PathVariable String sessionId, @RequestParam("file") MultipartFile multipartFile) throws Exception{
	if (multipartFile != null) {
	    JavaTCTApp javaTCTApp = javaTCTAppServiceImpl.fetch(appId);
	    String directory = javaTCTParentFolderName + "/" + javaTCTApp.getAppFolderName() + "/" + "testFlow_" + sessionId;
	    new File(directory).mkdir();
	    File file = new File(directory + "/" + multipartFile.getOriginalFilename());
	    FileOutputStream fileOutputStream = new FileOutputStream(file); 
	    fileOutputStream.write(multipartFile.getBytes());
	    fileOutputStream.close(); 
	    return new ResponseEntity<Response>(new Response("File uploaded", HttpStatus.OK.toString()), HttpStatus.OK);
	}
	return new ResponseEntity<Response>(new Response("No file uploaded", HttpStatus.BAD_REQUEST.toString()), HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<Response> process(String type, Long app_id, List<MultipartFile> files) {

	String typeFolder = "src";

	if ("classes".equals(type)) {
	    typeFolder = "bin";
	} else if ("source".equals(type)) {
	    typeFolder = "src";
	} else {
	    return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.BAD_REQUEST.toString(),
		    " Request should contains /app/upload/source or /app/upload/classes"), HttpStatus.BAD_REQUEST);
	}

	if (files != null && files.size() > 0) {
	    try {
		JavaTCTApp javaTCTApp = javaTCTAppServiceImpl.fetch(app_id);

		List<String> uploadErrorFile = new ArrayList<String>();

		/**
		 * Delete existing source/classes
		 */
		String directory = javaTCTParentFolderName + File.separator + javaTCTApp.getAppFolderName() + File.separator + typeFolder;
		FileUtils.deleteDirectory(new File(directory));
		new File(directory).mkdir();

		for (MultipartFile multipartFile : files) {
		    Boolean status = GlobalUtils.uploadSource(javaTCTParentFolderName, javaTCTApp.getAppFolderName(), multipartFile, multipartFile.getOriginalFilename(), typeFolder);

		    if (!status) {
			uploadErrorFile.add(multipartFile.getOriginalFilename());
		    }
		}

		if (uploadErrorFile.size() == files.size()) {
		    return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.BAD_REQUEST.toString()), HttpStatus.BAD_REQUEST);
		} else if (uploadErrorFile.size() > 0) {
		    return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString(), "Not able to upload " + uploadErrorFile.toString()),
			    HttpStatus.CREATED);
		}

		Set<JavaTCTConfig> javaTCTConfigTemp = new HashSet<JavaTCTConfig>(javaTCTApp.getJavaTCTConfig());

		if ("classes".equals(type)) {
		    for (Iterator<JavaTCTConfig> iterator = javaTCTConfigTemp.iterator(); iterator.hasNext();) {
			JavaTCTConfig javaTCTConfig = (JavaTCTConfig) iterator.next();

			if ("class_file_uploaded".equals(javaTCTConfig.getConfig_key())) {
			    javaTCTApp.getJavaTCTConfig().remove(javaTCTConfig);
			}
		    }

		    if (javaTCTConfigTemp.size() > 0) {
			javaTCTApp.getJavaTCTConfig().add(new JavaTCTConfig("class_file_uploaded", "true", "status"));
			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
		    } else {

			javaTCTConfigTemp = new HashSet<JavaTCTConfig>();
			javaTCTConfigTemp.add(new JavaTCTConfig("class_file_uploaded", "true", "status"));
			javaTCTApp.setJavaTCTConfig(javaTCTConfigTemp);
			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
		    }

		    Boolean status = GlobalUtils.extractClassPackagesToInclude(javaTCTParentFolderName, javaTCTApp.getAppFolderName(), typeFolder);

		} else if ("source".equals(type)) {
		    for (Iterator<JavaTCTConfig> iterator = javaTCTConfigTemp.iterator(); iterator.hasNext();) {
			JavaTCTConfig javaTCTConfig = (JavaTCTConfig) iterator.next();

			if ("source_file_uploaded".equals(javaTCTConfig.getConfig_key())) {
			    javaTCTApp.getJavaTCTConfig().remove(javaTCTConfig);
			}
		    }

		    if (javaTCTConfigTemp.size() > 0) {
			javaTCTApp.getJavaTCTConfig().add(new JavaTCTConfig("source_file_uploaded", "true", "status"));

			for (JavaTCTConfig javatct : javaTCTApp.getJavaTCTConfig()) {
			    System.out.println(javatct.getConfig_id() + "	" + javatct.getConfig_key() + "	" + javatct.getConfig_type() + "	" + javatct.getConfig_value());
			}

			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
		    } else {
			javaTCTConfigTemp = new HashSet<JavaTCTConfig>();
			javaTCTConfigTemp.add(new JavaTCTConfig("source_file_uploaded", "true", "status"));
			javaTCTApp.setJavaTCTConfig(javaTCTConfigTemp);
			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
		    }
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	    } catch (DataAccessException e) {
		System.out.println("Exception uploading source " + e.getMessage());
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	    } catch (Exception e) {
		System.out.println("Exception uploading source " + e.getMessage());
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	} else {
	    return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), "Empty file can not be uploaded"), HttpStatus.NO_CONTENT);
	}

    }

}
