package com.att.tta.ccqp.dao;

import java.util.List;

import com.att.tta.ccqp.schema.JavaTCTConfig;


public interface JavaTCTConfigDAO 
{
	
	public long create(JavaTCTConfig javaTCTConfig);
	public JavaTCTConfig update(JavaTCTConfig javaTCTConfig);	
	public void delete(JavaTCTConfig javaTCTConfig);
	public List<JavaTCTConfig> fetchAll();
	public JavaTCTConfig fetch(long id);
	public List<JavaTCTConfig> fetchAll(String textStr);

}
