package com.att.tta.ccqp.schema;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "JAVA_TCT_APP_CONFIG",uniqueConstraints=@UniqueConstraint(columnNames={"CONFIG_KEY","CONFIG_VALUE","CONFIG_TYPE","APP_ID"}))
public class JavaTCTConfig implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	@Id 
	@SequenceGenerator(name = "JAVA_TCT_CONFIG_SEQ", sequenceName="JAVA_TCT_CONFIG_SEQ", allocationSize=1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "JAVA_TCT_CONFIG_SEQ")	
	@Column(name="CONFIG_ID")
	private Long config_id;
		
	@Column(nullable=false,name="CONFIG_KEY")
	private String config_key;
	
	@Column(nullable=false,name="CONFIG_VALUE")
	private String config_value;
	
	@Column(nullable=false,name="CONFIG_TYPE")
	private String config_type;		
			
		
	public JavaTCTConfig() 
	{
		
	}
	
	public JavaTCTConfig(String config_key, String config_value,
			String config_type) {
		super();
		this.config_key = config_key;
		this.config_value = config_value;
		this.config_type = config_type;
	}





	public JavaTCTConfig(Long config_id, String config_key,
			String config_value, String config_type) {
		super();
		this.config_id = config_id;
		this.config_key = config_key;
		this.config_value = config_value;
		this.config_type = config_type;
	}





	public Long getConfig_id() {
		return config_id;
	}





	public void setConfig_id(Long config_id) {
		this.config_id = config_id;
	}





	public String getConfig_key() {
		return config_key;
	}





	public void setConfig_key(String config_key) {
		this.config_key = config_key;
	}





	public String getConfig_value() {
		return config_value;
	}





	public void setConfig_value(String config_value) {
		this.config_value = config_value;
	}





	public String getConfig_type() {
		return config_type;
	}





	public void setConfig_type(String config_type) {
		this.config_type = config_type;
	}



	@Override
	public boolean equals(Object obj) 
	{
		
		if(this.config_id==null)
		{
			return false;
		}
		
		JavaTCTConfig local = (JavaTCTConfig) obj;
		
		if(local.getConfig_id() == this.config_id)
		{
			return true;
		}
		
		return false;
	}
	
	@Override
	public int hashCode() 
	{
		if(this.config_id==null)
		{
			return super.hashCode();
		}
		
		return this.config_id.hashCode();
	}

	
	
}
