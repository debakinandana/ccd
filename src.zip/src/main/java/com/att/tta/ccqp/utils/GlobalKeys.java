package com.att.tta.ccqp.utils;

public interface GlobalKeys 
{

	public static final String RESPONSE_MESSAGE_SUCCESS="success";
	public static final String RESPONSE_MESSAGE_FAILED="failed";
	
	
	
}
