package com.att.tta.ccqp.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.att.tta.ccqp.model.ExecDashboardOverAllStats;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;

@Repository
public class JavaTCTAppDAOImpl implements JavaTCTAppDAO
{
	public JavaTCTAppDAOImpl()
	{

	}

	@Autowired
	private HibernateUtil hibernateUtil;

	@Override
	public long create(JavaTCTApp javaTCTApp)
	{
		return (Long) hibernateUtil.create(javaTCTApp);
	}

	@Override
	public JavaTCTApp update(JavaTCTApp javaTCTApp)
	{
		
		for(JavaTCTConfig javatct: javaTCTApp.getJavaTCTConfig())
		{
			System.out.println(javatct.getConfig_id());
			
		}
		
		return hibernateUtil.update(javaTCTApp);
	}

	@Override
	public void delete(JavaTCTApp javaTCTApp)
	{
		hibernateUtil.delete(javaTCTApp);
	}

	@Override
	public List<JavaTCTApp> fetchAll()
	{
		// return hibernateUtil.fetchAll(JavaTCTApp.class);
		String query = "SELECT APP_ID,APP_NAME,HOST_NAME,VERSION,DESCRIPTION,STRATEGY,OWNER_EMAIL_ID,APP_ENV,RELEASE,BUILD FROM JAVA_TCT_APP order by APP_NAME";

		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		List<JavaTCTApp> GlobalModels = new ArrayList<JavaTCTApp>();

		for (Object[] globalModelObject : GlobalModelObjects)
		{
			JavaTCTApp javaTCTStatusMaster = new JavaTCTApp();

			long id = Long.valueOf(String.valueOf(globalModelObject[0]));
			
			String app_name = (String) globalModelObject[1];
			String host_name = (String) globalModelObject[2];
			String version = (String) globalModelObject[3];
			String desc = (String) globalModelObject[4];
			String strategy = (String) globalModelObject[5];
			String owner_email_id = (String) globalModelObject[6];
			String app_env = (String) globalModelObject[7];
			String release = (String) globalModelObject[8];
			String build = (String) globalModelObject[9];

			javaTCTStatusMaster.setApp_id(id);
			javaTCTStatusMaster.setApp_name(app_name);
			javaTCTStatusMaster.setHost_name(host_name);
			javaTCTStatusMaster.setVersion(version);
			javaTCTStatusMaster.setDesc(desc);
			javaTCTStatusMaster.setStrategy(strategy);
			javaTCTStatusMaster.setOwner_email_id(owner_email_id);
			javaTCTStatusMaster.setApp_env(app_env);
			javaTCTStatusMaster.setRelease(release);
			javaTCTStatusMaster.setBuild(build);
			GlobalModels.add(javaTCTStatusMaster);

		}

		return GlobalModels;
	}

	@Override
	public JavaTCTApp fetch(long id)
	{
		return hibernateUtil.fetchById(id, JavaTCTApp.class);
	}

	@Override
	public List<JavaTCTApp> fetchAll(String textStr)
	{
		String query = "SELECT APP_ID,APP_NAME,HOST_NAME,VERSION,DESCRIPTION,STRATEGY,OWNER_EMAIL_ID,APP_ENV,RELEASE,BUILD FROM JAVA_TCT_APP e WHERE upper(e.app_name) like upper('%" + textStr + "%')";

		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		List<JavaTCTApp> GlobalModels = new ArrayList<JavaTCTApp>();

		for (Object[] globalModelObject : GlobalModelObjects)
		{
			JavaTCTApp javaTCTStatusMaster = new JavaTCTApp();

			long id = Long.valueOf(String.valueOf(globalModelObject[0]));
			String app_name = (String) globalModelObject[1];
			String host_name = (String) globalModelObject[2];
			String version = (String) globalModelObject[3];
			String desc = (String) globalModelObject[4];
			String strategy = (String) globalModelObject[5];
			String owner_email_id = (String) globalModelObject[6];
			String app_env = (String) globalModelObject[7];
			String release = (String) globalModelObject[8];
			String build = (String) globalModelObject[9];
			
			
			javaTCTStatusMaster.setApp_id(id);
			javaTCTStatusMaster.setApp_name(app_name);
			javaTCTStatusMaster.setHost_name(host_name);
			javaTCTStatusMaster.setVersion(version);
			javaTCTStatusMaster.setDesc(desc);
			javaTCTStatusMaster.setStrategy(strategy);
			javaTCTStatusMaster.setOwner_email_id(owner_email_id);
			javaTCTStatusMaster.setApp_env(app_env);
			javaTCTStatusMaster.setRelease(release);
			javaTCTStatusMaster.setBuild(build);
			GlobalModels.add(javaTCTStatusMaster);
		}

		return GlobalModels;
	}

	@Override
	public Long giveMeAvailablePort()
	{
		String query = "select nvl(max(to_number(config_value) + 1),6300) as port  from JAVA_TCT_APP_CONFIG  where config_key='tcpport'";
		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);

		if (GlobalModelObjects.size() <= 0)
		{
			return 6300L;
		}

		long id = Long.valueOf(String.valueOf(GlobalModelObjects.get(0)));
		return id;
	}

	@Override
	public ExecDashboardOverAllStats fetchExecDashboardOverAllStats()
	{
		String query = "select count(distinct app_name) app_names,count(distinct host_name) host_names,count(distinct owner_email_id) email_ids  from JAVA_TCT_APP";

		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		ExecDashboardOverAllStats dashboardOverAllStats = null;

		for (Object[] globalModelObject : GlobalModelObjects)
		{
			long app_count = Long.valueOf(String.valueOf(globalModelObject[0]));
			long host_count = Long.valueOf(String.valueOf(globalModelObject[1]));
			long email_count = Long.valueOf(String.valueOf(globalModelObject[2]));

			dashboardOverAllStats = new ExecDashboardOverAllStats(app_count, host_count, email_count);

		}

		return dashboardOverAllStats;
	}
}
