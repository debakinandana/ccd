package com.att.tta.ccqp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tta.ccqp.dao.JavaTCTConfigDAO;
import com.att.tta.ccqp.schema.JavaTCTConfig;


@Service
public class JavaTCTConfigServiceImpl implements JavaTCTConfigService
{
	
	@Autowired
	JavaTCTConfigDAO javaTCTConfigDAOImpl;
	
	@Override
	public long create(JavaTCTConfig javaTCTConfig) 
	{
		return javaTCTConfigDAOImpl.create(javaTCTConfig);
	}

	@Override
	public JavaTCTConfig update(JavaTCTConfig javaTCTConfig) 
	{
		return javaTCTConfigDAOImpl.update(javaTCTConfig);
	}
	
	@Override
	public void delete(JavaTCTConfig javaTCTConfig)
	{
		javaTCTConfigDAOImpl.delete(javaTCTConfig);		
	}

	@Override	
	public List<JavaTCTConfig> fetchAll() 
	{
		return javaTCTConfigDAOImpl.fetchAll();
	}

	@Override
	public JavaTCTConfig fetch(long id)
	{
		return javaTCTConfigDAOImpl.fetch(id);
	}

	@Override
	public List<JavaTCTConfig> fetchAll(String textStr)
	{
		return javaTCTConfigDAOImpl.fetchAll(textStr);
	}

}
