package com.att.tta.ccqp.utils;

import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.att.tta.ccqp.model.ClassInfo;
import com.att.tta.ccqp.model.PackageClass;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.service.JavaTCTAppService;
@Component
public class ChangesProcessingAndValidation {
    @Autowired
    public JavaTCTAppService javaTCTAppServiceImpl;
    @Value("${java_tct_home}")
    public String javaTCTParentFolderName;
    @Value("${java_tct_coverage_report_home}")
    public String javaTCTCoverageReportFolder;
    @Value("${java_tct_report_server_address}")
    public String javaReportServerAddress;

    public ResponseEntity<List<PackageClass>> xlsxFileNamesExtractor(MultipartFile multipart, Long app_id) throws Exception {
	Set<String> fileNames = new HashSet<String>();

	XSSFWorkbook workbook = new XSSFWorkbook(multipart.getInputStream());
	XSSFSheet worksheet = workbook.getSheetAt(0);
	Iterator<Row> rowIterator = worksheet.iterator();
	while (rowIterator.hasNext()) {
	    Row row = rowIterator.next();
	    Cell cell = row.getCell(7);
	    if (cell != null) {
		fileNames.add(cell.getStringCellValue());
	    }
	}
	return processFileNames(fileNames, app_id);
    }

    public ResponseEntity<List<PackageClass>> xlsFileNamesExtractor(MultipartFile multipart, Long app_id) throws Exception {
	Set<String> fileNames = new HashSet<String>();

	HSSFWorkbook workbook = new HSSFWorkbook(multipart.getInputStream());
	HSSFSheet worksheet = workbook.getSheetAt(0);
	Iterator<Row> rowIterator = worksheet.iterator();
	while (rowIterator.hasNext()) {
	    Row row = rowIterator.next();
	    Cell cell = row.getCell(7);
	    if (cell != null) {
		fileNames.add(cell.getStringCellValue());
	    }
	}
	return processFileNames(fileNames, app_id);
    }

    public ResponseEntity<List<PackageClass>> csvFileNamesExtractor(MultipartFile multipart, Long app_id) throws Exception {
	Set<String> fileNames = new HashSet<String>();

	CSVParser parser = new CSVParser(new InputStreamReader(multipart.getInputStream()), CSVFormat.EXCEL.withHeader());
	for (CSVRecord record : parser) {
	    fileNames.add(record.get(7));
	}
	parser.close();
	return processFileNames(fileNames, app_id);
    }

    public ResponseEntity<List<PackageClass>> processFileNames(Set<String> fileNames, Long app_id) throws Exception {
	
	if (fileNames.size() == 0) {
	    ArrayList<PackageClass> errorList = new ArrayList<PackageClass>();
	    errorList.add(new PackageClass("No class filenames found", null));
	    return new ResponseEntity<List<PackageClass>>(errorList, HttpStatus.BAD_REQUEST);
	}
	
	ArrayList<PackageClass> packageClasses = new ArrayList<PackageClass>();
	Set<String> reportFileNames = new HashSet<String>();

	JavaTCTApp javaTCTApp = javaTCTAppServiceImpl.fetch(app_id);
	String serverMergeSessionId = "not found";
	for (JavaTCTConfig javaTCTConfig : javaTCTApp.getJavaTCTConfig()) {
	    if ("server_merge_sessionid".equals(javaTCTConfig.getConfig_key())) {
		serverMergeSessionId = javaTCTConfig.getConfig_value();
	    }
	}
	String reportFolderRootPath = javaTCTCoverageReportFolder + "/" + serverMergeSessionId;
	
	getAbsoluteFileNames(reportFileNames, reportFolderRootPath);

	Set<String> normalizedReportFileNames = normalizeFileNames(reportFileNames, reportFolderRootPath + "/", ".html", "/");
	Set<String> normalizedChangeFileNames = normalizeFileNames(fileNames, "/src/main/java/", ".java", "/");
	
	if (normalizedChangeFileNames.size() == 0) {
	    ArrayList<PackageClass> errorList = new ArrayList<PackageClass>();
	    errorList.add(new PackageClass("No class filenames found", null));
	    return new ResponseEntity<List<PackageClass>>(errorList, HttpStatus.BAD_REQUEST);
	}

	String reportFilesHttpPathPrefix = javaReportServerAddress +"/" + serverMergeSessionId;
	for (String name : normalizedChangeFileNames) {
	    if (!name.contains(".")) {
		continue;
	    }
	    String packageName = name.substring(0, name.lastIndexOf("."));
	    String classReportName = name.substring(name.lastIndexOf(".") + 1, name.length());
	    String classReportLink = null;
	    if (normalizedReportFileNames.contains(name)) {
		classReportLink = reportFilesHttpPathPrefix + "/" + packageName + "/" + classReportName + ".html";
	    }
	    ClassInfo classInfo = new ClassInfo(classReportName, classReportLink);
	    int index = packageClasses.indexOf(new PackageClass(packageName, null));
	    if (index >= 0) {
		packageClasses.get(index).getClassNames().add(classInfo);
	    } else {
		ArrayList<ClassInfo> newList = new ArrayList<ClassInfo>();
		newList.add(classInfo);
		packageClasses.add(new PackageClass(packageName, newList));
	    }
	}
	return new ResponseEntity<List<PackageClass>>(packageClasses, HttpStatus.OK);
    }

//    static int fileCount = 0; //remove these two lines
//    static int folderCount = 0;
    public void getAbsoluteFileNames(Set<String> fileNamesSet, String folderName) {
	
	System.out.println("FolderName:" + folderName);
	File folder = new File(folderName);
	if (!folder.exists()) {
	    return;
	}
	File[] listOfFiles = folder.listFiles();

	for (int i = 0; i < listOfFiles.length; i++) {
	    if (listOfFiles[i].isFile()) {
//		fileCount++;
		fileNamesSet.add(listOfFiles[i].getAbsolutePath().replaceAll("\\\\", "/"));
		System.out.println("File " + listOfFiles[i].getAbsolutePath());
	    } else if (listOfFiles[i].isDirectory()) {
//		folderCount++;
		getAbsoluteFileNames(fileNamesSet, listOfFiles[i].getAbsolutePath().replaceAll("\\\\", "/"));
	    }
	}
    }

    public Set<String> normalizeFileNames(Set<String> absoluteFileNames, String prefix, String suffix, String seperator) {
	
	Set<String> returnSet = new HashSet<String>();
	System.out.println(prefix + suffix + seperator);
	for (String absoluteFileName : absoluteFileNames) {
	    if (absoluteFileName.contains(suffix) && absoluteFileName.contains(prefix)) {
		System.out.println(absoluteFileName);
		String tempName = absoluteFileName.substring(absoluteFileName.indexOf(prefix) + prefix.length(), absoluteFileName.indexOf(suffix)).replaceAll(seperator, ".");
		returnSet.add(tempName);
	    }
	}
	return returnSet;
    }
}