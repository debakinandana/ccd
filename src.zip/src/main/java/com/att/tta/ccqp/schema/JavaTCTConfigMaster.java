package com.att.tta.ccqp.schema;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "JAVA_TCT_CONFIG_MASTER",uniqueConstraints=@UniqueConstraint(columnNames={"TYPE","KEY","DEFAULT_VALUE","REQUIRED","STRATEGY"}))
public class JavaTCTConfigMaster implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	@Id 
	@SequenceGenerator(name = "JAVA_TCT_CONFIG_MASTER_SEQ", sequenceName="JAVA_TCT_CONFIG_MASTER_SEQ", allocationSize=100)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "JAVA_TCT_CONFIG_MASTER_SEQ")
	@Column(name="ID")
	private Long config_master_id;
	
	@Column(nullable=false,name="TYPE")
	private String type;
	
	@Column(nullable=false,name="KEY")
	private String key;
	
	@Column(nullable=false,name="DEFAULT_VALUE")
	private String default_value;
	
	@Column(nullable=true,name="HINT",length=3000)
	private String hint;
	
	@Column(nullable=false,name="STRATEGY")
	private String strategy;
	
	@Column(nullable=false,name="REQUIRED",columnDefinition="char default 1")
	private Character required;
	
	public JavaTCTConfigMaster() 
	{
		
	}
	

	public JavaTCTConfigMaster(Long config_master_id, String type, String key,
			String default_value, String hint, String strategy,
			Character required) {
		super();
		this.config_master_id = config_master_id;
		this.type = type;
		this.key = key;
		this.default_value = default_value;
		this.hint = hint;
		this.strategy = strategy;
		this.required = required;
	}





	public Long getConfig_master_id() {
		return config_master_id;
	}





	public void setConfig_master_id(Long config_master_id) {
		this.config_master_id = config_master_id;
	}





	public String getType() {
		return type;
	}





	public void setType(String type) {
		this.type = type;
	}





	public String getKey() {
		return key;
	}





	public void setKey(String key) {
		this.key = key;
	}





	public String getDefault_value() {
		return default_value;
	}





	public void setDefault_value(String default_value) {
		this.default_value = default_value;
	}





	public String getHint() {
		return hint;
	}





	public void setHint(String hint) {
		this.hint = hint;
	}





	public String getStrategy() {
		return strategy;
	}





	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}





	public Character getRequired() {
		return required;
	}





	public void setRequired(Character required) {
		this.required = required;
	}





	@Override
	public boolean equals(Object obj) 
	{		
		if(this.config_master_id==null)
		{
			return false;
		}
		
		JavaTCTConfigMaster local = (JavaTCTConfigMaster) obj;
		
		if(local.getConfig_master_id() == this.config_master_id)
		{
			return true;
		}
		
		return false;
	}
	
	@Override
	public int hashCode() 
	{
		if(this.config_master_id==null)
		{
			return super.hashCode();
		}
		
		return this.config_master_id.hashCode();
	}

	
}
