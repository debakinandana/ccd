package com.att.tta.ccqp.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.att.tta.ccqp.schema.JavaTCTConfig;

@Repository
public class JavaTCTConfigDAOImpl implements JavaTCTConfigDAO 
{
	public JavaTCTConfigDAOImpl()
	{
		
	}
	
	@Autowired
	private HibernateUtil hibernateUtil;

	@Override	
	public long create(JavaTCTConfig javaTCTConfig) 
	{		
		return (Long) hibernateUtil.create(javaTCTConfig);
	}

	@Override
	public JavaTCTConfig update(JavaTCTConfig javaTCTConfig) 
	{
		return hibernateUtil.update(javaTCTConfig);
	}

	
	@Override
	public void delete(JavaTCTConfig javaTCTConfig) 
	{
		hibernateUtil.delete(javaTCTConfig);		
	}
	

	@Override
	public List<JavaTCTConfig> fetchAll() 
	{
		return hibernateUtil.fetchAll(JavaTCTConfig.class);
	}

	@Override
	public JavaTCTConfig fetch(long id) 
	{
		return hibernateUtil.fetchById(id, JavaTCTConfig.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<JavaTCTConfig> fetchAll(String textStr) 
	{
		String query = "SELECT e.* FROM JAVA_TCT_APP_CONFIG e WHERE upper(e.config_key) like upper('%"+ textStr + "%')";
		
		List<Object[]> GlobalModelObjects = hibernateUtil.fetchAll(query);
		List<JavaTCTConfig> GlobalModels = new ArrayList<JavaTCTConfig>();

		for (Object[] globalModelObject : GlobalModelObjects) 
		{
			JavaTCTConfig tctConfig = new JavaTCTConfig();
			
			long id = Long.valueOf(String.valueOf(globalModelObject[0]));
			String config_key = (String) globalModelObject[1];
			String config_type = (String) globalModelObject[2];
			String config_value = (String) globalModelObject[3];
			//String app_id = (String) globalModelObject[4];

			tctConfig.setConfig_id(id);
			tctConfig.setConfig_key(config_key);
			tctConfig.setConfig_type(config_type);
			tctConfig.setConfig_value(config_value);			
			GlobalModels.add(tctConfig);
		}
		
		return GlobalModels;		
	}
}
