package com.att.tta.ccqp.service;

import java.util.List;
import java.util.Map;

import com.att.tta.ccqp.model.ExecDashboardOverAllStats;
import com.att.tta.ccqp.model.KeyValue;
import com.att.tta.ccqp.schema.JavaTCTApp;

public interface JavaTCTAppService
{

	public long create(JavaTCTApp javaTCTApp) throws Exception;

	public long createApplication(JavaTCTApp javaTCTApp) throws Exception;

	public JavaTCTApp update(JavaTCTApp javaTCTApp) throws Exception;

	public JavaTCTApp updateConfig(JavaTCTApp javaTCTApp) throws Exception;

	public void delete(JavaTCTApp javaTCTApp) throws Exception;

	public List<JavaTCTApp> fetchAll() throws Exception;

	public JavaTCTApp fetch(long id) throws Exception;

	public List<JavaTCTApp> fetchAll(String textStr) throws Exception;

	public Map<String, String> fetchCoverageReportDetail() throws Exception;

	public List<KeyValue> fetchAllPackagesClassStrutures(String appName) throws Exception;

	public ExecDashboardOverAllStats fetchExecDashboardOverAllStats() throws Exception;

	public Boolean archiveReport(long id) throws Exception;

	public String startNewSession(long id) throws Exception;

	public String stopNewSession(String sessionData) throws Exception;

	public List<KeyValue> fetchSessinList(long id) throws Exception;

}
