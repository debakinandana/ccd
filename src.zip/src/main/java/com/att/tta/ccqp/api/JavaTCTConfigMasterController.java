package com.att.tta.ccqp.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.att.tta.ccqp.model.Response;
import com.att.tta.ccqp.schema.JavaTCTConfigMaster;
import com.att.tta.ccqp.service.JavaTCTConfigMasterService;
import com.att.tta.ccqp.utils.GlobalKeys;


@RestController
@RequestMapping(value="/master/config")
public class JavaTCTConfigMasterController
{

	@Autowired
	JavaTCTConfigMasterService javaTCTConfigMaterServiceImpl;
	
	
	@RequestMapping(value = "/search/all/{strategy}", method=RequestMethod.GET)	
	public ResponseEntity<List<JavaTCTConfigMaster>> searchAllStrategy(@PathVariable String strategy) throws Exception 
    {	
		
		List<JavaTCTConfigMaster> javaTCTStatusMasters=null;
		
		try
		{
			javaTCTStatusMasters = javaTCTConfigMaterServiceImpl.fetchAllStrategy(strategy);
		}
		catch(Exception e)
		{
			System.out.println("Exception /search/all Master config "+e.getMessage());
			return new ResponseEntity<List<JavaTCTConfigMaster>>(javaTCTStatusMasters, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<List<JavaTCTConfigMaster>>(javaTCTStatusMasters, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/search/{text}", method=RequestMethod.GET)	
	public ResponseEntity<List<JavaTCTConfigMaster>> searchAll(@PathVariable String text) throws Exception 
    {	
		
		List<JavaTCTConfigMaster> javaTCTStatusMasters=null;
		
		try
		{
			javaTCTStatusMasters = javaTCTConfigMaterServiceImpl.fetchAll(text);
		}
		catch(Exception e)
		{
			System.out.println("Exception /search/{text} Master config "+e.getMessage());
			return new ResponseEntity<List<JavaTCTConfigMaster>>(javaTCTStatusMasters, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<List<JavaTCTConfigMaster>>(javaTCTStatusMasters, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/search/{id}", method=RequestMethod.GET)	
	public ResponseEntity<JavaTCTConfigMaster> searchById(@PathVariable Long id) throws Exception 
    {	
		
		JavaTCTConfigMaster javaTCTStatusMasters=null;
		
		try
		{
			javaTCTStatusMasters = javaTCTConfigMaterServiceImpl.fetch(id);
		}
		catch(Exception e)
		{
			System.out.println("Exception /search/{id} Master config "+e.getMessage());
			return new ResponseEntity<JavaTCTConfigMaster>(javaTCTStatusMasters, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<JavaTCTConfigMaster>(javaTCTStatusMasters, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/create", method=RequestMethod.POST)	
	public ResponseEntity<Response> create(@RequestBody JavaTCTConfigMaster tctStatusMaster) throws Exception 
    {	
		try
		{
			Long result = javaTCTConfigMaterServiceImpl.create(tctStatusMaster);
		}
		catch(Exception e)
		{
			System.out.println("Exception creating Master config "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/create/multiple", method=RequestMethod.POST)	
	public ResponseEntity<Response> createMiltiple(@RequestBody List<JavaTCTConfigMaster> tctStatusMasters) throws Exception 
    {	
		try
		{
			for (JavaTCTConfigMaster javaTCTStatusMaster : tctStatusMasters) 
			{				
				Long result = javaTCTConfigMaterServiceImpl.create(javaTCTStatusMaster);				
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception /create/multiple Master config "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}
	
	
	
	@RequestMapping(value = "/update", method=RequestMethod.PUT)	
	public ResponseEntity<JavaTCTConfigMaster> update(@RequestBody JavaTCTConfigMaster tctStatusMaster) throws Exception 
    {	
		
		JavaTCTConfigMaster javaTCTStatusMaster = null;
		
		try
		{
			javaTCTStatusMaster = javaTCTConfigMaterServiceImpl.update(tctStatusMaster);
		}
		catch(Exception e)
		{
			System.out.println("Exception /update Master config "+e.getMessage());
			return new ResponseEntity<JavaTCTConfigMaster>(javaTCTStatusMaster, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<JavaTCTConfigMaster>(javaTCTStatusMaster, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/update/multiple", method=RequestMethod.PUT)	
	public ResponseEntity<List<JavaTCTConfigMaster>> updateMultiple(@RequestBody List<JavaTCTConfigMaster> tctStatusMaster) throws Exception 
    {	
		List<JavaTCTConfigMaster> javaTCTStatusMasters = new ArrayList<JavaTCTConfigMaster>();
		
		try
		{
			for (JavaTCTConfigMaster javaTCTStatusMaster : tctStatusMaster)
			{
				
				javaTCTStatusMasters.add(javaTCTConfigMaterServiceImpl.update(javaTCTStatusMaster));
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception /update/multiple Master config "+e.getMessage());
			return new ResponseEntity<List<JavaTCTConfigMaster>>(javaTCTStatusMasters, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<List<JavaTCTConfigMaster>>(javaTCTStatusMasters, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/delete", method=RequestMethod.DELETE)	
	public ResponseEntity<Response> delete(@RequestBody JavaTCTConfigMaster javaTCTConfigMaster) throws Exception 
    {	
		try
		{
			javaTCTConfigMaterServiceImpl.delete(javaTCTConfigMaster);
		}
		catch(Exception e)
		{
			System.out.println("Exception /update Master config "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.OK.toString()),HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/delete/{id}", method=RequestMethod.DELETE)	
	public ResponseEntity<Response> deleteById(@PathVariable Long id) throws Exception 
    {	
		try
		{
			javaTCTConfigMaterServiceImpl.delete(javaTCTConfigMaterServiceImpl.fetch(id));
		}
		catch(Exception e)
		{
			System.out.println("Exception /update Master config "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.OK.toString()),HttpStatus.OK);
	}
		
}
