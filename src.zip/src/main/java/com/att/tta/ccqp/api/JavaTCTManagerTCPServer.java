package com.att.tta.ccqp.api;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.att.tta.ccqp.model.Response;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.service.JavaTCTAppService;
import com.att.tta.ccqp.utils.GlobalKeys;
import com.att.tta.ccqp.utils.GlobalUtils;
import com.att.tta.ccqp.utils.ScriptExecutorTask;


@RestController
@RequestMapping(value="/tcp-server")
public class JavaTCTManagerTCPServer 
{
	
	@Autowired
	JavaTCTAppService javaTCTAppServiceImpl;
	
	@Value("${java_tct_home}")
	String java_tct_home;
	
	@Value("${java_tct_start_client_script_name}")
	String java_tct_start_client_script_name;
	
	@Value("${java_tct_stop_client_script_name}")
	String java_tct_stop_client_script_name;
	
	@Value("${java_tct_status_client_script_name}")
	String java_tct_status_client_script_name;

	@RequestMapping(value = "/start/{id}", method=RequestMethod.POST)	
	public ResponseEntity<Response> startServer(@PathVariable Long id) throws Exception 
    {	
		try
		{
			//Need to write code to validate if port is already running or acquired			
			JavaTCTApp javaTCTApp= javaTCTAppServiceImpl.fetch(id);
			
			List<String> args = new ArrayList<String>();	
			
			if(GlobalUtils.isWindows())
			{
				args.add(java_tct_home+File.separator+"bin"+File.separator+java_tct_start_client_script_name+".bat");
			}
			else
			{
				args.add(java_tct_home+File.separator+"bin"+File.separator+java_tct_start_client_script_name+".sh");
			}			
			
			args.add(javaTCTApp.getAppFolderName());
			new ScriptExecutorTask().executeCommand(args);
		}
		catch(Exception e)
		{
			System.out.println("Exception starting server "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString(),"Server Started"), HttpStatus.OK);
		
    }
	
	@RequestMapping(value = "/stop/{id}", method=RequestMethod.DELETE)	
	public ResponseEntity<Response> stopServer(@PathVariable Long id) throws Exception 
    {	
		List<String> result = null;
		
		try
		{
			//Need to write code to validate if port is already running or acquired
			
			JavaTCTApp javaTCTApp= javaTCTAppServiceImpl.fetch(id);			
			Set<JavaTCTConfig> config = javaTCTApp.getJavaTCTConfig();
			
			String port = null;
			
			for (JavaTCTConfig javaTCTConfig : config)
			{
				if(javaTCTConfig.getConfig_key().equals("tcpport"))
				{
					port= javaTCTConfig.getConfig_value();
				}
			}
			
			List<String> args = new ArrayList<String>();	
			
			if(GlobalUtils.isWindows())
			{
				args.add(java_tct_home+File.separator+"bin"+File.separator+java_tct_stop_client_script_name+".bat");				
			}
			else
			{
				args.add(java_tct_home+File.separator+"bin"+File.separator+java_tct_stop_client_script_name+".sh");
			}			
			
			args.add(port);
			result = new ScriptExecutorTask().call(args);
		}
		catch(Exception e)
		{
			System.out.println("Exception stopping server "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString(),result.toString()), HttpStatus.OK);		
    }
	
	@RequestMapping(value = "/status/{id}", method=RequestMethod.GET)	
	public ResponseEntity<Response> statusServer(@PathVariable Long id) throws Exception 
    {	
		List<String> result = null;
		try
		{
			//Need to write code to validate if port is already running or acquired
			
			JavaTCTApp javaTCTApp= javaTCTAppServiceImpl.fetch(id);			
			Set<JavaTCTConfig> config = javaTCTApp.getJavaTCTConfig();
			
			String port = null;
			
			for (JavaTCTConfig javaTCTConfig : config)
			{
				if(javaTCTConfig.getConfig_key().equals("tcpport"))
				{
					port= javaTCTConfig.getConfig_value();
				}
			}
			
			List<String> args = new ArrayList<String>();	
			if(GlobalUtils.isWindows())
			{
				args.add(java_tct_home+File.separator+"bin"+File.separator+java_tct_status_client_script_name+".bat");
				
			}
			else
			{
				args.add(java_tct_home+File.separator+"bin"+File.separator+java_tct_status_client_script_name+".sh");
			}	
			
			if(port!=null)
			{
				args.add(port);
				result = new ScriptExecutorTask().call(args);
			}
			else
			{
				result = new ArrayList<String>();
				result.add("NOT-FOUND");				
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception status server "+e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(result.size() > 0)
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString(),result.get(result.size()-1)), HttpStatus.OK);	
		else
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(),"Error while fetching server status!!!"), HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	public static void main(String[] args) {
		
		System.out.println(System.getProperty("os.name"));
	}
	
	
}
