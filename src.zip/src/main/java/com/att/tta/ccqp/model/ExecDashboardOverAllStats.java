package com.att.tta.ccqp.model;

public class ExecDashboardOverAllStats 
{
	
	private Long app_count;
	private Long host_count;
	private Long email_count;
	private Boolean success=true;
	
	public ExecDashboardOverAllStats() {
		// TODO Auto-generated constructor stub
	}

	public ExecDashboardOverAllStats(Long app_count, Long host_count,
			Long email_count) {
		super();
		this.app_count = app_count;
		this.host_count = host_count;
		this.email_count = email_count;
	}
	
	

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

	public Long getApp_count() {
		return app_count;
	}

	public void setApp_count(Long app_count) {
		this.app_count = app_count;
	}

	public Long getHost_count() {
		return host_count;
	}

	public void setHost_count(Long host_count) {
		this.host_count = host_count;
	}

	public Long getEmail_count() {
		return email_count;
	}

	public void setEmail_count(Long email_count) {
		this.email_count = email_count;
	}
}
