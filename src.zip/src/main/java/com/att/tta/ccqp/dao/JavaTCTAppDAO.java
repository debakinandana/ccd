package com.att.tta.ccqp.dao;

import java.util.List;

import com.att.tta.ccqp.model.ExecDashboardOverAllStats;
import com.att.tta.ccqp.schema.JavaTCTApp;



public interface JavaTCTAppDAO
{
	public long create(JavaTCTApp javaTCTApp);
	public JavaTCTApp update(JavaTCTApp javaTCTApp);
	public void delete(JavaTCTApp javaTCTApp);
	public List<JavaTCTApp> fetchAll();
	public JavaTCTApp fetch(long id);
	public List<JavaTCTApp> fetchAll(String textStr);
	public Long giveMeAvailablePort();	
	public ExecDashboardOverAllStats fetchExecDashboardOverAllStats();

}
