package com.att.tta.ccqp.model;

public class Response 
{
	
	private String message;
	private String status;
	private String exception;
	
	public Response() {
		// TODO Auto-generated constructor stub
	}

	public Response(String message, String status) {
		super();
		this.message = message;
		this.status = status;
	}
	
	

	public Response(String message, String status, String exception) {
		super();
		this.message = message;
		this.status = status;
		this.exception = exception;
	}

	
	
	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
