package com.att.tta.ccqp.api;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.att.tta.ccqp.dao.JavaTCTAppDAO;
import com.att.tta.ccqp.model.ExecDashboardOverAllStats;
import com.att.tta.ccqp.model.KeyValue;
import com.att.tta.ccqp.model.Response;
import com.att.tta.ccqp.schema.JavaTCTApp;
import com.att.tta.ccqp.schema.JavaTCTConfig;
import com.att.tta.ccqp.service.JavaTCTAppService;
import com.att.tta.ccqp.utils.GlobalKeys;

@RestController
@RequestMapping(value = "/app")
public class JavaTCTAppController
{

	@Autowired
	JavaTCTAppService javaTCTAppServiceImpl;
	
	@Autowired
	JavaTCTAppDAO javaTCTAppDAOImpl;
	
	@Value("${java_tct_home}")
	String javaTCTParentFolderName;

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<Response> createApplication(@RequestBody JavaTCTApp javaTCTApp) throws Exception
	{
		Long id;

		try
		{
			id = javaTCTAppServiceImpl.createApplication(javaTCTApp);
		} catch (DataAccessException e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, String.valueOf(id)), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/create/all", method = RequestMethod.POST)
	public ResponseEntity<Response> create(@RequestBody JavaTCTApp javaTCTApp) throws Exception
	{
		try
		{
			javaTCTAppServiceImpl.create(javaTCTApp);
		} catch (DataAccessException e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public ResponseEntity<Response> update(@RequestBody JavaTCTApp javaTCTApp) throws Exception
	{
		try
		{
			javaTCTAppServiceImpl.update(javaTCTApp);
		} catch (Exception e)
		{
			System.out.println("Exception updating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/update/application", method = RequestMethod.PUT)
	public ResponseEntity<Response> updateApplication(@RequestBody JavaTCTApp javaTCTApp) throws Exception
	{
		try
		{
			javaTCTAppServiceImpl.updateConfig(javaTCTApp);
		} catch (Exception e)
		{
			System.out.println("Exception updating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public ResponseEntity<Response> delete(@RequestBody JavaTCTApp javaTCTApp) throws Exception
	{
		try
		{
			javaTCTAppServiceImpl.delete(javaTCTApp);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.OK);
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Response> deleteById(@PathVariable Long id) throws Exception
	{
		try
		{
			javaTCTAppServiceImpl.delete(javaTCTAppServiceImpl.fetch(id));
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.OK);
	}

	@RequestMapping(value = "/search/{id}", method = RequestMethod.GET)
	public ResponseEntity<JavaTCTApp> searchById(@PathVariable Long id) throws Exception
	{
		JavaTCTApp javaTCTApp = null;
		try
		{
			javaTCTApp = javaTCTAppServiceImpl.fetch(id);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<JavaTCTApp>(javaTCTApp, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<JavaTCTApp>(javaTCTApp, HttpStatus.OK);
	}

	@RequestMapping(value = "/report-detail", method = RequestMethod.GET)
	public ResponseEntity<Map<String, String>> fetchCoverageReportDetail() throws Exception
	{
		return new ResponseEntity<Map<String, String>>(javaTCTAppServiceImpl.fetchCoverageReportDetail(), HttpStatus.OK);
	}

	@RequestMapping(value = "/search/all", method = RequestMethod.GET)
	public ResponseEntity<List<JavaTCTApp>> searchAll() throws Exception
	{
		List<JavaTCTApp> javaTCTApps = null;
		try
		{
			javaTCTApps = javaTCTAppServiceImpl.fetchAll();
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<List<JavaTCTApp>>(javaTCTApps, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<List<JavaTCTApp>>(javaTCTApps, HttpStatus.OK);
	}

	@RequestMapping(value = "/download/agent-properties/{id}", method = RequestMethod.GET)
	public ResponseEntity<InputStreamResource> downloadAgentProperties(@PathVariable Long id) throws Exception
	{
		JavaTCTApp javaTCTApp = null;
		InputStream is = null;
		StringBuilder properties = null;
		HttpHeaders headers = new HttpHeaders();

		try
		{
			javaTCTApp = javaTCTAppServiceImpl.fetch(id);
			Set<JavaTCTConfig> javaTCTConfigs = javaTCTApp.getJavaTCTConfig();

			properties = new StringBuilder();

			for (JavaTCTConfig javaTCTConfig : javaTCTConfigs)
			{
				if (javaTCTConfig.getConfig_type().equals("agent"))
				{
					properties.append(javaTCTConfig.getConfig_key()).append("=").append(javaTCTConfig.getConfig_value()).append("\n");
				} 
				else if (javaTCTConfig.getConfig_type().equals("client") && javaTCTConfig.getConfig_key().equals("sessionid"))
				{
					properties.append(javaTCTConfig.getConfig_key()).append("=").append(javaTCTConfig.getConfig_value()).append("\n");
				}
			}
			
			properties.append("dumponexit").append("=").append("false");

			is = new ByteArrayInputStream(properties.toString().getBytes());

			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
			headers.add("content-disposition", "attachment; filename=ccqp.properties");
		} catch (Exception e)
		{

		}

		return ResponseEntity.ok().contentLength(properties.toString().length()).headers(headers).contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM.toString())).body(new InputStreamResource(is));

	}

	@RequestMapping(value = "/download/agent", method = RequestMethod.GET)
	public ResponseEntity<InputStreamResource> downloadAgent() throws Exception
	{
		ClassPathResource pdfFile = new ClassPathResource("../agent-setup/lib/ccqp-agent.jar");

		HttpHeaders headers = new HttpHeaders();
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
		headers.add("content-disposition", "attachment; filename=ccqp-agent.jar");

		return ResponseEntity.ok().contentLength(pdfFile.contentLength()).headers(headers).contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM.toString())).body(new InputStreamResource(pdfFile.getInputStream()));
	}
	
	private static final int BUFFER_SIZE = 4096;
	
	@RequestMapping(value = "/download/coverage/{id}", method = RequestMethod.GET)
	public void downloadCoverage(@PathVariable Long id,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		JavaTCTApp javaTCTApp = null;
		StringBuilder properties = null;

		javaTCTApp = javaTCTAppServiceImpl.fetch(id);
		Set<JavaTCTConfig> javaTCTConfigs = javaTCTApp.getJavaTCTConfig();

		properties = new StringBuilder();
		
		String ccqp_parant = null;
		String merge_data_file = null;

		for (JavaTCTConfig javaTCTConfig : javaTCTConfigs)
		{
			if(javaTCTConfig.getConfig_key().equals("ccqp_parant"))
			{
				ccqp_parant = javaTCTConfig.getConfig_value();
				
			}
			else if(javaTCTConfig.getConfig_key().equals("merge_data_file"))
			{
				merge_data_file=javaTCTConfig.getConfig_value();
				
			}				
		}
		
		properties.append(ccqp_parant);
		properties.append("/");
		properties.append(merge_data_file);			

		
		
		// get absolute path of the application
        ServletContext context = request.getServletContext();
 
        // construct the complete absolute path of the file
        String fullPath = properties.toString();  
        File downloadFile = new File(fullPath);
        FileInputStream inputStream = new FileInputStream(downloadFile);
         
        // get MIME type of the file
        String mimeType = context.getMimeType(fullPath);
        if (mimeType == null) {
            // set to binary type if MIME mapping not found
            mimeType = "application/octet-stream";
        }
        System.out.println("MIME type: " + mimeType);
 
        // set content attributes for the response
        response.setContentType(mimeType);
        response.setContentLength((int) downloadFile.length());
 
        // set headers for the response
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"",
                downloadFile.getName());
        response.setHeader(headerKey, headerValue);
 
        // get output stream of the response
        OutputStream outStream = response.getOutputStream();
 
        byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead = -1;
 
        // write bytes read from the input stream into the output stream
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
 
        inputStream.close();
        outStream.close();


	}

	@RequestMapping(value = "/search/packages/{appName}", method = RequestMethod.GET)
	public ResponseEntity<List<KeyValue>> fetchAllPackagesClassStrutures(@PathVariable String appName) throws Exception
	{
		return new ResponseEntity<List<KeyValue>>(javaTCTAppServiceImpl.fetchAllPackagesClassStrutures(appName), HttpStatus.OK);
	}

	@RequestMapping(value = "/dashboard/overall", method = RequestMethod.GET)
	public ResponseEntity<ExecDashboardOverAllStats> fetchExecDashboardOverAllStats() throws Exception
	{
		return new ResponseEntity<ExecDashboardOverAllStats>(javaTCTAppServiceImpl.fetchExecDashboardOverAllStats(), HttpStatus.OK);
	}

	@RequestMapping(value = "/archieve/{id}", method = RequestMethod.GET)
	public ResponseEntity<Response> archiveCoverage(@PathVariable Long id) throws Exception
	{
		try
		{
			javaTCTAppServiceImpl.archiveReport(id);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, HttpStatus.CREATED.toString()), HttpStatus.OK);
	}

	@RequestMapping(value = "/start_new_session/{id}", method = RequestMethod.GET)
	public ResponseEntity<Response> startNewSession(@PathVariable Long id) throws Exception
	{
		String sessionId = null;

		try
		{
			sessionId = javaTCTAppServiceImpl.startNewSession(id);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, "New Session has been started successfully : " + sessionId, sessionId), HttpStatus.OK);
	}

	@RequestMapping(value = "/stop_new_session/{sessionData}", method = RequestMethod.GET)
	public ResponseEntity<Response> stopNewSession(@PathVariable String sessionData) throws Exception
	{
		String sessionId = null;

		try
		{
			sessionId = javaTCTAppServiceImpl.stopNewSession(sessionData);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_FAILED, HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, "New Session has been started successfully : " + sessionId, sessionId), HttpStatus.OK);
	}

	@RequestMapping(value = "/fetch_all_sessions/{id}", method = RequestMethod.GET)
	public ResponseEntity<List<KeyValue>> fetchAllSessions(@PathVariable Long id) throws Exception
	{
		List<KeyValue> sessions = null;

		try
		{
			sessions = javaTCTAppServiceImpl.fetchSessinList(id);
		} catch (Exception e)
		{
			System.out.println("Exception creating app " + e.getMessage());
			return new ResponseEntity<List<KeyValue>>(sessions, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<List<KeyValue>>(sessions, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/get_test_flow_files_list/{id}/{sessionId}", method = RequestMethod.GET)
	public ResponseEntity<List<KeyValue>> getTestFlowFilesList(@PathVariable Long id, @PathVariable String sessionId) throws Exception {
	    JavaTCTApp appDetails = javaTCTAppServiceImpl.fetch(id);
	    List<KeyValue> filenamesList = new ArrayList<KeyValue>();
	    String testFlowDirectoryPath = javaTCTParentFolderName + "/" + appDetails.getAppFolderName() + "/testFlow_" + sessionId;
	    File testFlowDirectory = new File(testFlowDirectoryPath);
	    File[] filesList = null;
	    if (testFlowDirectory.exists()) {
		filesList = testFlowDirectory.listFiles();
		for (File file : filesList) {
		    String endpointUri = "/app/download/test_flow_file/" + id + "/" + sessionId + "/" + file.getName();
		    KeyValue fileAndEndpoint = new KeyValue(file.getName(), endpointUri);
		    filenamesList.add(fileAndEndpoint);
		}
	    }
	    return new ResponseEntity<List<KeyValue>>(filenamesList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "download/test_flow_file/{id}/{sessionId}/{filename:.+}", method = RequestMethod.GET)
	public ResponseEntity<InputStreamResource> downloadTestFlowFile(@PathVariable long id, @PathVariable String sessionId, @PathVariable String filename) throws Exception {
	    JavaTCTApp appDetails = javaTCTAppServiceImpl.fetch(id);
	    String testFlowFilePath = javaTCTParentFolderName + "/" + appDetails.getAppFolderName() + "/testFlow_" + sessionId + "/" + filename;
	    FileSystemResource testFlowFile = new FileSystemResource(testFlowFilePath);
	    
	    HttpHeaders headers = new HttpHeaders();
	    if(testFlowFile.exists()) {
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
		headers.add("content-disposition", "attachment; filename=" + filename);
		
	    }
	    return ResponseEntity.ok().contentLength(testFlowFile.contentLength()).headers(headers).contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM.toString())).body(new InputStreamResource(testFlowFile.getInputStream()));
	    
	    
	}
	
	@RequestMapping(value = "/staty", method = RequestMethod.GET)
	public ResponseEntity<Response> getStatus() {
		return new ResponseEntity<Response>(new Response(GlobalKeys.RESPONSE_MESSAGE_SUCCESS, "Up and running"), HttpStatus.OK);
	}
	
	

}
