package com.att.tta.ccqp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.tta.ccqp.dao.HibernateUtil;
import com.att.tta.ccqp.utils.GlobalUtils;



@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class TestHiberNate 
{
	
	@Autowired
	private HibernateUtil hibernateUtil;
	
	@Test	
	public void testConnection()
	{
		
		GlobalUtils.isWindows();
		//save(2);		
	}
	
	public void save(Integer seq)
	{
		
		/*
		 * JAVA_TCT_CONFIG_DETAIL
		
		JavaTCTConfigMaster configDetail = new JavaTCTConfigMaster();
		configDetail.setName("SESSIONID1"+seq);
		configDetail.setType("CLIENT"+seq);
		
		JavaTCTConfigMaster configDetail2 = new JavaTCTConfigMaster();
		configDetail2.setName("SESSIONID2"+seq);
		configDetail2.setType("CLIENT"+seq);
		
		JavaTCTConfigMaster configDetail3 = new JavaTCTConfigMaster();
		configDetail3.setName("SESSIONID3"+seq);
		configDetail3.setType("AGENT"+seq);
		
		hibernateUtil.create(configDetail);
		hibernateUtil.create(configDetail2);
		hibernateUtil.create(configDetail3);
		 */
		
		
		/*
		 * JAVA_TCT_CP_MASTER
		
		JavaTCTCustPropertyMaster custPropertyMaster = new JavaTCTCustPropertyMaster();
		custPropertyMaster.setName("SESSIONID1"+seq);
		
		JavaTCTCustPropertyMaster custPropertyMaster2 = new JavaTCTCustPropertyMaster();
		custPropertyMaster2.setName("SESSIONID2"+seq);
		
		JavaTCTCustPropertyMaster custPropertyMaster3 = new JavaTCTCustPropertyMaster();
		custPropertyMaster3.setName("SESSIONID3"+seq);
		 */
		
		/*
		 * JAVA_TCT_JVM_ARGS_MASTER
		
		JavaTCTJVMArgsMaster javaTCTJVMArgsMaster = new JavaTCTJVMArgsMaster();
		javaTCTJVMArgsMaster.setName("JAVAAGENT1"+seq);
		
		JavaTCTJVMArgsMaster javaTCTJVMArgsMaster2 = new JavaTCTJVMArgsMaster();
		javaTCTJVMArgsMaster2.setName("JAVAAGENT2"+seq);
		
		JavaTCTJVMArgsMaster javaTCTJVMArgsMaster3 = new JavaTCTJVMArgsMaster();
		javaTCTJVMArgsMaster3.setName("JAVAAGENT3"+seq);
		 */
		
		/*
		 * JAVA_TCT_STATUS_MASTER
		 
		JavaTCTStatusMaster javaTCTStatusMaster = new JavaTCTStatusMaster();
		javaTCTStatusMaster.setName("RUNNING1"+seq);
		
		JavaTCTStatusMaster javaTCTStatusMaster2 = new JavaTCTStatusMaster();
		javaTCTStatusMaster2.setName("RUNNING2"+seq);
		
		JavaTCTStatusMaster javaTCTStatusMaster3 = new JavaTCTStatusMaster();
		javaTCTStatusMaster3.setName("RUNNING3"+seq);
		*/
		
		/*
		 * JAVA_TCT_APP_DETAIL
		
		JavaTCTApp appDetail = new JavaTCTApp();		
		appDetail.setApp_name("API36000"+seq);
		appDetail.setHost_name("HLTD42500"+seq);
		appDetail.setVersion("100.0.000"+seq);
		
		JavaTCTJVMArgs javaTCTJVMArgs = new JavaTCTJVMArgs();
		javaTCTJVMArgs.setText("javaagent:abedddddd"+seq);
		javaTCTJVMArgs.setJavaTCTAppDetail(appDetail);
		javaTCTJVMArgs.setTctjvmArgsMaster(javaTCTJVMArgsMaster);
		 */
		
		/*
		JavaTCTCustProperty javaTCTCustProperty = new JavaTCTCustProperty();
		javaTCTCustProperty.setText("mycustormprop"+seq);
		javaTCTCustProperty.setJavaTCTAppDetail(appDetail);
		javaTCTCustProperty.setCustPropertyMaster(custPropertyMaster);
		
		
		JavaTCTStatus javaTCTStatus = new JavaTCTStatus();
		javaTCTStatus.setText("VALUE"+seq);
		javaTCTStatus.setJavaTCTAppDetail(appDetail);
		javaTCTStatus.setJavaTCTStatusMaster(javaTCTStatusMaster);
		*/
		
		/*
		hibernateUtil.create(javaTCTJVMArgs);
		hibernateUtil.create(javaTCTCustProperty);
		hibernateUtil.create(javaTCTStatus);
		*/
		
		/*
		JavaTCTConfig config = new JavaTCTConfig();	
		config.setConfig_value("mysession"+seq);
		config.setJavaTCTApp(appDetail);	
		config.setJavaTCTConfigMaster(configDetail);
		
		JavaTCTConfig config2 = new JavaTCTConfig();
		config2.setConfig_value("mysession2"+seq);
		config2.setJavaTCTApp(appDetail);
		config2.setJavaTCTConfigMaster(configDetail2);
		
		JavaTCTConfig config3 = new JavaTCTConfig();
		config3.setConfig_value("mysession3"+seq);
		config3.setJavaTCTApp(appDetail);
		config3.setJavaTCTConfigMaster(configDetail3);		
		
		hibernateUtil.create(config);
		hibernateUtil.create(config2);
		hibernateUtil.create(config3);
		*/
		
	}
	

}
